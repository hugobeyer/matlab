// Copyright 2026 Hugo Beyer. All Rights Reserved.

#include "Widgets/SMixtormat.h"
#include "Widgets/SMixtormatInternal.h"
#include "MixtormatParameterBinding.h"
#include "UI/Menus/MixtormatMenuBuilder.h"
#include "UI/Parameters/MixtormatParameterUiMeta.h"
#include "Widgets/Gallery/SMixtormatGalleryScrollBox.h"
#include "Widgets/Gallery/SMixtormatSurfaceCard.h"
#include "Style/MixtormatTypography.h"
#include "Style/MixtormatThemeStore.h"
#include "UI/Controls/SMixtormatGroupAction.h"
#include "UI/Controls/SMixtormatTextFieldGradient.h"
#include "UI/Atoms/SMixtormatChip.h"
#include "UI/Atoms/MixtormatIcons.h"
#include "UI/Atoms/SMixtormatIconButton.h"
#include "UI/Menus/SMixtormatHelp.h"
#include "UI/Primitives/SMixtormatWellBox.h"
#include "UI/Primitives/SMixtormatSurfaceBox.h"
#include "UI/Controls/MixtormatShellSplitterStyle.h"
#include "Style/MixtormatRecipes.h"
#include "Widgets/Layout/SSplitter.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Input/SEditableTextBox.h"

#include "ObjectTools.h"

// Shipped surface galleries and the user-owned saved-mix/imported-surface library.

#define LOCTEXT_NAMESPACE "SMixtormat"

namespace
{
	bool bSuppressDeveloperRefreshSuccessDialog = false;

	class SMixtormatCompositionCard final : public SCompoundWidget
	{
	public:
		SLATE_BEGIN_ARGS(SMixtormatCompositionCard) {}
			SLATE_DEFAULT_SLOT(FArguments, Content)
			SLATE_EVENT(FOnGetContent, OnGetContextMenu)
		SLATE_END_ARGS()

		void Construct(const FArguments& InArgs)
		{
			ChildSlot
			[
				SAssignNew(ContextAnchor, SMenuAnchor)
				.Placement(MenuPlacement_MenuRight)
				.UseApplicationMenuStack(true)
				.OnGetMenuContent(InArgs._OnGetContextMenu)
				[
					InArgs._Content.Widget
				]
			];
		}

		virtual FReply OnPreviewMouseButtonDown(
			const FGeometry& Geometry,
			const FPointerEvent& MouseEvent) override
		{
			if (MouseEvent.GetEffectingButton() == EKeys::RightMouseButton && ContextAnchor.IsValid())
			{
				ContextAnchor->SetIsOpen(true);
				return FReply::Handled();
			}
			return SCompoundWidget::OnPreviewMouseButtonDown(Geometry, MouseEvent);
		}

	private:
		TSharedPtr<SMenuAnchor> ContextAnchor;
	};
}

FReply SMixtormat::RefreshSurfaceList()
{
	RebuildCategoryList();
	RebuildSurfaceList();
	RebuildUserLibraryList();
	RebuildMaskList();
	return FReply::Handled();
}

void SMixtormat::ZoomMaterialGallery(const int32 Direction)
{
	MaterialGalleryTileSize = FMath::Clamp(
		MaterialGalleryTileSize + Direction * MixtormatTokens::MaterialGalleryTileStep,
		MixtormatTokens::MaterialGalleryTileMinimum,
		MixtormatTokens::MaterialGalleryTileMaximum);
	RebuildSurfaceList();
}

FReply SMixtormat::SelectMask(FText DisplayName, FSoftObjectPath AssetPath)
{
	SelectedMaskPath = AssetPath;
	SelectedLibraryMaskName = DisplayName;
	if (MaskListBox.IsValid())
	{
		MaskListBox->Invalidate(EInvalidateWidgetReason::Paint);
	}
	return FReply::Handled();
}

FReply SMixtormat::SelectSurface(FText DisplayName, FSoftObjectPath AssetPath)
{
	SelectedSurfacePath = AssetPath;
	SelectedLibrarySurfaceName = DisplayName;
	if (bHasWorkingMaterial)
	{
		return FReply::Handled();
	}

	bHasSelectedLayer = false;
	SelectedLayerIndex = INDEX_NONE;
	SelectedEffectIndex = INDEX_NONE;
	SelectedMaskIndex = INDEX_NONE;
	DebugPreviewMode = EMixtormatDebugPreviewMode::None;
	WorkingLayers.Reset();
	WorkingMaterialName = TEXT("No material");
	if (SelectedSurfaceText.IsValid())
	{
		SelectedSurfaceText->SetText(LOCTEXT("NoSelectedLayer", "No layer selected"));
	}
	if (WorkingBaseLayerText.IsValid())
	{
		WorkingBaseLayerText->SetText(DisplayName);
	}

	const UMixtormatSurface* Surface = Cast<UMixtormatSurface>(AssetPath.TryLoad());
	if (Surface)
	{
		SelectedPreviewMaterial.Reset(Cast<UMaterialInstanceConstant>(Surface->PreviewMaterial.Get()));
		bHasWorkingMaterial = false;
		if (SelectedPreviewMaterial.IsValid())
		{
			CurrentTiling = FMath::Max(1.0f, FMath::RoundToFloat(
				UMaterialEditingLibrary::GetMaterialInstanceScalarParameterValue(
					SelectedPreviewMaterial.Get(), TEXT("DA_Tiling"))));
			CurrentRoughnessBias = UMaterialEditingLibrary::GetMaterialInstanceScalarParameterValue(
				SelectedPreviewMaterial.Get(), TEXT("DA_RoughnessBias"));
			CurrentRoughnessContrast = UMaterialEditingLibrary::GetMaterialInstanceScalarParameterValue(
				SelectedPreviewMaterial.Get(), TEXT("DA_RoughnessContrast"));
			CurrentRoughnessOffset = UMaterialEditingLibrary::GetMaterialInstanceScalarParameterValue(
				SelectedPreviewMaterial.Get(), TEXT("DA_RoughnessOffset"));
		}
		if (SelectedIdentityText.IsValid())
		{
			SelectedIdentityText->SetText(FText::FromName(Surface->Family));
		}
		if (bPreviewDisplacementEnabled)
		{
			PreviewSelectedSurfaceWithDisplacement();
		}
		else
		{
			for (const TSharedPtr<SMixtormatPreviewViewport>& Viewport : PreviewViewports)
			{
				if (Viewport.IsValid())
				{
					Viewport->SetPreviewMaterial(Surface->PreviewMaterial);
				}
			}
		}
	}

	RebuildLayerList();
	return FReply::Handled();
}

FReply SMixtormat::HandleSurfaceDropped(FText DisplayName, FSoftObjectPath AssetPath)
{
	SelectSurface(DisplayName, AssetPath);
	return bHasWorkingMaterial
		? AddWorkingLayer(EMixtormatLayerType::Material)
		: StartNewMaterial();
}

FReply SMixtormat::SetCategoryFilter(const FName Family)
{
	CategoryFilter = Family;
	RebuildCategoryList();
	RebuildSurfaceList();
	return FReply::Handled();
}

void SMixtormat::HandleSearchChanged(const FText& SearchTextValue)
{
	SearchText = SearchTextValue.ToString();
	RebuildSurfaceList();
}

void SMixtormat::RebuildCategoryList()
{
	if (!CategoryListBox.IsValid())
	{
		return;
	}

	TArray<FName> Families;
	for (const FMixtormatSurfaceEntry& Surface : FMixtormatRegistry::GetSurfaces())
	{
		if (!MixtormatUI::IsUserLibraryAsset(Surface.AssetPath))
		{
			Families.AddUnique(Surface.Family);
		}
	}
	Families.Remove(NAME_None);
	Families.Sort([](const FName& A, const FName& B)
	{
		return A.LexicalLess(B);
	});

	if (!CategoryFilter.IsNone() && !Families.Contains(CategoryFilter))
	{
		CategoryFilter = NAME_None;
	}

	CategoryListBox->ClearChildren();
	const ISlateStyle& Style = FMixtormatStyle::Get();
	const auto AddCategory = [this, &Style](const FName Family, const FText& Label)
	{
		CategoryListBox->AddSlot()
		.AutoHeight()
		.Padding(0.0f, CategoryListBox->GetChildren()->Num() > 0 ? 4.0f : 0.0f, 0.0f, 0.0f)
		[
			SNew(SButton)
			.ButtonStyle(&Style.GetWidgetStyle<FButtonStyle>(
				CategoryFilter == Family ? TEXT("Mixtormat.TabButtonActive") : TEXT("Mixtormat.TabButton")))
			.Text(Label)
			.OnClicked_Lambda([this, Family]() { return SetCategoryFilter(Family); })
		];
	};

	AddCategory(NAME_None, LOCTEXT("AllCategory", "All Materials"));
	for (const FName Family : Families)
	{
		AddCategory(Family, FText::FromName(Family));
	}
}

void SMixtormat::RebuildSurfaceList()
{
	if (!SurfaceListBox.IsValid())
	{
		return;
	}

	SurfaceListBox->ClearChildren();
	const TArray<FMixtormatSurfaceEntry> Surfaces = FMixtormatRegistry::GetSurfaces();
	int32 VisibleSurfaceIndex = 0;
	for (const FMixtormatSurfaceEntry& Surface : Surfaces)
	{
		if (MixtormatUI::IsUserLibraryAsset(Surface.AssetPath)
			|| (!CategoryFilter.IsNone() && Surface.Family != CategoryFilter))
		{
			continue;
		}
		if (!SearchText.IsEmpty() && !Surface.DisplayName.ToString().Contains(SearchText))
		{
			continue;
		}

		SurfaceListBox->AddSlot()
		.HAlign(HAlign_Left)
		.VAlign(VAlign_Top)
		[
			BuildSurfaceCard(Surface.DisplayName, Surface.AssetPath, Surface.ThumbnailAsset)
		];
		++VisibleSurfaceIndex;
	}

	if (VisibleSurfaceIndex == 0)
	{
		SurfaceListBox->AddSlot()
		[
			SNew(STextBlock)
			.Text(Surfaces.IsEmpty()
				? LOCTEXT("EmptyRegistry", "Built-in Mixtormat content is missing. Repair or reinstall Mixtormat, or import a texture folder.")
				: LOCTEXT("NoMatchingSurfaces", "No materials match the current filters."))
			.AutoWrapText(true)
			.ColorAndOpacity(FSlateColor::UseSubduedForeground())
		];
	}
}

void SMixtormat::HandleUserLibrarySearchChanged(const FText& SearchTextValue)
{
	UserLibrarySearchText = SearchTextValue.ToString();
	RebuildUserLibraryList();
}

void SMixtormat::RebuildUserLibraryList()
{
	if (!UserLibraryListBox.IsValid()) { return; }
	UserLibraryListBox->ClearChildren();
	const auto& Resolved = FMixtormatThemeStore::GetResolved();
	const auto& Library = Resolved.ShellLayout;
	const auto& Palette = Resolved.Palette;
	const auto HeadingStyle = Mixtormat::FMixtormatTypography::MakeTextStyle(
		Mixtormat::FMixtormatTypography::GetSpec(Resolved.Typography, Mixtormat::EMixtormatTextRole::CardTitle),
		Palette.Get(Mixtormat::EMixtormatColorRole::TextMuted));
	const auto LabelStyle = Mixtormat::FMixtormatTypography::MakeTextStyle(
		Mixtormat::FMixtormatTypography::GetSpec(Resolved.Typography, Mixtormat::EMixtormatTextRole::LayerName),
		Palette.Get(Mixtormat::EMixtormatColorRole::Text));
	const FLinearColor HeadingColor = Palette.Get(Mixtormat::EMixtormatColorRole::TextMuted)
		.CopyWithNewOpacity(Palette.Get(Mixtormat::EMixtormatColorRole::TextMuted).A * Library.LibraryHeadingOpacity);
	const FLinearColor LabelColor = Palette.Get(Mixtormat::EMixtormatColorRole::Text)
		.CopyWithNewOpacity(Palette.Get(Mixtormat::EMixtormatColorRole::Text).A * Library.LibraryLabelOpacity);

	int32 VisibleItemCount = 0;
	const auto AddHeading = [this, &Library, &HeadingStyle, HeadingColor](const FText& Label)
	{
		UserLibraryListBox->AddSlot().AutoHeight()
		.Padding(0.0f, Library.LibraryItemGap, 0.0f, Library.LibraryItemGap)
		[
			SNew(STextBlock)
			.Font(HeadingStyle.Font)
			.ColorAndOpacity(FSlateColor(HeadingColor))
			.Text(Label)
		];
	};
	const auto AddCard = [this, &Library, &LabelStyle, LabelColor](
		const FText& Name, const FAssetData& ThumbnailAsset,
		const FOnGetContent& ContextMenu)
	{
		UserLibraryListBox->AddSlot().AutoHeight()
		.Padding(0.0f, 0.0f, 0.0f, Library.LibraryItemGap)
		[
			SNew(SBox)
			.HeightOverride(Library.LibraryRowHeight)
			[
				SNew(SMixtormatCompositionCard)
				.OnGetContextMenu(ContextMenu)
				[
					SNew(SMixtormatSurfaceBox)
				.Recipe_Lambda([]()
				{
					return Mixtormat::MakeCardBodyRecipe(FMixtormatThemeStore::GetTheme(), 1.0f, 0.0f);
				})
				.Padding(FMargin(Library.LibraryItemGap))
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)
					[
						SNew(SMixtormatTile)
						.TileSize(FMath::Min(Library.LibraryThumbnailSize,
							FMath::Max(12.0f, Library.LibraryRowHeight - 2.0f * Library.LibraryItemGap)))
						.ThumbnailAsset(ThumbnailAsset)
						.ThumbnailPool(ThumbnailPool)
						.bShowName(false)
						.bShowNameOnHover(false)
					]
					+ SHorizontalBox::Slot().FillWidth(1.0f).VAlign(VAlign_Center)
					.Padding(Library.LibraryItemGap, 0.0f, 0.0f, 0.0f)
					[
						SNew(STextBlock)
						.Font(LabelStyle.Font)
						.ColorAndOpacity(FSlateColor(LabelColor))
						.Text(Name)
						.OverflowPolicy(ETextOverflowPolicy::Ellipsis)
					]
					]
				]
			]
		];
	};

	bool bAddedCompositionHeading = false;
	for (const FMixtormatCompositionEntry& Composition : FMixtormatRegistry::GetCompositions())
	{
		if (!UserLibrarySearchText.IsEmpty()
			&& !Composition.DisplayName.ToString().Contains(UserLibrarySearchText)) { continue; }
		if (!bAddedCompositionHeading)
		{
			AddHeading(LOCTEXT("SavedMixesHeading", "SAVED MIXES"));
			bAddedCompositionHeading = true;
		}
		AddCard(Composition.DisplayName, Composition.ThumbnailAsset,
			FOnGetContent::CreateSP(this, &SMixtormat::BuildCompositionLibraryContextMenu, Composition.AssetPath));
		++VisibleItemCount;
	}
	bool bAddedSurfaceHeading = false;
	for (const FMixtormatSurfaceEntry& Surface : FMixtormatRegistry::GetSurfaces())
	{
		if (!MixtormatUI::IsUserLibraryAsset(Surface.AssetPath)
			|| (!UserLibrarySearchText.IsEmpty()
				&& !Surface.DisplayName.ToString().Contains(UserLibrarySearchText))) { continue; }
		if (!bAddedSurfaceHeading)
		{
			AddHeading(LOCTEXT("ImportedSurfacesHeading", "IMPORTED SURFACES"));
			bAddedSurfaceHeading = true;
		}
		AddCard(Surface.DisplayName, Surface.ThumbnailAsset,
			FOnGetContent::CreateSP(this, &SMixtormat::BuildSurfaceLibraryContextMenu, Surface.AssetPath));
		++VisibleItemCount;
	}
	if (VisibleItemCount == 0)
	{
		UserLibraryListBox->AddSlot().AutoHeight()
		.Padding(0.0f, Library.LibraryItemGap)
		[
			SNew(STextBlock)
			.Text(UserLibrarySearchText.IsEmpty()
				? LOCTEXT("EmptyUserLibrary", "No saved mixes or imported surfaces yet.")
				: LOCTEXT("NoMatchingUserLibrary", "No matches."))
			.AutoWrapText(true)
			.Font(HeadingStyle.Font)
			.ColorAndOpacity(FSlateColor(HeadingColor))
		];
	}
}

TSharedRef<SWidget> SMixtormat::BuildUserLibraryPage()
{
	const ISlateStyle& Style = FMixtormatStyle::Get();
	const TSharedRef<SEditableTextBox> SearchEdit = SNew(SEditableTextBox)
		.Style(&Style.GetWidgetStyle<FEditableTextBoxStyle>(TEXT("Mixtormat.TextField")))
		.HintText(LOCTEXT("SearchUserLibraryHint", "Search saved mixes..."))
		.OnTextChanged_Lambda([this](const FText& Text)
		{
			if (UserLibrarySearchText != Text.ToString())
			{
				HandleUserLibrarySearchChanged(Text);
			}
		});
	SearchEdit->SetText(FText::FromString(UserLibrarySearchText));
	const auto& Layout = FMixtormatThemeStore::GetResolved().ShellLayout;
	const TSharedRef<SWidget> SearchBox = SNew(SMixtormatWellBox)
	[
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot().FillWidth(1.0f).VAlign(VAlign_Center)
		.Padding(Layout.LibrarySearchInnerPadding, 0.0f)
		[
			SNew(SMixtormatTextFieldGradient)
			[
				SNew(SBox)
				.MinDesiredHeight(FMixtormatThemeStore::GetTheme().TextField.MinHeight)
				.MinDesiredWidth(FMixtormatThemeStore::GetTheme().TextField.MinWidth)
				[SearchEdit]
			]
		]
		+ SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)
		.Padding(0.0f, 0.0f, Layout.LibrarySearchInnerPadding, 0.0f)
		[
			SNew(SMixtormatHelp)
			.Text(LOCTEXT("ChooseUserTextureFolderHint", "Import a texture folder"))
			[
				SNew(SButton)
				.ButtonStyle(&FCoreStyle::Get().GetWidgetStyle<FButtonStyle>(TEXT("NoBorder")))
				.ContentPadding(0.0f)
				.OnClicked_Lambda([this]() { ImportSurfaces(); return FReply::Handled(); })
				[
					SNew(SImage)
					.Image(MixtormatIcons::Folder())
					.ColorAndOpacity(FSlateColor(FMixtormatThemeStore::GetResolved().Palette.Get(
						Mixtormat::EMixtormatColorRole::TextMuted)))
				]
			]
		]
	];

	return SNew(SBorder)
		.Padding(Layout.LibraryPagePadding)
		.BorderImage(FCoreStyle::Get().GetBrush(TEXT("WhiteBrush")))
		.BorderBackgroundColor(FMixtormatThemeStore::GetResolved().Palette.Get(
			Mixtormat::EMixtormatColorRole::Shell))
		[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot().AutoHeight()
			.Padding(0.0f, 0.0f, 0.0f, Layout.LibrarySearchBottomGap)
			[
				SearchBox
			]
			+ SVerticalBox::Slot().FillHeight(1.0f)
			[
				SNew(SScrollBox)
				.ScrollBarStyle(&Style.GetWidgetStyle<FScrollBarStyle>(TEXT("Mixtormat.ScrollBar")))
				.ScrollBarThickness(FVector2D(FMixtormatThemeStore::GetResolved().ShellLayout.ScrollbarThickness))
				+ SScrollBox::Slot()
				[
					SAssignNew(UserLibraryListBox, SVerticalBox)
				]
			]
		];
}

TSharedRef<SWidget> SMixtormat::BuildBottomLibrary()
{
	const ISlateStyle& Style = FMixtormatStyle::Get();
	const Mixtormat::FMixtormatGalleryMetrics& Gallery = FMixtormatThemeStore::GetResolved().GalleryLayout;

	const Mixtormat::FMixtormatControlMetrics& Controls = FMixtormatThemeStore::GetResolved().ControlLayout;
	const float ShadowRange = FMixtormatThemeStore::GetTheme().ShellTheme.ColumnShadowRange;
	TSharedRef<SOverlay> Drawer = SNew(SOverlay);

	// A single broad, translucent backing replaces the nested rectangular shadow bands.
	Drawer->AddSlot().Padding(FMargin(0.0f, 0.0f, 0.0f, 0.0f))
	[
		SNew(SMixtormatSurfaceBox)
		.Recipe_Lambda([]()
		{
			Mixtormat::FMixtormatSurfaceRecipe Recipe = Mixtormat::MakeGroundRecipe();
			Recipe.bTranslucent = true;
			Recipe.Base.Role = Mixtormat::EMixtormatColorRole::Shade;
			Recipe.Base.Opacity = FMixtormatThemeStore::GetTheme().ShellTheme.ColumnShadowOpacity;
			return Recipe;
		})
	];

	Drawer->AddSlot().Padding(FMargin(ShadowRange, ShadowRange,
		ShadowRange + MixtormatTokens::DragGhostShadowOffsetX,
		0.0f))
	[
		SNew(SMixtormatSurfaceBox)
			.Recipe_Lambda([]()
			{
				Mixtormat::FMixtormatSurfaceRecipe Recipe = Mixtormat::MakeGroundRecipe();
				Recipe.bTranslucent = true;
				Recipe.Base.Opacity = FMixtormatThemeStore::GetResolved().GalleryLayout.DrawerSurfaceOpacity;
				Mixtormat::FMixtormatBorderLayer Border;
				Border.Source.Role = Mixtormat::EMixtormatColorRole::Hairline;
				Border.Source.Opacity = FMixtormatThemeStore::GetTheme().Menu.BorderOpacity;
				Border.Width = FMixtormatThemeStore::GetResolved().ControlLayout.HairlineThickness;
				Border.bTop = Border.bBottom = Border.bLeft = Border.bRight = true;
				Recipe.Borders.Add(Border);
				return Recipe;
			})
			.Padding(FMargin(FMixtormatThemeStore::GetResolved().ControlLayout.HairlineThickness))
			[
			SNew(SVerticalBox)
			+ SVerticalBox::Slot().AutoHeight()
			[
				SAssignNew(GalleryDrawerHeader, SBox)
				.HeightOverride(Gallery.DrawerHeaderHeight)
				.ToolTipText(LOCTEXT("GalleryDrawerHeaderHint", "Click to collapse the gallery. Drag to resize (G toggles)."))
				[
					SNew(SOverlay)
					+ SOverlay::Slot().HAlign(HAlign_Fill).VAlign(VAlign_Fill)
					[
						SNew(SButton)
						.ButtonStyle(&Style.GetWidgetStyle<FButtonStyle>(TEXT("Mixtormat.BottomLibraryCollapseButton")))
						.ContentPadding(FMargin(0.0f))
						.OnClicked(this, &SMixtormat::ToggleBottomLibraryCollapsed)
						[
							SNew(SHorizontalBox)
							+ SHorizontalBox::Slot().FillWidth(1.0f).VAlign(VAlign_Center)
							.Padding(Gallery.CaptionInset, 0.0f)
							[
								SNew(STextBlock)
								.Text(LOCTEXT("GalleryDrawerHeading", "GALLERY"))
								.TextStyle(&Style.GetWidgetStyle<FTextBlockStyle>(TEXT("Mixtormat.GroupButtonText")))
							]
						]
					]
					+ SOverlay::Slot().HAlign(HAlign_Center).VAlign(VAlign_Center)
					[
						SNew(SBox)
						.WidthOverride(Gallery.DrawerHeaderGripSize)
						.HeightOverride(Gallery.DrawerHeaderGripSize)
						[
							SNew(SImage)
							.Image(MixtormatIcons::Grip())
							.Visibility(EVisibility::HitTestInvisible)
							.ColorAndOpacity_Lambda([this]()
							{
								const bool bHovered = GalleryDrawerHeader.IsValid() && GalleryDrawerHeader->IsHovered();
								const FLinearColor Color = FMixtormatThemeStore::GetResolved().Palette.Get(
									bHovered ? Mixtormat::EMixtormatColorRole::Accent : Mixtormat::EMixtormatColorRole::TextMuted);
								return FSlateColor(Color.CopyWithNewOpacity(bHovered ? 0.9f : 0.35f));
							})
						]
					]
					+ SOverlay::Slot().HAlign(HAlign_Right).VAlign(VAlign_Center)
					[
						SNew(SMixtormatIconButton)
						.Role(Mixtormat::EMixtormatIconRole::GalleryToolbar)
						.Icon(MixtormatIcons::Pin())
						.bActive_Lambda([this]() { return bGalleryPinned; })
						.ToolTip_Lambda([this]()
						{
							return bGalleryPinned
								? LOCTEXT("UnpinGalleryHint", "Unpin gallery; it will collapse when the pointer leaves")
								: LOCTEXT("PinGalleryHint", "Pin gallery open");
						})
						.OnClicked(FSimpleDelegate::CreateLambda([this]()
						{
							bGalleryPinned = !bGalleryPinned;
							if (bGalleryPinned)
							{
								GalleryDrawerHeight = GetGalleryOpenHeight();
								bGalleryCursorPeek = false;
							}
							PersistGalleryPinState();
							Invalidate(EInvalidateWidgetReason::Paint);
						}))
					]
				]
				]
			+ SVerticalBox::Slot().FillHeight(1.0f)
			[
				SNew(SSplitter)
				.Style(&MixtormatShell::GetSplitterStyle())
				.PhysicalSplitterHandleSize(FMixtormatThemeStore::GetResolved().ControlLayout.HairlineThickness)
				.HitDetectionSplitterHandleSize(FMixtormatThemeStore::GetResolved().ShellLayout.SplitterHitWidth)
				+ SSplitter::Slot()
				.Value_Lambda([this]() { return GalleryColumnFraction; })
				.OnSlotResized_Lambda([this](float Value)
				{
					if (!bSuppressSplitWriteBack)
					{
						GalleryColumnFraction = Value;
					}
				})
				[
					SNew(SVerticalBox)
					+ SVerticalBox::Slot().AutoHeight()[BuildLibraryPage()]
					+ SVerticalBox::Slot().FillHeight(1.0f).Padding(Gallery.TilePadding)[BuildSurfaceList()]
				]
				+ SSplitter::Slot()
				.Value_Lambda([this]() { return 1.0f - GalleryColumnFraction; })
				[
					BuildMaskBar()
				]
			]
	]
];
return Drawer;
}

TSharedRef<SWidget> SMixtormat::BuildLibraryPage()
{
	const ISlateStyle& Style = FMixtormatStyle::Get();
	const bool bHasDeveloperSources =
		!FMixtormatSurfaceImporter::EnumerateShippedSourceDirectories().IsEmpty();
	const TSharedRef<SEditableTextBox> SearchEdit = SNew(SEditableTextBox)
		.Style(&Style.GetWidgetStyle<FEditableTextBoxStyle>(TEXT("Mixtormat.TextField")))
		.HintText(LOCTEXT("SearchHint", "Search materials..."))
		.OnTextChanged_Lambda([this](const FText& Text)
		{
			// Restoring the text during a style rebuild must not rebuild the old surface list.
			if (SearchText != Text.ToString())
			{
				HandleSearchChanged(Text);
			}
		});
	SearchEdit->SetText(FText::FromString(SearchText));
	const TSharedRef<SWidget> SearchBox = SNew(SMixtormatWellBox)
	[
		SNew(SMixtormatTextFieldGradient)
		[
			SNew(SBox)
			.MinDesiredHeight(FMixtormatThemeStore::GetTheme().TextField.MinHeight)
			.MinDesiredWidth(FMixtormatThemeStore::GetTheme().TextField.MinWidth)
			[SearchEdit]
		]
	];

	// The two developer actions beside the category dropdown. Their gaps come from the gallery's own
	// spacing rather than the legacy 3px RowGap, which left two 30px buttons almost touching.
	const Mixtormat::FMixtormatResolvedStyle& LibraryStyle = FMixtormatThemeStore::GetResolved();

	return SNew(SBorder)
		.Padding(FMixtormatThemeStore::GetResolved().GalleryLayout.TilePadding)
		.BorderImage(FCoreStyle::Get().GetBrush(TEXT("WhiteBrush")))
		.BorderBackgroundColor(FLinearColor::Transparent)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)
				.Padding(0.0f, 0.0f, LibraryStyle.ControlLayout.RowLabelGap, 0.0f)
			[
				SNew(STextBlock)
				.Text(LOCTEXT("MaterialGalleryHeading", "MATERIALS"))
				.TextStyle(&Style.GetWidgetStyle<FTextBlockStyle>(TEXT("Mixtormat.GroupButtonText")))
			]
			+ SHorizontalBox::Slot().FillWidth(1.0f).VAlign(VAlign_Center).Padding(0.0f, 0.0f, FMixtormatThemeStore::GetResolved().ControlLayout.RowLabelGap, 0.0f)
			[
				SNew(SBox).HeightOverride(LibraryStyle.Buttons.Height)[SearchBox]
			]
			+ SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)
			[
				SNew(SBox).HeightOverride(LibraryStyle.Buttons.Height)
				[
				SNew(SMixtormatChip)
				.ToolTip(LOCTEXT("MaterialCategoryFilterHint", "Filter materials by category"))
				.Text_Lambda([this]()
				{
					return CategoryFilter.IsNone() ? LOCTEXT("AllMaterialCategories", "All") : FText::FromName(CategoryFilter);
				})
				.OnGetMenuContent_Lambda([this]()
				{
					TArray<FName> Families;
					for (const FMixtormatSurfaceEntry& Surface : FMixtormatRegistry::GetSurfaces())
					{
						if (!MixtormatUI::IsUserLibraryAsset(Surface.AssetPath))
						{
							Families.AddUnique(Surface.Family);
						}
					}
					Families.Remove(NAME_None);
					Families.Sort([](const FName& A, const FName& B) { return A.LexicalLess(B); });

					MixtormatMenu::FBuilder Menu;
					Menu.Caption(LOCTEXT("MaterialCategoryMenuCaption", "MATERIALS"));
					Menu.Item(LOCTEXT("AllCategory", "All Materials"), nullptr,
						FSimpleDelegate::CreateLambda([this]() { SetCategoryFilter(NAME_None); }))
						.Checked(TAttribute<bool>::CreateLambda([this]() { return CategoryFilter.IsNone(); }));
					for (const FName Family : Families)
					{
						Menu.Item(FText::FromName(Family), nullptr,
							FSimpleDelegate::CreateLambda([this, Family]() { SetCategoryFilter(Family); }))
							.Checked(TAttribute<bool>::CreateLambda([this, Family]() { return CategoryFilter == Family; }));
					}
					return SNew(SBox)
						.MaxDesiredHeight(FMixtormatThemeStore::GetResolved().GalleryLayout.DrawerInitialHeight)
						[
							SNew(SScrollBox)
							.ScrollBarStyle(&FMixtormatStyle::Get().GetWidgetStyle<FScrollBarStyle>(TEXT("Mixtormat.ScrollBar")))
							.ScrollBarThickness(FVector2D(FMixtormatThemeStore::GetResolved().ShellLayout.ScrollbarThickness))
							+ SScrollBox::Slot()[Menu.Build()]
						];
				})
				]
			]
			+ SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(
				LibraryStyle.GalleryLayout.TileGap, 0.0f, 0.0f, 0.0f)
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot().AutoWidth().Padding(0.0f, 0.0f, LibraryStyle.GalleryLayout.TileGap, 0.0f)
				[
					SNew(SMixtormatIconButton)
					.Visibility(bHasDeveloperSources ? EVisibility::Visible : EVisibility::Collapsed)
					.Role(Mixtormat::EMixtormatIconRole::GalleryToolbar)
					.Icon(MixtormatIcons::Refresh())
					.ToolTip(LOCTEXT("RefreshLibraryHint", "Refresh Library"))
					.OnClicked(FSimpleDelegate::CreateLambda([this]() { RefreshSurfaceList(); }))
				]
				+ SHorizontalBox::Slot().AutoWidth()
				[
					SNew(SMixtormatIconButton)
					.Visibility(bHasDeveloperSources ? EVisibility::Visible : EVisibility::Collapsed)
					.Role(Mixtormat::EMixtormatIconRole::GalleryToolbar)
					.Icon(MixtormatIcons::Settings())
					.ToolTip(LOCTEXT("RebuildBuiltInLibraryHint", "Developer only: rebuild built-in assets from plugin source PNGs"))
					.OnClicked(FSimpleDelegate::CreateLambda([this]() { RebuildBuiltInLibrary(); }))
				]
			]
		];
}

TSharedRef<SWidget> SMixtormat::BuildSurfaceList()
{
	return SNew(SMixtormatGalleryScrollBox)
		.Orientation(Orient_Vertical)
		.OnGalleryZoom(this, &SMixtormat::ZoomMaterialGallery)
		[
			SAssignNew(SurfaceListBox, SWrapBox)
			.UseAllottedSize(true)
			.InnerSlotPadding(FVector2D(
				FMixtormatThemeStore::GetResolved().GalleryLayout.TileGap,
				FMixtormatThemeStore::GetResolved().GalleryLayout.TileGap))
		];
}

TSharedRef<SWidget> SMixtormat::BuildSurfaceCard(
	const FText& Name,
	const FSoftObjectPath& AssetPath,
	const FAssetData& ThumbnailAsset)
{
	return SNew(SMixtormatSurfaceCard)
		.DisplayName(Name)
		.SurfacePath(AssetPath)
		.ThumbnailAsset(ThumbnailAsset)
		.ThumbnailPool(ThumbnailPool)
		.OnSelected(this, &SMixtormat::SelectSurface)
		.OnGalleryZoom(this, &SMixtormat::ZoomMaterialGallery)
		.OnGetContextMenu(this, &SMixtormat::BuildSurfaceLibraryContextMenu, AssetPath)
		[
			SNew(SOverlay)
			+ SOverlay::Slot()
			[
				SNew(SMixtormatTile)
				.TileSize(MaterialGalleryTileSize)
				.DisplayName(Name)
				.ThumbnailAsset(ThumbnailAsset)
				.ThumbnailPool(ThumbnailPool)
				.bShowName(false)
				.bShowNameOnHover(false)
				.bSelected_Lambda([this, AssetPath]() { return SelectedSurfacePath == AssetPath; })
			]
			+ SOverlay::Slot().HAlign(HAlign_Right).VAlign(VAlign_Bottom)
			.Padding(FMixtormatThemeStore::GetResolved().GalleryLayout.OverlayInset)
			[
				MixtormatUI::BuildLibraryOwnershipBadge(AssetPath)
			]
		];
}

TSharedRef<SWidget> SMixtormat::BuildSurfaceLibraryContextMenu(const FSoftObjectPath AssetPath)
{
	const bool bIsUserAsset = MixtormatUI::IsUserLibraryAsset(AssetPath);
	const UMixtormatSurface* Surface = Cast<UMixtormatSurface>(AssetPath.TryLoad());
	const bool bCanDeveloperRefresh = !bIsUserAsset
		&& Surface
		&& !Surface->SourceTextureBaseName.IsEmpty()
		&& !FMixtormatSurfaceImporter::EnumerateShippedSourceDirectories().IsEmpty();
	MixtormatMenu::FBuilder Menu;
	Menu.Caption(LOCTEXT("LibraryMaterialContextCaption", "Library Material"))
		.Item(
			LOCTEXT("AddLibraryMaterialLayer", "Add as Material Layer"),
			MixtormatIcons::Add(),
			FSimpleDelegate::CreateSP(this, &SMixtormat::AddSurfaceFromLibrary, AssetPath))
		.Item(
			LOCTEXT("BrowseLibraryMaterial", "Show in Content Browser"),
			MixtormatIcons::Folder(),
			FSimpleDelegate::CreateSP(this, &SMixtormat::BrowseLibraryAsset, AssetPath));
	if (bCanDeveloperRefresh)
	{
		Menu.Item(
			LOCTEXT("RefreshBuiltInMaterial", "Developer: Refresh / Reimport from Source"),
			MixtormatIcons::Refresh(),
			FSimpleDelegate::CreateSP(this, &SMixtormat::RefreshBuiltInSurface, AssetPath));
	}
	if (!bIsUserAsset && FMixtormatSurfaceImporter::CanDeleteShippedSurface(AssetPath))
	{
		Menu.Item(
			LOCTEXT("DeleteBuiltInMaterial", "Developer: Delete Material…"),
			MixtormatIcons::Trash(),
			FSimpleDelegate::CreateSP(this, &SMixtormat::DeleteBuiltInSurface, AssetPath))
			.Destructive();
	}
	Menu.Separator()
		.Item(
			LOCTEXT("RemoveImportedMaterial", "Remove Imported Material…"),
			MixtormatIcons::Trash(),
			FSimpleDelegate::CreateSP(this, &SMixtormat::RemoveImportedSurface, AssetPath))
		.Enabled(bIsUserAsset)
		.Destructive();
	return Menu.Build();
}

void SMixtormat::RefreshBuiltInSurface(const FSoftObjectPath AssetPath)
{
	const FMixtormatImportResult Result =
		FMixtormatSurfaceImporter::ReimportShippedSurface(AssetPath);
	RebuildCategoryList();
	RebuildSurfaceList();
	RebuildUserLibraryList();

	const bool bSucceeded = Result.Errors.IsEmpty();
	WorkingStatusText = bSucceeded
		? TEXT("Developer material refresh completed")
		: TEXT("Developer material refresh failed");
	if (bSucceeded && bSuppressDeveloperRefreshSuccessDialog)
	{
		return;
	}

	bool bSuppressSuccessFeedback = false;
	TSharedPtr<SWindow> FeedbackWindow;
	SAssignNew(FeedbackWindow, SWindow)
		.Title(LOCTEXT("DeveloperRefreshResultTitle", "Material Refresh"))
		.ClientSize(FVector2D(
			FMixtormatThemeStore::GetResolved().ControlLayout.FeedbackDialogWidth,
			FMixtormatThemeStore::GetResolved().ControlLayout.FeedbackDialogHeight))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		[
			SNew(SBorder)
			.Padding(FMixtormatThemeStore::GetResolved().ControlLayout.DialogPadding)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot().FillHeight(1.0f)
				[
					SNew(STextBlock)
					.Text(Result.ToMessage())
					.AutoWrapText(true)
				]
				+ SVerticalBox::Slot().AutoHeight().Padding(0.0f, 12.0f)
				[
					SNew(SCheckBox)
					.IsChecked(ECheckBoxState::Unchecked)
					.OnCheckStateChanged_Lambda([&bSuppressSuccessFeedback](const ECheckBoxState State)
					{
						bSuppressSuccessFeedback = State == ECheckBoxState::Checked;
					})
					[
						SNew(STextBlock)
						.Text(LOCTEXT(
							"SuppressDeveloperRefreshSuccess",
							"Don't show successful refresh feedback again this session"))
					]
				]
				+ SVerticalBox::Slot().AutoHeight().HAlign(HAlign_Right)
				[
					SNew(SButton)
					.Text(LOCTEXT("CloseDeveloperRefreshResult", "OK"))
					.OnClicked_Lambda([&FeedbackWindow]()
					{
						FeedbackWindow->RequestDestroyWindow();
						return FReply::Handled();
					})
				]
			]
		];
	FSlateApplication::Get().AddModalWindow(
		FeedbackWindow.ToSharedRef(),
		FSlateApplication::Get().FindWidgetWindow(AsShared()),
		false);
	bSuppressDeveloperRefreshSuccessDialog |= bSuppressSuccessFeedback;
}

TSharedRef<SWidget> SMixtormat::BuildCompositionLibraryContextMenu(const FSoftObjectPath AssetPath)
{
	MixtormatMenu::FBuilder Menu;
	// References keep the recipe live; the other actions import its layers or its existing bake.
	// Nothing is baked here: the shared compositor belongs to the open document.
	const UMixtormatMaterial* Composition = Cast<UMixtormatMaterial>(AssetPath.TryLoad());
	const bool bHasBakedSurface = Composition && !Composition->BakedSurface.IsNull();
	Menu.Caption(LOCTEXT("SavedMixContextCaption", "Saved Mix"))
		.Item(
			LOCTEXT("AddCompositionReferenceLayer", "Add as Reference Layer"),
			MixtormatIcons::Add(),
			FSimpleDelegate::CreateSP(this, &SMixtormat::AddReferenceLayerFromComposition, AssetPath))
		.Enabled(Composition != nullptr)
		.Item(
			LOCTEXT("AddCompositionLayers", "Add All Layers"),
			MixtormatIcons::Add(),
			FSimpleDelegate::CreateSP(this, &SMixtormat::AddCompositionLayers, AssetPath))
		.Item(
			LOCTEXT("AddCompositionBakedLayer", "Add as Baked Layer"),
			MixtormatIcons::LayerMaterial(),
			FSimpleDelegate::CreateSP(this, &SMixtormat::AddBakedLayerFromComposition, AssetPath))
		.Enabled(bHasBakedSurface)
		.Item(
			LOCTEXT("BrowseComposition", "Show in Content Browser"),
			MixtormatIcons::Folder(),
			FSimpleDelegate::CreateSP(this, &SMixtormat::BrowseLibraryAsset, AssetPath));
	return Menu.Build();
}

void SMixtormat::AddSurfaceFromLibrary(const FSoftObjectPath AssetPath)
{
	const UMixtormatSurface* Surface = Cast<UMixtormatSurface>(AssetPath.TryLoad());
	if (!Surface)
	{
		WorkingStatusText = TEXT("Library surface could not be loaded");
		return;
	}
	const FText DisplayName = Surface->DisplayName.IsEmpty()
		? FText::FromString(Surface->GetName())
		: Surface->DisplayName;
	HandleSurfaceDropped(DisplayName, AssetPath);
}

// The flattened counterpart to AddCompositionLayers: one layer sourcing the mix's own baked
// surface, instead of every layer that produced it. Per-pixel F0 is the one thing that does not
// survive the bake -- it shared the alpha the height now occupies -- so the surface stands in
// with a single IOR.
void SMixtormat::AddBakedLayerFromComposition(const FSoftObjectPath AssetPath)
{
	const UMixtormatMaterial* Composition = Cast<UMixtormatMaterial>(AssetPath.TryLoad());
	if (!Composition)
	{
		WorkingStatusText = TEXT("Saved mix could not be loaded");
		return;
	}
	if (Composition->BakedSurface.IsNull())
	{
		WorkingStatusText = TEXT("Saved mix has no bake yet · bake it first");
		return;
	}
	const UMixtormatSurface* Surface = Composition->BakedSurface.LoadSynchronous();
	if (!Surface)
	{
		WorkingStatusText = TEXT("Baked surface is missing from disk");
		return;
	}

	const FText DisplayName = Composition->DisplayName.IsEmpty()
		? FText::FromString(Composition->GetName())
		: Composition->DisplayName;
	// Same path a library surface takes when it is dropped onto the stack: select it, then add
	// one Material layer that sources it.
	HandleSurfaceDropped(DisplayName, FSoftObjectPath(Surface));
}

void SMixtormat::AddReferenceLayerFromComposition(const FSoftObjectPath AssetPath)
{
	const UMixtormatMaterial* Composition = Cast<UMixtormatMaterial>(AssetPath.TryLoad());
	if (!Composition)
	{
		WorkingStatusText = TEXT("Saved mix could not be loaded");
		return;
	}

	TArray<FMixtormatLayer> ReferenceLayers;
	FMixtormatLayer& Reference = ReferenceLayers.AddDefaulted_GetRef();
	Reference.Type = EMixtormatLayerType::Material;
	Reference.SourceSurface.Reset();
	Reference.SourceComposition = TSoftObjectPtr<UMixtormatMaterial>(AssetPath);
	Reference.DisplayName = Composition->DisplayName.IsEmpty()
		? FText::FromString(Composition->GetName())
		: Composition->DisplayName;

	FText ReferenceError;
	const FSoftObjectPath OwnerPath = bHasWorkingMaterial && WorkingMaterialAsset.IsValid()
		? FSoftObjectPath(WorkingMaterialAsset.Get()) : FSoftObjectPath();
	if (!MixtormatCompositionReferences::Validate(ReferenceLayers, OwnerPath, ReferenceError))
	{
		WorkingStatusText = ReferenceError.ToString();
		return;
	}

	const bool bCreateDocument = !bHasWorkingMaterial;
	if (bCreateDocument)
	{
		bHasWorkingMaterial = true;
		WorkingMaterialAsset.Reset();
		WorkingMaterialName = TEXT("Untitled Mixtormat Material");
		WorkingLayers.Reset();
		// The isolated source already includes its own document rotation.
		bGlobalUVRotation90 = false;
		for (const TSharedPtr<SMixtormatPreviewViewport>& Viewport : PreviewViewports)
		{
			if (Viewport.IsValid())
			{
				Viewport->SetGlobalUVRotation90(false);
			}
		}
		SavedLayers.Reset();
	}

	WorkingLayers.Append(MoveTemp(ReferenceLayers));
	if (bCreateDocument)
	{
		ResetEditHistory(false);
	}
	SoloLayerIndex = INDEX_NONE;
	bShowCompositionBefore = false;
	DebugPreviewMode = EMixtormatDebugPreviewMode::None;
	SelectedLayerIndex = WorkingLayers.Num() - 1;
	SetLayerExpanded(SelectedLayerIndex, false);
	SelectedEffectIndex = INDEX_NONE;
	SelectedMaskIndex = INDEX_NONE;
	bHasSelectedLayer = true;
	SyncChildInstances();
	SyncSelectedLayerControls();
	RefreshLayeredPreview(!bCreateDocument);
	bIsWorkingMaterialDirty = true;
	WorkingStatusText = FString::Printf(TEXT("Added reference to %s"), *Composition->GetName());
	RebuildLayerList();
	RebuildMaskList();
}

void SMixtormat::AddCompositionLayers(const FSoftObjectPath AssetPath)
{
	const UMixtormatMaterial* Composition = Cast<UMixtormatMaterial>(AssetPath.TryLoad());
	if (!Composition || Composition->Layers.IsEmpty())
	{
		WorkingStatusText = TEXT("Saved mix has no layers");
		return;
	}

	TArray<FMixtormatLayer> ImportedLayers = Composition->Layers;
	TArray<FMixtormatLayerGroup> ImportedGroups = Composition->LayerGroups;
	MixtormatParameterBinding::RegenerateLayerIdentities(ImportedLayers, ImportedGroups);
	const int32 FirstImportedLayer = bHasWorkingMaterial ? WorkingLayers.Num() : 0;

	if (bHasWorkingMaterial)
	{
		WorkingLayers.Append(MoveTemp(ImportedLayers));
		WorkingLayerGroups.Append(MoveTemp(ImportedGroups));
	}
	else
	{
		bHasWorkingMaterial = true;
		WorkingMaterialAsset.Reset();
		WorkingMaterialName = TEXT("Untitled Mixtormat Material");
		WorkingLayers = MoveTemp(ImportedLayers);
		WorkingLayerGroups = MoveTemp(ImportedGroups);
		bGlobalUVRotation90 = Composition->bRotateUV90;
		WorkingFinalSettings = Composition->FinalSettings;
		for (const TSharedPtr<SMixtormatPreviewViewport>& Viewport : PreviewViewports)
		{
			if (Viewport.IsValid())
			{
				Viewport->SetGlobalUVRotation90(bGlobalUVRotation90);
			}
		}
		SavedLayers.Reset();
		SavedLayerGroups.Reset();
		ResetEditHistory(false);
	}

	SoloLayerIndex = INDEX_NONE;
	bShowCompositionBefore = false;
	DebugPreviewMode = EMixtormatDebugPreviewMode::None;
	SelectedLayerIndex = FirstImportedLayer;
	SelectedEffectIndex = INDEX_NONE;
	SelectedMaskIndex = INDEX_NONE;
	bHasSelectedLayer = WorkingLayers.IsValidIndex(SelectedLayerIndex);
	SyncChildInstances();
	SyncSelectedLayerControls();
	RefreshLayeredPreview(false);
	bIsWorkingMaterialDirty = true;
	WorkingStatusText = FString::Printf(
		TEXT("Added %d layers from %s"),
		Composition->Layers.Num(),
		*Composition->GetName());
	RebuildLayerList();
	RebuildMaskList();
}

void SMixtormat::BrowseLibraryAsset(const FSoftObjectPath AssetPath)
{
	FAssetRegistryModule& AssetRegistryModule =
		FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	const FAssetData Asset = AssetRegistryModule.Get().GetAssetByObjectPath(AssetPath);
	if (!Asset.IsValid())
	{
		return;
	}

	FContentBrowserModule& ContentBrowserModule =
		FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));
	ContentBrowserModule.Get().SyncBrowserToAssets({Asset});
}

void SMixtormat::DeleteBuiltInSurface(const FSoftObjectPath AssetPath)
{
	if (!MixtormatParameterUi::IsDeveloperMetaEnabled()
		|| !FMixtormatSurfaceImporter::CanDeleteShippedSurface(AssetPath))
	{
		return;
	}
	const UMixtormatSurface* Surface = Cast<UMixtormatSurface>(AssetPath.TryLoad());
	if (!Surface)
	{
		RefreshSurfaceList();
		WorkingStatusText = TEXT("Developer material deletion failed: surface could not be loaded");
		return;
	}
	const FText MaterialName = Surface->DisplayName.IsEmpty()
		? FText::FromString(Surface->GetName()) : Surface->DisplayName;
	bool bConfirmed = false;
	TSharedPtr<SWindow> ConfirmationWindow;
	TSharedPtr<SButton> CancelButton;
	SAssignNew(ConfirmationWindow, SWindow)
		.Title(LOCTEXT("DeleteBuiltInMaterialTitle", "Delete Built-In Material"))
		.ClientSize(FVector2D(
			FMixtormatThemeStore::GetResolved().ControlLayout.ConfirmDialogWidth,
			FMixtormatThemeStore::GetResolved().ControlLayout.ConfirmDialogHeight))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		[
			SNew(SBorder)
			.Padding(FMixtormatThemeStore::GetResolved().ControlLayout.DialogPadding)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot().FillHeight(1.0f)
				[
					SNew(STextBlock)
					.Text(FText::Format(LOCTEXT("DeleteBuiltInMaterialConfirmation",
						"Permanently delete '{0}'?\n\nThis deletes:\n- shipped source texture files\n- generated Mixtormat surface asset\n- imported textures (including packed-height variants)\n- preview material instance\n- thumbnail\n\nRebuilding the built-in library will NOT restore this material unless its source files are added again. The open composition will not be edited."), MaterialName))
					.AutoWrapText(true)
				]
				+ SVerticalBox::Slot().AutoHeight().HAlign(HAlign_Right)
					.Padding(0.0f, MixtormatTokens::DialogActionsTopMargin, 0.0f, 0.0f)
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot().AutoWidth()
					[
						SAssignNew(CancelButton, SButton)
						.Text(LOCTEXT("CancelDeleteBuiltInMaterial", "Cancel"))
						.OnClicked_Lambda([&ConfirmationWindow]()
						{
							ConfirmationWindow->RequestDestroyWindow();
							return FReply::Handled();
						})
					]
					+ SHorizontalBox::Slot().AutoWidth().Padding(FMixtormatThemeStore::GetResolved().ControlLayout.DialogButtonGap, 0.0f, 0.0f, 0.0f)
					[
						SNew(SButton)
						.Text(LOCTEXT("ConfirmDeleteBuiltInMaterial", "Delete Material"))
						.OnClicked_Lambda([&ConfirmationWindow, &bConfirmed]()
						{
							bConfirmed = true;
							ConfirmationWindow->RequestDestroyWindow();
							return FReply::Handled();
						})
					]
				]
			]
		];
	ConfirmationWindow->SetWidgetToFocusOnActivate(CancelButton);
	FSlateApplication::Get().AddModalWindow(ConfirmationWindow.ToSharedRef(),
		FSlateApplication::Get().FindWidgetWindow(AsShared()), false);
	if (!bConfirmed)
	{
		return;
	}

	const FMixtormatSurfaceDeletionResult Result = FMixtormatSurfaceImporter::DeleteShippedSurface(AssetPath);
	if (Result.bSurfaceDeleted && SelectedSurfacePath == AssetPath)
	{
		SelectedSurfacePath.Reset();
		SelectedLibrarySurfaceName = FText::GetEmpty();
		SelectedPreviewMaterial.Reset();
	}
	RebuildCategoryList();
	RebuildSurfaceList();
	RebuildUserLibraryList();
	WorkingStatusText = Result.Errors.IsEmpty()
		? TEXT("Developer material deleted") : TEXT("Developer material deletion failed");
	if (!Result.Errors.IsEmpty())
	{
		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(FString::Join(Result.Errors, TEXT("\n"))));
	}
}

void SMixtormat::RemoveImportedSurface(const FSoftObjectPath AssetPath)
{
	if (!MixtormatUI::IsUserLibraryAsset(AssetPath))
	{
		return;
	}

	UMixtormatSurface* Surface = Cast<UMixtormatSurface>(AssetPath.TryLoad());
	if (!Surface)
	{
		RefreshSurfaceList();
		RebuildUserLibraryList();
		return;
	}

	TArray<FAssetData> Assets;
	const auto AddUserAsset = [&Assets](UObject* Asset)
	{
		if (Asset && MixtormatUI::IsUserLibraryAsset(FSoftObjectPath(Asset->GetPathName())))
		{
			Assets.AddUnique(FAssetData(Asset));
		}
	};
	AddUserAsset(Surface);
	AddUserAsset(Surface->PreviewMaterial);
	AddUserAsset(Surface->Thumbnail);
	AddUserAsset(Surface->BaseColor);
	AddUserAsset(Surface->Normal);
	AddUserAsset(Surface->RoughnessAOMetallic);

	if (!Surface->SourceTextureBaseName.IsEmpty() && Surface->BaseColor)
	{
		const FString TextureRoot = FPackageName::GetLongPackagePath(
			Surface->BaseColor->GetOutermost()->GetName());
		const TCHAR* PackedSuffixes[] = {TEXT("_RAM"), TEXT("_RAMH"), TEXT("_RAMH_Derived")};
		for (const TCHAR* Suffix : PackedSuffixes)
		{
			const FString AssetName = ObjectTools::SanitizeObjectName(
				Surface->SourceTextureBaseName + Suffix);
			const FString ObjectPath = FString::Printf(
				TEXT("%s/%s.%s"), *TextureRoot, *AssetName, *AssetName);
			AddUserAsset(LoadObject<UObject>(nullptr, *ObjectPath));
		}
	}

	ObjectTools::DeleteAssets(Assets, true);
	if (SelectedSurfacePath == AssetPath)
	{
		FAssetRegistryModule& AssetRegistryModule =
			FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
		if (!AssetRegistryModule.Get().GetAssetByObjectPath(AssetPath).IsValid())
		{
			SelectedSurfacePath.Reset();
			SelectedLibrarySurfaceName = FText::GetEmpty();
			SelectedPreviewMaterial.Reset();
		}
	}
	RefreshSurfaceList();
	RebuildUserLibraryList();
}

#undef LOCTEXT_NAMESPACE
