// Copyright 2026 Hugo Beyer. All Rights Reserved.

#include "Widgets/SMixtormat.h"
#include "MixtormatEditorSettings.h"
#include "MixtormatLayerGroups.h"
#include "MixtormatParameterBinding.h"
#include "Services/MixtormatPaths.h"
#include "Widgets/Dialogs/SMixtormatActionDialog.h"
#include "Widgets/Dialogs/SMixtormatBakeResultDialog.h"
#include "Widgets/Dialogs/SMixtormatBakeSettingsDialog.h"
#include "Widgets/SMixtormatInternal.h"

// Material lifecycle: new/open/save, import, composition resolution, and baking.

#define LOCTEXT_NAMESPACE "SMixtormat"

FReply SMixtormat::ImportSurfaces()
{
	const FMixtormatImportResult Result = FMixtormatSurfaceImporter::ImportFromDialog();
	if (!Result.bCancelled)
	{
		FMessageDialog::Open(EAppMsgType::Ok, Result.ToMessage());
		RebuildCategoryList();
		RebuildSurfaceList();
		RebuildUserLibraryList();
	}
	return FReply::Handled();
}

FReply SMixtormat::ImportMasks()
{
	const FMixtormatImportResult Result = FMixtormatSurfaceImporter::ImportMasksFromDialog();
	if (!Result.bCancelled)
	{
		FMessageDialog::Open(EAppMsgType::Ok, Result.ToMessage());
		RebuildMaskList();
	}
	return FReply::Handled();
}

FReply SMixtormat::RebuildBuiltInLibrary()
{
	const FMixtormatImportResult Result = FMixtormatSurfaceImporter::ReimportShippedLibrary();
	RebuildCategoryList();
	RebuildSurfaceList();
	RebuildUserLibraryList();
	RebuildMaskList();
	FMessageDialog::Open(EAppMsgType::Ok, Result.ToMessage());
	return FReply::Handled();
}


FReply SMixtormat::StartNewMaterial()
{
	return StartNewMaterialWith(EMixtormatLayerType::Material);
}

FReply SMixtormat::StartNewMaterialWith(const EMixtormatLayerType LayerType)
{
	const bool bMaterial = LayerType == EMixtormatLayerType::Material;
	if (bMaterial && !SelectedPreviewMaterial.IsValid())
	{
		return FReply::Handled();
	}

	bHasWorkingMaterial = true;
	WorkingMaterialAsset.Reset();
	WorkingMaterialName = TEXT("Untitled Mixtormat Material");
	SoloLayerIndex = INDEX_NONE;
	bShowCompositionBefore = false;
	bGlobalUVRotation90 = false;
	WorkingFinalSettings = FMixtormatFinalSettings();
	bAutomaticFlowPreview = false;
	DebugPreviewMode = EMixtormatDebugPreviewMode::None;
	CollapsedGeneratorAddresses.Reset();
	ChildRowWidgets.Reset();
	AmbiguousChildRowAddresses.Reset();
	WorkingLayers.Reset();
	WorkingLayerGroups.Reset();
	WorkingSources.Reset();
	SelectedSourceId.Invalidate();
	for (const TSharedPtr<SMixtormatPreviewViewport>& Viewport : PreviewViewports)
	{
		if (Viewport.IsValid())
		{
			Viewport->SetGlobalUVRotation90(false);
		}
	}

	// The first layer of a new recipe -- an ordinary layer, not a privileged base.
	FMixtormatLayer& FirstLayer = WorkingLayers.AddDefaulted_GetRef();
	if (!bMaterial)
	{
		InitializeNewLayer(FirstLayer, LayerType, 1);
	}
	else
	{
		FirstLayer.DisplayName = SelectedLibrarySurfaceName;
		FirstLayer.Type = EMixtormatLayerType::Material;
		FirstLayer.SourceSurface = TSoftObjectPtr<UMixtormatSurface>(SelectedSurfacePath);
		FirstLayer.Tiling = CurrentTiling;
		FirstLayer.RoughnessBias = CurrentRoughnessBias;
		FirstLayer.RoughnessContrast = CurrentRoughnessContrast;
		FirstLayer.RoughnessOffset = CurrentRoughnessOffset;
	}

	SelectedLayerIndex = 0;
	SelectedEffectIndex = INDEX_NONE;
	SelectedMaskIndex = INDEX_NONE;
	bHasSelectedLayer = true;
	if (bMaterial && SelectedSurfaceText.IsValid())
	{
		SelectedSurfaceText->SetText(SelectedLibrarySurfaceName);
	}
	SavedLayers.Reset();
	SavedLayerGroups.Reset();
	// Same reset its neighbours get: a stale saved snapshot would misreport the dirty state
	// against the sources this new document does not have.
	SavedSources.Reset();
	ResetEditHistory(false);
	bIsWorkingMaterialDirty = true;
	RefreshLayeredPreview(false);
	WorkingStatusText = TEXT("New material · unsaved");
	RebuildLayerList();
	RebuildMaskList();
	RebuildSourcesList();
	return FReply::Handled();
}

FReply SMixtormat::NewWorkingMaterial()
{
	if (!ConfirmDiscardUnsavedChanges())
	{
		return FReply::Handled();
	}

	bHasWorkingMaterial = false;
	bHasSelectedLayer = false;
	bIsWorkingMaterialDirty = false;
	SelectedLayerIndex = INDEX_NONE;
	SelectedEffectIndex = INDEX_NONE;
	SelectedMaskIndex = INDEX_NONE;
	SoloLayerIndex = INDEX_NONE;
	bShowCompositionBefore = false;
	bGlobalUVRotation90 = false;
	bSavedGlobalUVRotation90 = false;
	bAutomaticFlowPreview = false;
	DebugPreviewMode = EMixtormatDebugPreviewMode::None;
	CollapsedGeneratorAddresses.Reset();
	ChildRowWidgets.Reset();
	AmbiguousChildRowAddresses.Reset();
	WorkingLayers.Reset();
	WorkingLayerGroups.Reset();
	WorkingSources.Reset();
	SelectedSourceId.Invalidate();
	SavedLayers.Reset();
	SavedLayerGroups.Reset();
	WorkingMaterialAsset.Reset();
	for (const TSharedPtr<SMixtormatPreviewViewport>& Viewport : PreviewViewports)
	{
		if (Viewport.IsValid())
		{
			Viewport->SetGlobalUVRotation90(false);
		}
	}
	ResetEditHistory(true);
	WorkingMaterialName = TEXT("No material");
	WorkingStatusText = TEXT("Select a library material, then drag it into Layers");
	if (bPreviewDisplacementEnabled)
	{
		PreviewSelectedSurfaceWithDisplacement();
	}
	else if (SelectedPreviewMaterial.IsValid())
	{
		for (const TSharedPtr<SMixtormatPreviewViewport>& Viewport : PreviewViewports)
		{
			if (Viewport.IsValid())
			{
				Viewport->SetPreviewMaterial(SelectedPreviewMaterial.Get());
			}
		}
	}
	RebuildLayerList();
	RebuildMaskList();
	return FReply::Handled();
}

FReply SMixtormat::OpenWorkingMaterial()
{
	if (!ConfirmDiscardUnsavedChanges())
	{
		return FReply::Handled();
	}

	FOpenAssetDialogConfig DialogConfig;
	DialogConfig.DialogTitleOverride = LOCTEXT("OpenMixtormatMaterial", "Open Mixtormat Material");
	DialogConfig.DefaultPath = TEXT("/Game");
	DialogConfig.AssetClassNames.Add(UMixtormatMaterial::StaticClass()->GetClassPathName());
	DialogConfig.bAllowMultipleSelection = false;

	FContentBrowserModule& ContentBrowserModule =
		FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));
	const TArray<FAssetData> Assets =
		ContentBrowserModule.Get().CreateModalOpenAssetDialog(DialogConfig);
	if (Assets.IsEmpty())
	{
		return FReply::Handled();
	}

	UMixtormatMaterial* MaterialAsset = Cast<UMixtormatMaterial>(Assets[0].GetAsset());
	if (!MaterialAsset || MaterialAsset->Layers.IsEmpty())
	{
		FMessageDialog::Open(
			EAppMsgType::Ok,
			LOCTEXT("InvalidMixtormatMaterial", "The selected recipe has no layers."));
		return FReply::Handled();
	}

	WorkingMaterialAsset.Reset(MaterialAsset);
	CollapsedGeneratorAddresses.Reset();
	ChildRowWidgets.Reset();
	AmbiguousChildRowAddresses.Reset();
	WorkingLayers = MaterialAsset->Layers;
	WorkingLayerGroups = MaterialAsset->LayerGroups;
	WorkingSources = MaterialAsset->Sources;
	SelectedSourceId.Invalidate();
	bGlobalUVRotation90 = MaterialAsset->bRotateUV90;
	WorkingFinalSettings = MaterialAsset->FinalSettings;
	for (const TSharedPtr<SMixtormatPreviewViewport>& Viewport : PreviewViewports)
	{
		if (Viewport.IsValid())
		{
			Viewport->SetGlobalUVRotation90(bGlobalUVRotation90);
		}
	}
	MixtormatParameterBinding::EnsureStableIds(WorkingLayers, WorkingLayerGroups, WorkingSources);
	// The asset repairs itself on load, but a working copy can also come from an older in-memory
	// edit, so reconcile membership against the layers actually opened.
	MixtormatLayerGroups::ValidateGroups(WorkingLayers, WorkingLayerGroups);
	SoloLayerIndex = INDEX_NONE;
	bShowCompositionBefore = false;
	bAutomaticFlowPreview = false;
	DebugPreviewMode = EMixtormatDebugPreviewMode::None;
	WorkingMaterialName = MaterialAsset->DisplayName.IsEmpty()
		? MaterialAsset->GetName()
		: MaterialAsset->DisplayName.ToString();
	bHasWorkingMaterial = true;
	SelectedLayerIndex = 0;
	SelectedEffectIndex = INDEX_NONE;
	SelectedMaskIndex = INDEX_NONE;
	bHasSelectedLayer = true;

	if (const UMixtormatSurface* FirstSurface = WorkingLayers[0].SourceSurface.LoadSynchronous())
	{
		SelectedSurfacePath = WorkingLayers[0].SourceSurface.ToSoftObjectPath();
		SelectedLibrarySurfaceName = WorkingLayers[0].DisplayName;
		SelectedPreviewMaterial.Reset(Cast<UMaterialInstanceConstant>(FirstSurface->PreviewMaterial.Get()));
	}

	SyncSelectedLayerControls();
	ResetEditHistory(true);
	RefreshLayeredPreview(false);
	bIsWorkingMaterialDirty = false;
	WorkingStatusText = FString::Printf(TEXT("Opened %s"), *WorkingMaterialName);
	RebuildLayerList();
	RebuildMaskList();
	RebuildSourcesList();
	return FReply::Handled();
}

FReply SMixtormat::SaveWorkingMaterial()
{
	if (!bHasWorkingMaterial)
	{
		return FReply::Handled();
	}
	if (!WorkingMaterialAsset.IsValid())
	{
		return SaveWorkingMaterialAs();
	}

	UMixtormatMaterial* MaterialAsset = WorkingMaterialAsset.Get();
	FText ReferenceError;
	if (!MixtormatCompositionReferences::Validate(
		WorkingLayers, FSoftObjectPath(MaterialAsset), ReferenceError))
	{
		WorkingStatusText = ReferenceError.ToString();
		return FReply::Handled();
	}
	MaterialAsset->Modify();
	MaterialAsset->DisplayName = FText::FromString(WorkingMaterialName);
	MaterialAsset->Layers = WorkingLayers;
	MaterialAsset->LayerGroups = WorkingLayerGroups;
	MaterialAsset->Sources = WorkingSources;
	MaterialAsset->bRotateUV90 = bGlobalUVRotation90;
	MaterialAsset->FinalSettings = WorkingFinalSettings;
	MaterialAsset->MarkPackageDirty();
	bool bSaved = false;
	if (UEditorAssetSubsystem* AssetSubsystem = GEditor->GetEditorSubsystem<UEditorAssetSubsystem>())
	{
		bSaved = AssetSubsystem->SaveLoadedAsset(MaterialAsset, false);
	}
	bIsWorkingMaterialDirty = !bSaved;
	if (bSaved)
	{
		SavedLayers = WorkingLayers;
		SavedLayerGroups = WorkingLayerGroups;
		SavedSources = WorkingSources;
		bSavedGlobalUVRotation90 = bGlobalUVRotation90;
		SavedFinalSettings = WorkingFinalSettings;
		CurrentHistoryState.Layers = WorkingLayers;
		CurrentHistoryState.Groups = WorkingLayerGroups;
		CurrentHistoryState.Sources = WorkingSources;
		CurrentHistoryState.bRotateUV90 = bGlobalUVRotation90;
	}
	WorkingStatusText = bSaved
		? FString::Printf(TEXT("Saved %s"), *WorkingMaterialName)
		: TEXT("Save failed");
	if (bSaved)
	{
		RebuildUserLibraryList();
	}
	return FReply::Handled();
}

FReply SMixtormat::SaveWorkingMaterialAs()
{
	if (!bHasWorkingMaterial)
	{
		return FReply::Handled();
	}

	FSaveAssetDialogConfig DialogConfig;
	DialogConfig.DialogTitleOverride = LOCTEXT("SaveMixtormatMaterialAs", "Save Mixtormat Material As");
	DialogConfig.DefaultPath = FMixtormatPaths::ProjectMaterialsRoot();
	DialogConfig.DefaultAssetName = TEXT("Mixtormat_Untitled");
	DialogConfig.AssetClassNames.Add(UMixtormatMaterial::StaticClass()->GetClassPathName());
	DialogConfig.ExistingAssetPolicy = ESaveAssetDialogExistingAssetPolicy::Disallow;

	FContentBrowserModule& ContentBrowserModule =
		FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));
	const FString ObjectPath = ContentBrowserModule.Get().CreateModalSaveAssetDialog(DialogConfig);
	if (ObjectPath.IsEmpty())
	{
		return FReply::Handled();
	}

	FText ReferenceError;
	if (!MixtormatCompositionReferences::Validate(
		WorkingLayers, FSoftObjectPath(ObjectPath), ReferenceError))
	{
		WorkingStatusText = ReferenceError.ToString();
		return FReply::Handled();
	}

	const FString PackageName = FPackageName::ObjectPathToPackageName(ObjectPath);
	const FString AssetName = FPackageName::ObjectPathToObjectName(ObjectPath);
	UPackage* Package = CreatePackage(*PackageName);
	UMixtormatMaterial* MaterialAsset = Package
		? NewObject<UMixtormatMaterial>(
			Package,
			*AssetName,
			RF_Public | RF_Standalone | RF_Transactional)
		: nullptr;
	if (!MaterialAsset)
	{
		WorkingStatusText = FString::Printf(TEXT("Save failed · %s"), *ObjectPath);
		return FReply::Handled();
	}
	FAssetRegistryModule::AssetCreated(MaterialAsset);

	WorkingMaterialAsset.Reset(MaterialAsset);
	WorkingMaterialName = MaterialAsset->GetName();
	MaterialAsset->Modify();
	MaterialAsset->DisplayName = FText::FromString(WorkingMaterialName);
	MaterialAsset->Layers = WorkingLayers;
	MaterialAsset->LayerGroups = WorkingLayerGroups;
	MaterialAsset->Sources = WorkingSources;
	MaterialAsset->bRotateUV90 = bGlobalUVRotation90;
	MaterialAsset->FinalSettings = WorkingFinalSettings;
	MaterialAsset->MarkPackageDirty();
	bool bSaved = false;
	if (UEditorAssetSubsystem* AssetSubsystem = GEditor->GetEditorSubsystem<UEditorAssetSubsystem>())
	{
		bSaved = AssetSubsystem->SaveLoadedAsset(MaterialAsset, false);
	}
	bIsWorkingMaterialDirty = !bSaved;
	if (bSaved)
	{
		SavedLayers = WorkingLayers;
		SavedLayerGroups = WorkingLayerGroups;
		SavedSources = WorkingSources;
		bSavedGlobalUVRotation90 = bGlobalUVRotation90;
		SavedFinalSettings = WorkingFinalSettings;
		CurrentHistoryState.Layers = WorkingLayers;
		CurrentHistoryState.Groups = WorkingLayerGroups;
		CurrentHistoryState.Sources = WorkingSources;
		CurrentHistoryState.bRotateUV90 = bGlobalUVRotation90;
	}
	WorkingStatusText = bSaved
		? FString::Printf(TEXT("Saved %s"), *WorkingMaterialName)
		: TEXT("Save failed");
	if (bSaved)
	{
		RebuildUserLibraryList();
	}
	return FReply::Handled();
}

FReply SMixtormat::SetCompositionResolution(const int32 Resolution)
{
	if (Resolution == 1024 || Resolution == 2048 || Resolution == 4096)
	{
		CompositionResolution = Resolution;
		WorkingStatusText = FString::Printf(
			TEXT("Preview and bake resolution: %d × %d"),
			CompositionResolution,
			CompositionResolution);
		RefreshLayeredPreview(false);
	}
	FSlateApplication::Get().DismissAllMenus();
	return FReply::Handled();
}

FReply SMixtormat::BakeWorkingMaterial()
{
	if (!WorkingMaterialAsset.IsValid())
	{
		FMessageDialog::Open(
			EAppMsgType::Ok,
			LOCTEXT("SaveBeforeBake", "Save the Mixtormat recipe before baking."));
		return FReply::Handled();
	}

	const FSoftObjectPath RecipePath(WorkingMaterialAsset.Get());
	if (BakeSettingsRecipePath != RecipePath)
	{
		BakeSettingsRecipePath = RecipePath;
		BakeOutputBaseName = WorkingMaterialAsset->GetName();
		const UMixtormatEditorSettings* EditorSettings = GetDefault<UMixtormatEditorSettings>();
		FString DestinationRoot = EditorSettings->DefaultBakeOutputPath;
		while (DestinationRoot.RemoveFromEnd(TEXT("/"))) {}
		BakeDestinationPath = FString::Printf(
			TEXT("%s/%s"),
			*DestinationRoot,
			*WorkingMaterialAsset->GetName());
		BakeResolution = MixtormatBakeResolutionToPixels(EditorSettings->DefaultBakeResolution);
		BakeAASamples = MixtormatBakeAASamplesToInt(EditorSettings->DefaultBakeAASamples);
	}

	TSharedPtr<SMixtormatBakeSettingsDialog> SettingsDialog;
	const TSharedRef<SWindow> SettingsWindow = SNew(SWindow)
		.Title(LOCTEXT("BakeSettingsTitle", "Bake Material"))
		.ClientSize(FVector2D(
			FMixtormatThemeStore::GetResolved().ControlLayout.BakeSettingsDialogWidth,
			FMixtormatThemeStore::GetResolved().ControlLayout.BakeSettingsDialogHeight))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		[
			SAssignNew(SettingsDialog, SMixtormatBakeSettingsDialog)
			.InitialSettings(FMixtormatBakeSettings{BakeDestinationPath, BakeOutputBaseName, BakeResolution, BakeAASamples})
		];
	FSlateApplication::Get().AddModalWindow(
		SettingsWindow,
		FSlateApplication::Get().FindWidgetWindow(AsShared()),
		false);
	if (!SettingsDialog->WasAccepted())
	{
		WorkingStatusText = TEXT("Bake canceled");
		return FReply::Handled();
	}

	const FMixtormatBakeSettings Settings = SettingsDialog->GetSettings();
	BakeDestinationPath = Settings.DestinationPath;
	BakeOutputBaseName = Settings.BaseName;
	BakeResolution = Settings.Resolution;
	BakeAASamples = Settings.AASamples;
	return ExecuteBake(Settings, true);
}

FReply SMixtormat::ExecuteBake(
	const FMixtormatBakeSettings& Settings,
	const bool bConfirmExistingOutputs)
{
	if (!WorkingMaterialAsset.IsValid())
	{
		FMessageDialog::Open(
			EAppMsgType::Ok,
			LOCTEXT("MissingRebakeRecipe", "Re-bake stopped because the recipe is no longer available."));
		return FReply::Handled();
	}

	const TArray<FString> ExistingOutputs =
		FMixtormatBakeService::FindExistingOutputObjectPaths(Settings);
	if (bConfirmExistingOutputs && !ExistingOutputs.IsEmpty())
	{
		const FText ConflictMessage = FText::Format(
			LOCTEXT(
				"BakeOutputConflict",
				"These outputs already exist:\n\n{0}\n\nUpdate them in place, or cancel without changes."),
			FText::FromString(FString::Join(ExistingOutputs, TEXT("\n"))));
		if (!ShowMixtormatActionDialog(
			AsShared(),
			LOCTEXT("BakeConflictTitle", "Existing Bake Outputs"),
			ConflictMessage,
			LOCTEXT("UpdateBakeOutputs", "Update Existing"),
			LOCTEXT("CancelBakeConflict", "Cancel")))
		{
			WorkingStatusText = TEXT("Bake canceled · existing outputs unchanged");
			return FReply::Handled();
		}
	}

	SaveWorkingMaterial();
	if (bIsWorkingMaterialDirty || PreviewViewports.IsEmpty() || !PreviewViewports[0].IsValid())
	{
		FMessageDialog::Open(
			EAppMsgType::Ok,
			LOCTEXT("BakeSaveFailed", "Bake stopped because the recipe could not be saved."));
		return FReply::Handled();
	}

	FMixtormatBakeResult Result;
	{
		TGuardValue<bool> BakingGuard(bIsBaking, true);
		FScopedSlowTask SlowTask(5.0f, LOCTEXT("BakeProgressTitle", "Baking Mixtormat outputs..."));
		SlowTask.MakeDialog(false);
		WorkingStatusText = TEXT("Bake · Compose");
		SlowTask.EnterProgressFrame(1.0f, LOCTEXT("BakeStageCompose", "Compose"));
		// Bake-only resolution, independent of CompositionResolution (the live preview). Composing
		// at it temporarily resizes the shared compositor's render targets, but RefreshLayeredPreview
		// below puts them back to CompositionResolution before the viewport is shown again.
		if (!PreviewViewports[0]->ComposeLayersAtResolution(
			WorkingLayers, WorkingLayerGroups, Settings.Resolution, WorkingSources))
		{
			RefreshLayeredPreview(false);
			FMessageDialog::Open(
				EAppMsgType::Ok,
				LOCTEXT("BakeComposeFailed", "Compose failed. Check the current recipe and compositor output."));
			WorkingStatusText = TEXT("Bake failed · Compose");
			return FReply::Handled();
		}

		UTextureRenderTarget2D* BaseColor = PreviewViewports[0]->GetCompositedBaseColor();
		UTextureRenderTarget2D* Normal = PreviewViewports[0]->GetCompositedNormal();
		UTextureRenderTarget2D* RAM = PreviewViewports[0]->GetCompositedRAM();
		UTextureRenderTarget2D* Height = PreviewViewports[0]->GetCompositedHeight();
		if (!BaseColor || !Normal || !RAM || !Height)
		{
			RefreshLayeredPreview(false);
			FMessageDialog::Open(
				EAppMsgType::Ok,
				LOCTEXT("MissingBakeOutputs", "Readback cannot start because the GPU compositor has no valid outputs."));
			WorkingStatusText = TEXT("Bake failed · Readback");
			return FReply::Handled();
		}

		const auto ReportProgress = [this, &SlowTask](const EMixtormatBakeStage Stage)
		{
			FText StageText;
			switch (Stage)
			{
			case EMixtormatBakeStage::Readback:
				StageText = LOCTEXT("BakeStageReadback", "Readback");
				break;
			case EMixtormatBakeStage::CreateTextures:
				StageText = LOCTEXT("BakeStageCreateTextures", "Create Textures");
				break;
			case EMixtormatBakeStage::CreateMaterial:
				StageText = LOCTEXT("BakeStageCreateMaterial", "Create Material");
				break;
			default:
				StageText = LOCTEXT("BakeStageSave", "Save");
				break;
			}
			WorkingStatusText = FString::Printf(TEXT("Bake · %s"), *StageText.ToString());
			SlowTask.EnterProgressFrame(1.0f, StageText);
		};
		Result = FMixtormatBakeService::Bake(
			*WorkingMaterialAsset.Get(),
			*BaseColor,
			*Normal,
			*RAM,
			*Height,
			Settings,
			ReportProgress);
	}

	RefreshLayeredPreview(false);
	if (!Result.Succeeded())
	{
		FString ErrorText = TEXT("Bake failed:\n\n");
		for (const FText& Error : Result.Errors)
		{
			if (!ErrorText.EndsWith(TEXT("\n\n")))
			{
				ErrorText += TEXT("\n");
			}
			ErrorText += FString::Printf(TEXT("• %s"), *Error.ToString());
		}

		const auto AppendAssetPaths = [&ErrorText](
			const TCHAR* Heading,
			const TArray<FString>& AssetPaths)
		{
			if (AssetPaths.IsEmpty())
			{
				return;
			}
			ErrorText += FString::Printf(TEXT("\n\n%s\n"), Heading);
			for (const FString& AssetPath : AssetPaths)
			{
				ErrorText += FString::Printf(TEXT("• %s\n"), *AssetPath);
			}
		};
		AppendAssetPaths(TEXT("Created in memory:"), Result.CreatedAssetPaths);
		AppendAssetPaths(TEXT("Updated in memory:"), Result.UpdatedAssetPaths);
		AppendAssetPaths(TEXT("Saved successfully:"), Result.SavedAssetPaths);
		AppendAssetPaths(TEXT("Failed or incomplete:"), Result.FailedAssetPaths);

		FMessageDialog::Open(EAppMsgType::Ok, FText::FromString(ErrorText));
		WorkingStatusText = TEXT("Bake failed · review reported asset paths");
		return FReply::Handled();
	}

	const TArray<FString> OutputPaths = FMixtormatBakeService::GetOutputObjectPaths(Settings);
	const FText SuccessMessage = FText::Format(
		LOCTEXT(
			"BakeSucceeded",
			"Bake completed successfully:\n\n{0}"),
		FText::FromString(FString::Join(OutputPaths, TEXT("\n"))));
	WorkingStatusText = FString::Printf(
		TEXT("Baked %s · 5 outputs saved"),
		*Settings.BaseName);

	switch (ShowMixtormatBakeResultDialog(AsShared(), SuccessMessage))
	{
	case EMixtormatBakeResultAction::Reveal:
	{
		TArray<FAssetData> Assets;
		Assets.Reserve(5);
		Assets.Add(FAssetData(Result.BaseColor));
		Assets.Add(FAssetData(Result.Normal));
		Assets.Add(FAssetData(Result.RAM));
		Assets.Add(FAssetData(Result.Height));
		Assets.Add(FAssetData(Result.Material));
		FContentBrowserModule& ContentBrowserModule =
			FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));
		ContentBrowserModule.Get().SyncBrowserToAssets(Assets);
		WorkingStatusText += TEXT(" · revealed in Content Browser");
		break;
	}
	case EMixtormatBakeResultAction::Open:
	{
		UAssetEditorSubsystem* AssetEditorSubsystem = GEditor
			? GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()
			: nullptr;
		if (!AssetEditorSubsystem || !AssetEditorSubsystem->OpenEditorForAsset(Result.Material))
		{
			FMessageDialog::Open(
				EAppMsgType::Ok,
				FText::Format(
					LOCTEXT("OpenBakedMaterialFailed", "Could not open {0}."),
					FText::FromString(Result.Material->GetPathName())));
			WorkingStatusText += TEXT(" · material instance could not be opened");
		}
		else
		{
			WorkingStatusText += TEXT(" · material instance opened");
		}
		break;
	}
	case EMixtormatBakeResultAction::Apply:
		ApplyBakedMaterialToSelectedActors(*Result.Material);
		break;
	case EMixtormatBakeResultAction::Rebake:
		return ExecuteBake(Settings, false);
	default:
		break;
	}
	return FReply::Handled();
}

void SMixtormat::ApplyBakedMaterialToSelectedActors(UMaterialInterface& Material)
{
	struct FMaterialAssignment
	{
		AActor* Actor = nullptr;
		UMeshComponent* Component = nullptr;
		int32 SlotIndex = INDEX_NONE;
	};

	USelection* SelectedActors = GEditor ? GEditor->GetSelectedActors() : nullptr;
	if (!SelectedActors)
	{
		FMessageDialog::Open(
			EAppMsgType::Ok,
			LOCTEXT("ApplyBakeNoSelection", "Select one or more actors with material slots first."));
		return;
	}

	TArray<FMaterialAssignment> Assignments;
	TSet<AActor*> TargetActors;
	int32 ReplacementCount = 0;
	int32 AlreadyAssignedCount = 0;
	for (FSelectionIterator SelectionIt(*SelectedActors); SelectionIt; ++SelectionIt)
	{
		AActor* Actor = Cast<AActor>(*SelectionIt);
		if (!IsValid(Actor))
		{
			continue;
		}

		TArray<UMeshComponent*> MeshComponents;
		Actor->GetComponents<UMeshComponent>(MeshComponents);
		for (UMeshComponent* Component : MeshComponents)
		{
			if (!IsValid(Component))
			{
				continue;
			}
			for (int32 SlotIndex = 0; SlotIndex < Component->GetNumMaterials(); ++SlotIndex)
			{
				UMaterialInterface* ExistingMaterial = Component->GetMaterial(SlotIndex);
				if (ExistingMaterial == &Material)
				{
					++AlreadyAssignedCount;
					continue;
				}
				ReplacementCount += ExistingMaterial ? 1 : 0;
				Assignments.Add({Actor, Component, SlotIndex});
				TargetActors.Add(Actor);
			}
		}
	}

	if (Assignments.IsEmpty())
	{
		FMessageDialog::Open(
			EAppMsgType::Ok,
			AlreadyAssignedCount > 0
				? LOCTEXT("ApplyBakeAlreadyAssigned", "The baked material is already assigned to the selected actors.")
				: LOCTEXT("ApplyBakeNoSlots", "The selected actors have no compatible material slots."));
		return;
	}

	if (ReplacementCount > 0)
	{
		const FText Confirmation = FText::Format(
			LOCTEXT(
				"ConfirmReplaceSelectedMaterials",
				"Applying {0} will replace {1} existing material assignment(s) across {2} selected actor(s).\n\nCancel preserves every current assignment."),
			FText::FromString(Material.GetPathName()),
			FText::AsNumber(ReplacementCount),
			FText::AsNumber(TargetActors.Num()));
		if (!ShowMixtormatActionDialog(
			AsShared(),
			LOCTEXT("ReplaceSelectedMaterialsTitle", "Replace Existing Materials?"),
			Confirmation,
			LOCTEXT("ReplaceAndApplyBakedMaterial", "Replace and Apply"),
			LOCTEXT("CancelApplyBakedMaterial", "Cancel")))
		{
			WorkingStatusText = TEXT("Apply canceled · actor materials unchanged");
			return;
		}
	}

	const FScopedTransaction Transaction(LOCTEXT("ApplyBakedMaterialTransaction", "Apply Baked Material"));
	TSet<UMeshComponent*> ModifiedComponents;
	for (const FMaterialAssignment& Assignment : Assignments)
	{
		if (!ModifiedComponents.Contains(Assignment.Component))
		{
			Assignment.Component->Modify();
			ModifiedComponents.Add(Assignment.Component);
		}
		Assignment.Actor->Modify();
		Assignment.Component->SetMaterial(Assignment.SlotIndex, &Material);
	}
	for (UMeshComponent* Component : ModifiedComponents)
	{
		Component->PostEditChange();
	}
	for (AActor* Actor : TargetActors)
	{
		Actor->PostEditChange();
		Actor->MarkPackageDirty();
	}

	WorkingStatusText = FString::Printf(
		TEXT("Applied %s · %d slot(s) on %d actor(s) · Undo available"),
		*Material.GetName(),
		Assignments.Num(),
		TargetActors.Num());
}

bool SMixtormat::CanCloseTab()
{
	return ConfirmDiscardUnsavedChanges();
}

bool SMixtormat::ConfirmDiscardUnsavedChanges()
{
	if (!bIsWorkingMaterialDirty)
	{
		return true;
	}

	const EAppReturnType::Type Choice = FMessageDialog::Open(
		EAppMsgType::YesNoCancel,
		LOCTEXT(
			"SaveUnsavedMaterialChanges",
			"Save changes to the current Mixtormat recipe?\n\nYes: Save\nNo: Discard\nCancel: Keep editing"));
	if (Choice == EAppReturnType::Yes)
	{
		SaveWorkingMaterial();
		return !bIsWorkingMaterialDirty;
	}
	return Choice == EAppReturnType::No;
}

#undef LOCTEXT_NAMESPACE
