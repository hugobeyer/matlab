// Copyright 2026 Hugo Beyer. All Rights Reserved.

#include "UI/Parameters/MixtormatParameterAuthoring.h"


#include "UI/Parameters/MixtormatParameterUiMeta.h"
#include "MixtormatParameterBinding.h"
#include "Containers/StringConv.h"
#include "Interfaces/IPluginManager.h"
#include "Logging/LogMacros.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "HAL/PlatformFile.h"
#include "UObject/UnrealType.h"

namespace
{
	// UEnum entry names are fully qualified ("EMixtormatEffectType::Breakup"); the inner
	// name is the stable short spelling used in serialized keys and Category prefixes.
	FString InnerNameOf(const UEnum* Enum, const int64 Value)
	{
		const FString FullName = Enum->GetNameByValue(Value).ToString();
		const int32 Separator = FullName.Find(TEXT("::"));
		return Separator != INDEX_NONE ? FullName.Mid(Separator + 2) : FullName;
	}

	// The canonical family spelling: the enum's inner name, which for every family is also
	// the UPROPERTY Category prefix the database sections use.
	FString FamilyKeyOf(EMixtormatEffectType Family)
	{
		return InnerNameOf(StaticEnum<EMixtormatEffectType>(), static_cast<int64>(Family));
	}

	const UScriptStruct* StructForKey(const FMixtormatParameterDefinitionKey& Key)
	{
		for (const UScriptStruct* Struct : MixtormatParameterBinding::GetOwnerStructs(Key.Owner))
		{
			if (Struct->FindPropertyByName(Key.Parameter))
			{
				return Struct;
			}
		}
		return nullptr;
	}

	const FProperty* PropertyForKey(const FMixtormatParameterDefinitionKey& Key)
	{
		const UStruct* Struct = StructForKey(Key);
		return Struct ? Struct->FindPropertyByName(Key.Parameter) : nullptr;
	}

	const UEnum* EnumForProperty(const FProperty* Property)
	{
		if (const FEnumProperty* EnumProperty = CastField<FEnumProperty>(Property))
		{
			return EnumProperty->GetEnum();
		}
		if (const FByteProperty* ByteProperty = CastField<FByteProperty>(Property))
		{
			return ByteProperty->Enum;
		}
		return nullptr;
	}

	int64 ReadEnumValue(const FProperty* Property, const void* Container)
	{
		if (const FEnumProperty* EnumProperty = CastField<FEnumProperty>(Property))
		{
			return EnumProperty->GetUnderlyingProperty()->GetSignedIntPropertyValue(
				EnumProperty->ContainerPtrToValuePtr<void>(Container));
		}
		if (const FByteProperty* ByteProperty = CastField<FByteProperty>(Property);
			ByteProperty && ByteProperty->Enum)
		{
			return ByteProperty->GetPropertyValue(
				ByteProperty->ContainerPtrToValuePtr<uint8>(Container));
		}
		return INDEX_NONE;
	}

	void WriteEnumValue(const FProperty* Property, void* Container, const int64 Value)
	{
		if (const FEnumProperty* EnumProperty = CastField<FEnumProperty>(Property))
		{
			EnumProperty->GetUnderlyingProperty()->SetIntPropertyValue(
				EnumProperty->ContainerPtrToValuePtr<void>(Container), Value);
		}
		else if (const FByteProperty* ByteProperty = CastField<FByteProperty>(Property);
			ByteProperty && ByteProperty->Enum)
		{
			ByteProperty->SetPropertyValue(
				ByteProperty->ContainerPtrToValuePtr<uint8>(Container), static_cast<uint8>(Value));
		}
	}

	FName EnumEntryName(const UEnum* Enum, const int64 Value)
	{
		return Enum ? FName(*InnerNameOf(Enum, Value)) : NAME_None;
	}

	int64 EnumValueByEntryName(const UEnum* Enum, const FName EntryName)
	{
		if (!Enum || EntryName.IsNone())
		{
			return INDEX_NONE;
		}
		const int64 Value = Enum->GetValueByNameString(EntryName.ToString());
		return Value != INDEX_NONE
			&& EnumEntryName(Enum, Value) == EntryName
			? Value : INDEX_NONE;
	}

	FString FamilyForKey(const FMixtormatParameterDefinitionKey& Key)
	{
		if (const FProperty* Property = PropertyForKey(Key))
		{
			FString Family = Property->GetMetaData(TEXT("Category"));
			const int32 Pipe = Family.Find(TEXT("|"));
			if (Pipe != INDEX_NONE)
			{
				Family.LeftChopInline(Family.Len() - Pipe);
			}
			return Family;
		}
		return Key.Owner == EMixtormatParameterOwnerType::Generator
			? TEXT("Generator") : TEXT("Unknown");
	}

	// Category prefixes name families. Comparison also ignores the display space so the
	// enum's inner name ("WornEdges") matches the Category spelling ("Worn Edges|Output").
	bool CategoryMatchesFamily(const FString& Category, const FString& Family)
	{
		return Category.StartsWith(Family)
			|| Category.Replace(TEXT(" "), TEXT("")).StartsWith(Family);
	}

	// "Effect.BreakupNormalStrength" / "Effect.BreakupSeed:Int" -- owner segment and short
	// inner value-type spelling, matching LoadFromString's last-dot + ":Int" parse.
	FString KeyNameOf(const FMixtormatParameterDefinitionKey& Key)
	{
		FString Name = InnerNameOf(
			StaticEnum<EMixtormatParameterOwnerType>(), static_cast<int64>(Key.Owner));
		Name += TEXT(".");
		Name += Key.Parameter.ToString();
		if (Key.ValueType != EMixtormatParameterValueType::Float)
		{
			Name += TEXT(":");
			Name += InnerNameOf(
				StaticEnum<EMixtormatParameterValueType>(), static_cast<int64>(Key.ValueType));
		}
		return Name;
	}

	TOptional<float> ReadFloat(const TSharedPtr<FJsonValue>& Value)
	{
		// FJsonValue exposes its discriminated union as Type, not as IsNumber-style queries.
		if (!Value.IsValid() || Value->Type != EJson::Number)
		{
			return {};
		}
		return static_cast<float>(Value->AsNumber());
	}

	void WriteFloat(TSharedRef<FJsonObject> Object, const TCHAR* Field, const TOptional<float>& Value)
	{
		if (Value.IsSet())
		{
			Object->SetNumberField(Field, static_cast<double>(Value.GetValue()));
		}
		else
		{
			Object->RemoveField(Field);
		}
	}

	TOptional<float> ReadFloatField(const TSharedPtr<FJsonObject>& Object, const TCHAR* Field)
	{
		return ReadFloat(Object->TryGetField(Field));
	}

	// The shipped database, loaded lazily from the plugin JSON. Function-local statics keep
	// the file read to once per session and keep the mutable state out of global ctors.
	TMap<FMixtormatParameterDefinitionKey, FMixtormatParameterAuthoringEntry>& ShippedEntries()
	{
		static TMap<FMixtormatParameterDefinitionKey, FMixtormatParameterAuthoringEntry> Map;
		return Map;
	}

	TMap<FMixtormatParameterDefinitionKey, FMixtormatParameterAuthoringEntry>& PendingEntries()
	{
		static TMap<FMixtormatParameterDefinitionKey, FMixtormatParameterAuthoringEntry> Map;
		return Map;
	}

	// Once a load has happened -- from disk or from a string (tests) -- the database must not
	// be silently replaced by the file on the next failed lookup.
	bool& DatabaseLoaded()
	{
		static bool bLoaded = false;
		return bLoaded;
	}

	// A corrupt or missing shipped file must not be parsed again for every
	// visible Inspector attribute on every Slate paint.
	bool& DatabaseLoadAttempted()
	{
		static bool bAttempted = false;
		return bAttempted;
	}

	const FMixtormatParameterAuthoringEntry* FindEffective(
		const FMixtormatParameterDefinitionKey& Key)
	{
		MixtormatParameterAuthoring::LoadFromDisk();
		if (const FMixtormatParameterAuthoringEntry* Pending = PendingEntries().Find(Key))
		{
			return Pending;
		}
		return ShippedEntries().Find(Key);
	}
}

namespace MixtormatParameterAuthoring
{
	bool IsPersistentlyEditable(const FMixtormatParameterDefinitionKey& Key)
	{
		if (Key.ValueType == EMixtormatParameterValueType::Enum)
		{
			return ResolveParameterEnum(Key) != nullptr;
		}
		return (Key.ValueType == EMixtormatParameterValueType::Float
			|| Key.ValueType == EMixtormatParameterValueType::Int)
			&& MixtormatParameterUi::TryFindNumericProperty(Key) != nullptr;
	}

	const UEnum* ResolveParameterEnum(const FMixtormatParameterDefinitionKey& Key)
	{
		return Key.ValueType == EMixtormatParameterValueType::Enum
			? EnumForProperty(PropertyForKey(Key)) : nullptr;
	}

	FName ResolveCompiledEnumDefault(const FMixtormatParameterDefinitionKey& Key)
	{
		const UScriptStruct* Struct = StructForKey(Key);
		const FProperty* Property = PropertyForKey(Key);
		const UEnum* Enum = ResolveParameterEnum(Key);
		if (!Struct || !Property || !Enum)
		{
			return NAME_None;
		}
		FStructOnScope Defaults(Struct);
		return EnumEntryName(Enum, ReadEnumValue(Property, Defaults.GetStructMemory()));
	}

	FName ResolveAuthoringEnumDefault(const FMixtormatParameterDefinitionKey& Key)
	{
		LoadFromDisk();
		const FName CompiledDefault = ResolveCompiledEnumDefault(Key);
		if (const FMixtormatParameterAuthoringEntry* Entry = FindEffective(Key);
			Entry && Entry->DefaultEnum.IsSet())
		{
			const UEnum* Enum = ResolveParameterEnum(Key);
			if (EnumValueByEntryName(Enum, Entry->DefaultEnum.GetValue()) != INDEX_NONE)
			{
				return Entry->DefaultEnum.GetValue();
			}
		}
		return CompiledDefault;
	}

	const FMixtormatParameterAuthoringEntry* TryGetShipped(const FMixtormatParameterDefinitionKey& Key)
	{
		LoadFromDisk();
		return ShippedEntries().Find(Key);
	}

	bool HasShippedAuthoring(const FMixtormatParameterDefinitionKey& Key)
	{
		return TryGetShipped(Key) != nullptr;
	}

	const FMixtormatParameterAuthoringEntry* TryGetPending(const FMixtormatParameterDefinitionKey& Key)
	{
		return PendingEntries().Find(Key);
	}

	bool HasPendingAuthoring(const FMixtormatParameterDefinitionKey& Key)
	{
		return PendingEntries().Contains(Key);
	}

	bool HasAnyPendingAuthoring()
	{
		return !PendingEntries().IsEmpty();
	}

	void SetPendingAuthoring(
		const FMixtormatParameterDefinitionKey& Key,
		const FMixtormatParameterAuthoringEntry& Entry)
	{
		// An entry equal to "nothing" clears the pending edit rather than storing it, so the
		// unsaved set only ever contains deltas that mean something.
		if (Entry.IsEmpty())
		{
			PendingEntries().Remove(Key);
		}
		else
		{
			PendingEntries().Add(Key, Entry);
		}
	}

	void RevertPendingAuthoring(const FMixtormatParameterDefinitionKey& Key)
	{
		PendingEntries().Remove(Key);
	}

	bool SavePendingToPluginDefaults()
	{
		if (PendingEntries().IsEmpty())
		{
			return true;
		}
		// Allow an explicit save to retry if the user repaired the JSON on disk.
		// Normal Inspector attribute reads keep failed loads latched for this session.
		if (!DatabaseLoaded())
		{
			DatabaseLoadAttempted() = false;
		}
		// Never rebuild the shipped file from an uninitialized in-memory map.
		// A missing or malformed database must not be silently replaced by pending edits.
		if (!LoadFromDisk())
		{
			UE_LOG(LogTemp, Error,
				TEXT("Mixtormat authoring database: save aborted because existing JSON could not be loaded."));
			return false;
		}
		const auto PreviousEntries = ShippedEntries();
		for (const TPair<FMixtormatParameterDefinitionKey, FMixtormatParameterAuthoringEntry>& Pair
			: PendingEntries())
		{
			if (Pair.Value.IsEmpty())
			{
				ShippedEntries().Remove(Pair.Key);
			}
			else
			{
				ShippedEntries().Add(Pair.Key, Pair.Value);
			}
		}
		// Commit pending only after a successful write: a read-only plugin directory must
		// leave the unsaved edits in memory, not silently drop them.
		if (!SaveToDisk())
		{
			ShippedEntries() = PreviousEntries;
			return false;
		}
		PendingEntries().Reset();
		return true;
	}

	bool RestoreShippedAuthoring(const FMixtormatParameterDefinitionKey& Key)
	{
		if (!DatabaseLoaded())
		{
			DatabaseLoadAttempted() = false;
		}
		if (!LoadFromDisk())
		{
			UE_LOG(LogTemp, Error,
				TEXT("Mixtormat authoring database: restore aborted because existing JSON could not be loaded."));
			return false;
		}
		PendingEntries().Remove(Key);
		FMixtormatParameterAuthoringEntry Removed;
		if (ShippedEntries().RemoveAndCopyValue(Key, Removed) == 0)
		{
			return true; // Nothing shipped: already restored.
		}
		if (!SaveToDisk())
		{
			// Roll the entry back so the in-memory database still matches the file.
			ShippedEntries().Add(Key, MoveTemp(Removed));
			return false;
		}
		return true;
	}

	float ResolveAuthoringDefault(const FMixtormatParameterDefinitionKey& Key, const float FallbackStored)
	{
		if (const FMixtormatParameterAuthoringEntry* Entry = FindEffective(Key))
		{
			if (Entry->Default.IsSet())
			{
				return Entry->Default.GetValue();
			}
		}
		// The compiled default is the CDO initializer, read through reflection.
		return MixtormatParameterUi::ResolveUiDefault(Key, FallbackStored);
	}

	float ResolveAuthoringUiBound(const FMixtormatParameterDefinitionKey& Key, const float Fallback, const bool bMax)
	{
		if (const FMixtormatParameterAuthoringEntry* Entry = FindEffective(Key))
		{
			const TOptional<float> Bound = bMax ? Entry->UiMax : Entry->UiMin;
			if (Bound.IsSet())
			{
				return Bound.GetValue();
			}
		}
		// Falls through to the session override / UiMeta / literal chain.
		return MixtormatParameterUi::ResolveUiBound(Key, Fallback, bMax);
	}

	TOptional<float> ResolveAuthoringClamp(const FMixtormatParameterDefinitionKey& Key, const bool bMax)
	{
		if (const FMixtormatParameterAuthoringEntry* Entry = FindEffective(Key))
		{
			const TOptional<float> Bound = bMax ? Entry->ClampMax : Entry->ClampMin;
			if (Bound.IsSet())
			{
				return Bound;
			}
		}
		if (const FMixtormatParameterContract* Contract = MixtormatParameterContracts::TryGet(Key.Owner, Key.Parameter))
		{
			return bMax ? Contract->HardMax : Contract->HardMin;
		}
		return TOptional<float>();
	}

	float ResolveAuthoringSnap(const FMixtormatParameterDefinitionKey& Key, const float Fallback)
	{
		if (const FMixtormatParameterAuthoringEntry* Entry = FindEffective(Key))
		{
			if (Entry->Snap.IsSet())
			{
				return Entry->Snap.GetValue();
			}
		}
		return MixtormatParameterUi::ResolveUiSnap(Key, Fallback);
	}

	FText ResolveAuthoringLabel(const FMixtormatParameterDefinitionKey& Key, const FText& Fallback)
	{
		if (const FMixtormatParameterAuthoringEntry* Entry = FindEffective(Key))
		{
			if (!Entry->Label.IsEmpty())
			{
				return FText::FromString(Entry->Label);
			}
		}
		return Fallback;
	}

	void ApplyAuthoringDefaults(FMixtormatLayerChild& Child)
	{
		LoadFromDisk();
		EMixtormatEffectType EffectFamily = Child.Effect.ProceduralType;
		if (Child.Type == EMixtormatLayerChildType::Effect && !Child.Effect.Effect.IsNull())
		{
			if (const UMixtormatEffect* Asset = Child.Effect.Effect.LoadSynchronous())
			{
				EffectFamily = Asset->EffectType;
			}
		}
		for (const TPair<FMixtormatParameterDefinitionKey, FMixtormatParameterAuthoringEntry>& Pair
			: ShippedEntries())
		{
			if (Pair.Key.ValueType == EMixtormatParameterValueType::Enum
				? !Pair.Value.DefaultEnum.IsSet()
				: !Pair.Value.Default.IsSet())
			{
				continue;
			}
			const UScriptStruct* Struct = nullptr;
			void* Payload = MixtormatParameterBinding::GetMutableChildOwnerData(
				Child, Pair.Key.Owner, Struct);
			if (!Payload || !Struct)
			{
				continue;
			}
			const FProperty* Property = Struct->FindPropertyByName(Pair.Key.Parameter);
			if (!Property || (Pair.Key.Owner == EMixtormatParameterOwnerType::Effect
				&& !CategoryMatchesFamily(Property->GetMetaData(TEXT("Category")),
					FamilyKeyOf(EffectFamily))))
			{
				continue;
			}
			if (Pair.Key.ValueType == EMixtormatParameterValueType::Enum)
			{
				const UEnum* Enum = EnumForProperty(Property);
				const int64 AuthoredValue = EnumValueByEntryName(
					Enum, Pair.Value.DefaultEnum.GetValue());
				FStructOnScope Defaults(Struct);
				const int64 CompiledValue = ReadEnumValue(Property, Defaults.GetStructMemory());
				WriteEnumValue(Property, Payload,
					AuthoredValue != INDEX_NONE ? AuthoredValue : CompiledValue);
			}
			else if (Pair.Key.ValueType == EMixtormatParameterValueType::Float)
			{
				if (const FFloatProperty* Float = CastField<FFloatProperty>(Property))
				{
					*Float->ContainerPtrToValuePtr<float>(Payload) = Pair.Value.Default.GetValue();
				}
			}
			else if (Pair.Key.ValueType == EMixtormatParameterValueType::Int)
			{
				if (const FIntProperty* Int = CastField<FIntProperty>(Property))
				{
					*Int->ContainerPtrToValuePtr<int32>(Payload) =
						FMath::RoundToInt(Pair.Value.Default.GetValue());
				}
			}
		}
	}


	bool LoadFromString(const FString& Json)
	{
		const TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Json);
		TSharedPtr<FJsonObject> Root;
		if (!FJsonSerializer::Deserialize(Reader, Root) || !Root.IsValid())
		{
			UE_LOG(LogTemp, Warning,
				TEXT("Mixtormat authoring database: unreadable JSON; shipped entries are preserved."));
			return false;
		}

		ShippedEntries().Reset();
		DatabaseLoaded() = true;
		for (const TPair<FString, TSharedPtr<FJsonValue>>& FamilyPair : Root->Values)
		{
			const TSharedPtr<FJsonObject>* FamilyObject;
			if (!FamilyPair.Value->TryGetObject(FamilyObject) || !FamilyObject->IsValid())
			{
				continue;
			}

			// The section name is only a grouping key; its canonical spelling is the UPROPERTY
			// Category prefix, which is exactly what WriteToString emits. Accept it verbatim.
			// Warn when no property answers to it: such entries still load (they key by
			// parameter), but no family can ever match them at apply time.
			bool bSectionMatchesAnyCategory = false;
			const UEnum* OwnerEnum = StaticEnum<EMixtormatParameterOwnerType>();
			for (int32 OwnerIndex = 0; OwnerIndex < OwnerEnum->NumEnums() - 1
				&& !bSectionMatchesAnyCategory; ++OwnerIndex)
			{
				const auto Owner = static_cast<EMixtormatParameterOwnerType>(
					OwnerEnum->GetValueByIndex(OwnerIndex));
				for (const UScriptStruct* Struct : MixtormatParameterBinding::GetOwnerStructs(Owner))
				{
					for (TFieldIterator<FProperty> It(Struct); It; ++It)
					{
						if (CategoryMatchesFamily(It->GetMetaData(TEXT("Category")), FamilyPair.Key))
						{
							bSectionMatchesAnyCategory = true;
							break;
						}
					}
					if (bSectionMatchesAnyCategory)
					{
						break;
					}
				}
			}
			if (!bSectionMatchesAnyCategory)
			{
				UE_LOG(LogTemp, Warning,
					TEXT("Mixtormat authoring database: family section '%s' matches no Category prefix; entries load but apply to no family."),
					*FamilyPair.Key);
			}

			for (const TPair<FString, TSharedPtr<FJsonValue>>& ParamPair : (*FamilyObject)->Values)
			{
				const TSharedPtr<FJsonObject>* EntryObject;
				if (!ParamPair.Value->TryGetObject(EntryObject) || !EntryObject->IsValid())
				{
					continue;
				}

				FMixtormatParameterAuthoringEntry Entry;
				Entry.Label = (*EntryObject)->GetStringField(TEXT("label"));
				Entry.Default = ReadFloatField(*EntryObject, TEXT("default"));
				FString DefaultEnum;
				if ((*EntryObject)->TryGetStringField(TEXT("defaultEnum"), DefaultEnum)
					&& !DefaultEnum.IsEmpty())
				{
					Entry.DefaultEnum = FName(*DefaultEnum);
				}
				Entry.UiMin = ReadFloatField(*EntryObject, TEXT("uiMin"));
				Entry.UiMax = ReadFloatField(*EntryObject, TEXT("uiMax"));
				Entry.Snap = ReadFloatField(*EntryObject, TEXT("snap"));
				Entry.ClampMin = ReadFloatField(*EntryObject, TEXT("clampMin"));
				Entry.ClampMax = ReadFloatField(*EntryObject, TEXT("clampMax"));

				// Value type suffix on the key: ":Int" when not the float default.
				EMixtormatParameterValueType ValueType = EMixtormatParameterValueType::Float;
				FString ParameterName = ParamPair.Key;
				if (ParameterName.EndsWith(TEXT(":Int")))
				{
					ValueType = EMixtormatParameterValueType::Int;
					ParameterName.LeftChopInline(4);
				}
				else if (ParameterName.EndsWith(TEXT(":Enum")))
				{
					ValueType = EMixtormatParameterValueType::Enum;
					ParameterName.LeftChopInline(5);
					// Numeric fields are not a fallback representation for an enum.
					Entry.Default.Reset();
					Entry.UiMin.Reset();
					Entry.UiMax.Reset();
					Entry.Snap.Reset();
					Entry.ClampMin.Reset();
					Entry.ClampMax.Reset();
				}

				// Bare names remain Effect; qualified names resolve through the serialized
				// owner enum spelling rather than a special case for Generator.
				EMixtormatParameterOwnerType Owner = EMixtormatParameterOwnerType::Effect;
				int32 DotIndex = INDEX_NONE;
				if (ParameterName.FindLastChar(TEXT('.'), DotIndex))
				{
					const int64 OwnerValue = StaticEnum<EMixtormatParameterOwnerType>()
						->GetValueByNameString(ParameterName.Left(DotIndex));
					if (OwnerValue == INDEX_NONE)
					{
						continue;
					}
					Owner = static_cast<EMixtormatParameterOwnerType>(OwnerValue);
					ParameterName.RightChopInline(DotIndex + 1);
				}

				FMixtormatParameterDefinitionKey Key;
				Key.Owner = Owner;
				Key.Parameter = FName(*ParameterName);
				Key.ValueType = ValueType;
				if (!Entry.IsEmpty())
				{
					ShippedEntries().Add(Key, MoveTemp(Entry));
				}
			}
		}
		return true;
	}

	FString WriteToString()
	{
		// { "<Family>": { "<Parameter>": { ... } } } -- family-scoped so a future family
		// migration cannot collide with another's parameter block.
		const TSharedRef<FJsonObject> Root = MakeShared<FJsonObject>();
		TMap<FString, TSharedRef<FJsonObject>> Families;

		for (const TPair<FMixtormatParameterDefinitionKey, FMixtormatParameterAuthoringEntry>& Pair
			: ShippedEntries())
		{
			// The Category prefix is the family grouping, straight off the reflected owner struct.
			const FString Family = FamilyForKey(Pair.Key);

			TSharedRef<FJsonObject>* FamilyObject = Families.Find(Family);
			if (!FamilyObject)
			{
				FamilyObject = &Families.Add(Family, MakeShared<FJsonObject>());
			}

			const TSharedRef<FJsonObject> Entry = MakeShared<FJsonObject>();
			if (!Pair.Value.Label.IsEmpty())
			{
				Entry->SetStringField(TEXT("label"), Pair.Value.Label);
			}
			if (Pair.Key.ValueType == EMixtormatParameterValueType::Enum)
			{
				if (Pair.Value.DefaultEnum.IsSet())
				{
					Entry->SetStringField(TEXT("defaultEnum"), Pair.Value.DefaultEnum.GetValue().ToString());
				}
			}
			else
			{
				WriteFloat(Entry, TEXT("default"), Pair.Value.Default);
				WriteFloat(Entry, TEXT("uiMin"), Pair.Value.UiMin);
				WriteFloat(Entry, TEXT("uiMax"), Pair.Value.UiMax);
				WriteFloat(Entry, TEXT("snap"), Pair.Value.Snap);
				WriteFloat(Entry, TEXT("clampMin"), Pair.Value.ClampMin);
				WriteFloat(Entry, TEXT("clampMax"), Pair.Value.ClampMax);
			}
			(*FamilyObject)->SetObjectField(KeyNameOf(Pair.Key), Entry);
		}

		for (const TPair<FString, TSharedRef<FJsonObject>>& Family : Families)
		{
			Root->SetObjectField(Family.Key, Family.Value);
		}

		FString Out;
		const TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Out);
		FJsonSerializer::Serialize(Root, Writer);
		return Out;
	}

	FString GetDatabaseFilePath()
	{
		// Resolved through the plugin manager so the database follows the plugin wherever it
		// is installed (project Plugins/, engine Marketplace copy, mounted from elsewhere).
		if (const TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(TEXT("Mixtormat")))
		{
			return FPaths::Combine(
				Plugin->GetBaseDir(), TEXT("Config"),
				TEXT("MixtormatParameterAuthoring.json"));
		}
		// Fallback for exotic setups where the plugin is not registered under its own name.
		return FPaths::Combine(
			FPaths::ProjectPluginsDir(), TEXT("Mixtormat"), TEXT("Config"),
			TEXT("MixtormatParameterAuthoring.json"));
	}

	bool LoadFromDisk()
	{
		// Loaded once per session: an empty shipped map after a successful load is a valid
		// state (no entries), so the disk is not re-read on every failed lookup.
		if (DatabaseLoaded())
		{
			return true;
		}
		if (DatabaseLoadAttempted())
		{
			return false;
		}
		DatabaseLoadAttempted() = true;
		const FString Path = GetDatabaseFilePath();
		FString Json;
		if (!FFileHelper::LoadFileToString(Json, *Path))
		{
			return false; // Cannot safely overwrite a missing/unreadable shipped database.
		}
		return LoadFromString(Json);
	}

	bool SaveToDisk()
	{
		if (!LoadFromDisk())
		{
			UE_LOG(LogTemp, Error,
				TEXT("Mixtormat authoring database: refusing to write before a valid JSON load."));
			return false;
		}
		// Written as raw UTF-8 bytes (no BOM): SaveStringToFile's write-flag enums have been
		// renamed across engine versions, and encoding the bytes ourselves is stable.
		const FString Path = GetDatabaseFilePath();
		FTCHARToUTF8 Utf8(*WriteToString());
		TArray64<uint8> Bytes;
		Bytes.Append(reinterpret_cast<const uint8*>(Utf8.Get()), Utf8.Length());
		if (!FFileHelper::SaveArrayToFile(Bytes, *Path))
		{
			// Loud and explicit: a read-only plugin directory must fail the save visibly, never
			// silently redirect the database somewhere else.
			UE_LOG(LogTemp, Error,
				TEXT("Mixtormat authoring database: FAILED to write %s -- the plugin directory "
					"may be read-only. Pending changes are still in memory; nothing was saved."),
				*Path);
			return false;
		}
		return true;
	}
}
