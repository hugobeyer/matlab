// Copyright 2026 Hugo Beyer. All Rights Reserved.

#include "UI/Containers/SMixtormatInspectorWell.h"

#include "Style/MixtormatDesignTokens.h"
#include "Style/MixtormatStyle.h"
#include "Style/MixtormatThemeStore.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/SBoxPanel.h"

void SMixtormatInspectorWell::Construct(const FArguments& InArgs)
{
	ChildSlot
	[
		SNew(SBorder)
		.BorderImage(FMixtormatStyle::Get().GetBrush(TEXT("Mixtormat.InspectorWell")))
		.Padding(FMargin(0.0f, FMixtormatThemeStore::GetResolved().ControlLayout.InspectorTopMargin, 0.0f, 0.0f))
		[
			SAssignNew(Stack, SVerticalBox)
		]
	];
}

void SMixtormatInspectorWell::AddGroup(const TSharedRef<SWidget>& Group)
{
	if (Stack.IsValid())
	{
		// Groups used to stack flush, which is why the column read as one sheet. They are rounded
		// blocks now, and a rounded corner needs something to be rounded against: this gap is
		// where the darker surround shows through.
		Stack->AddSlot()
			.AutoHeight()
			.Padding(
				FMixtormatThemeStore::GetResolved().ControlLayout.GroupOuterGap,
				0.0f,
				FMixtormatThemeStore::GetResolved().ControlLayout.GroupOuterGap,
				FMixtormatThemeStore::GetResolved().ControlLayout.GroupOuterGap)
			[Group];
	}
}

void SMixtormatInspectorWell::ClearGroups()
{
	if (Stack.IsValid())
	{
		Stack->ClearChildren();
	}
}
