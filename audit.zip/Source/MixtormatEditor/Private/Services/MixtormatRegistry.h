// Copyright 2026 Hugo Beyer. All Rights Reserved.

#pragma once

#include "AssetRegistry/AssetData.h"
#include "CoreMinimal.h"
#include "UObject/SoftObjectPath.h"

struct FMixtormatMaskEntry
{
	FSoftObjectPath AssetPath;
	FAssetData ThumbnailAsset;
	FText DisplayName;
	FName Category;
};

struct FMixtormatSurfaceEntry
{
	FSoftObjectPath AssetPath;
	FAssetData ThumbnailAsset;
	FText DisplayName;
	FName Family;
	FName Subtype;
	FName Finish;
};

struct FMixtormatCompositionEntry
{
	FSoftObjectPath AssetPath;
	FAssetData ThumbnailAsset;
	FText DisplayName;
	int32 LayerCount = 0;
};

struct FMixtormatNormalEntry
{
	FSoftObjectPath AssetPath;
	FAssetData ThumbnailAsset;
	FText DisplayName;
	FName Category;
};

struct FMixtormatEffectEntry
{
	FSoftObjectPath AssetPath;
	FAssetData ThumbnailAsset;
	FText DisplayName;
	FName Category;
};

class FMixtormatRegistry final
{
public:
	static TArray<FMixtormatSurfaceEntry> GetSurfaces();
	static TArray<FMixtormatCompositionEntry> GetCompositions();
	static TArray<FMixtormatMaskEntry> GetMasks();
	static TArray<FMixtormatNormalEntry> GetNormals();
	static TArray<FMixtormatEffectEntry> GetEffects();
};
