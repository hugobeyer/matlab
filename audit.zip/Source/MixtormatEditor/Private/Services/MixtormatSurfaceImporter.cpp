// Copyright 2026 Hugo Beyer. All Rights Reserved.

#include "Services/MixtormatSurfaceImporter.h"

#include "Preview/MixtormatPreviewSceneSettings.h"
#include "Services/MixtormatPaths.h"
#include "Services/MixtormatThumbnailRenderer.h"
#include "UI/Parameters/MixtormatParameterUiMeta.h"
PRAGMA_DISABLE_DEPRECATION_WARNINGS
#include "AssetImportTask.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetToolsModule.h"
#include "DesktopPlatformModule.h"
#include "Editor.h"
#include "EditorFramework/AssetImportData.h"
#include "EditorReimportHandler.h"
PRAGMA_ENABLE_DEPRECATION_WARNINGS
#include "Engine/Texture2D.h"
#include "Factories/DataAssetFactory.h"
#include "Factories/MaterialInstanceConstantFactoryNew.h"
#include "Framework/Application/SlateApplication.h"
#include "HAL/FileManager.h"
#include "IDesktopPlatform.h"
#include "MaterialEditingLibrary.h"
#include "MixtormatEffect.h"
#include "MixtormatNormalHeightGenerator.h"
#include "MixtormatSurface.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Misc/MessageDialog.h"
#include "Misc/Paths.h"
#include "Misc/PackageName.h"
#include "Misc/SecureHash.h"
#include "ObjectTools.h"
#include "Subsystems/EditorAssetSubsystem.h"
#include "UObject/Package.h"

namespace MixtormatImporter
{
	struct FTextureSet
	{
		FString BaseName;
		FString BaseColorFile;
		FString NormalFile;
		FString RamFile;
		FString RamHeightFile;

		bool IsComplete() const
		{
			return !BaseColorFile.IsEmpty()
				&& !NormalFile.IsEmpty()
				&& (!RamFile.IsEmpty() || !RamHeightFile.IsEmpty());
		}
	};

	enum class EMapType : uint8
	{
		BaseColor,
		Normal,
		Ram,
		RamHeight,
		EffectData,
		EffectNormal
	};

	bool ParseMapName(const FString& Stem, FString& OutBaseName, EMapType& OutMapType)
	{
		if (Stem.EndsWith(TEXT("_RAMH"), ESearchCase::IgnoreCase))
		{
			OutBaseName = Stem.LeftChop(5);
			OutMapType = EMapType::RamHeight;
			return true;
		}

		if (Stem.EndsWith(TEXT("_RAM"), ESearchCase::IgnoreCase))
		{
			OutBaseName = Stem.LeftChop(4);
			OutMapType = EMapType::Ram;
			return true;
		}

		if (Stem.EndsWith(TEXT("_BC"), ESearchCase::IgnoreCase))
		{
			OutBaseName = Stem.LeftChop(3);
			OutMapType = EMapType::BaseColor;
			return true;
		}
		if (Stem.EndsWith(TEXT("_N"), ESearchCase::IgnoreCase))
		{
			OutBaseName = Stem.LeftChop(2);
			OutMapType = EMapType::Normal;
			return true;
		}
		return false;
	}

	bool ParseEffectMapName(const FString& Stem, FString& OutBaseName, FString& OutSuffix)
	{
		const TCHAR* Suffixes[] = {TEXT("_PDM"), TEXT("_MSK"), TEXT("_SDF"), TEXT("_BN"), TEXT("_H")};
		for (const TCHAR* Suffix : Suffixes)
		{
			const FString SuffixString(Suffix);
			if (Stem.EndsWith(SuffixString, ESearchCase::IgnoreCase))
			{
				OutBaseName = Stem.LeftChop(SuffixString.Len());
				OutSuffix = SuffixString;
				return true;
			}
		}
		return false;
	}

	bool ConfigureTexture(UTexture2D& Texture, const EMapType MapType)
	{
		const bool bNormalMap = MapType == EMapType::Normal
			|| MapType == EMapType::EffectNormal;
		const bool bEffectMap = MapType == EMapType::EffectData
			|| MapType == EMapType::EffectNormal;
		const bool bSRGB = MapType == EMapType::BaseColor;
		const TextureCompressionSettings Compression = bNormalMap
			? TC_Normalmap
			: (MapType == EMapType::BaseColor ? TC_Default : TC_Masks);
		const bool bLODGroupChanged = bNormalMap
			&& Texture.LODGroup != TEXTUREGROUP_WorldNormalMap;
		const bool bMipSettingsChanged = bEffectMap
			&& Texture.MipGenSettings != TMGS_NoMipmaps;
		const bool bStreamingChanged = !Texture.NeverStream;
		const bool bAlphaPreservationChanged = MapType == EMapType::RamHeight
			&& Texture.CompressionNoAlpha;
		if (Texture.SRGB == bSRGB
			&& Texture.CompressionSettings == Compression
			&& !bLODGroupChanged
			&& !bMipSettingsChanged
			&& !bStreamingChanged
			&& !bAlphaPreservationChanged)
		{
			return false;
		}

		Texture.Modify();
		Texture.SRGB = bSRGB;
		Texture.CompressionSettings = Compression;
		if (MapType == EMapType::RamHeight)
		{
			Texture.CompressionNoAlpha = false;
		}
		Texture.NeverStream = true;
		if (bNormalMap)
		{
			Texture.LODGroup = TEXTUREGROUP_WorldNormalMap;
		}
		if (bEffectMap)
		{
			Texture.MipGenSettings = TMGS_NoMipmaps;
		}
		Texture.PostEditChange();
		Texture.MarkPackageDirty();
		return true;
	}

	bool IsMixtormatAssetPath(const FString& PackagePath)
	{
		const auto IsUnderRoot = [&PackagePath](const FString& Root)
		{
			return PackagePath == Root
				|| PackagePath.StartsWith(Root + TEXT("/"), ESearchCase::CaseSensitive);
		};
		return IsUnderRoot(FMixtormatPaths::PluginContentRoot())
			|| IsUnderRoot(FMixtormatPaths::ProjectLibraryRoot());
	}

	bool SaveMixtormatAsset(UObject& Asset, const TCHAR* AssetLabel, TArray<FString>& Errors)
	{
		const FString PackageName = Asset.GetOutermost()->GetName();
		if (!IsMixtormatAssetPath(PackageName))
		{
			Errors.Add(FString::Printf(
				TEXT("Refused to save %s outside Mixtormat-managed content: %s."),
				AssetLabel,
				*PackageName));
			return false;
		}

		UEditorAssetSubsystem* AssetSubsystem = GEditor
			? GEditor->GetEditorSubsystem<UEditorAssetSubsystem>()
			: nullptr;
		if (!AssetSubsystem)
		{
			Errors.Add(FString::Printf(
				TEXT("The editor asset subsystem is unavailable; %s was not saved."),
				AssetLabel));
			return false;
		}
		if (!AssetSubsystem->SaveLoadedAsset(&Asset, false))
		{
			Errors.Add(FString::Printf(TEXT("Failed to save %s: %s."), AssetLabel, *PackageName));
			return false;
		}
		return true;
	}

	FString NormalizeSourcePath(const FString& Path)
	{
		FString Normalized = FPaths::ConvertRelativePathToFull(Path);
		FPaths::NormalizeFilename(Normalized);
		return Normalized;
	}

	bool HasSourceChanged(const UTexture2D& Texture, const FString& Filename)
	{
		if (!Texture.AssetImportData)
		{
			return true;
		}

		const FAssetImportInfo& SourceData = Texture.AssetImportData->GetSourceData();
		if (SourceData.SourceFiles.IsEmpty())
		{
			return true;
		}

		if (!NormalizeSourcePath(Texture.AssetImportData->GetFirstFilename()).Equals(
			NormalizeSourcePath(Filename),
			ESearchCase::IgnoreCase))
		{
			return true;
		}

		return SourceData.SourceFiles[0].FileHash != FMD5Hash::HashFile(*Filename);
	}

	UTexture2D* ImportTexture(
		IAssetTools& AssetTools,
		const FString& Filename,
		const FString& DestinationPath,
		const EMapType MapType,
		FMixtormatImportResult& Result,
		const bool bForceReimport = false)
	{
		if (!IsMixtormatAssetPath(DestinationPath))
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Refused to import a texture outside Mixtormat-managed content: %s."),
				*DestinationPath));
			return nullptr;
		}

		const FString AssetName = ObjectTools::SanitizeObjectName(
			FPaths::GetBaseFilename(Filename));
		const FString ObjectPath = FString::Printf(
			TEXT("%s/%s.%s"), *DestinationPath, *AssetName, *AssetName);

		if (UTexture2D* ExistingTexture = LoadObject<UTexture2D>(nullptr, *ObjectPath))
		{
			bool bReimported = false;
			if (bForceReimport || HasSourceChanged(*ExistingTexture, Filename))
			{
				if (!FReimportManager::Instance()->Reimport(
					ExistingTexture,
					false,
					false,
					Filename))
				{
					Result.Errors.Add(FString::Printf(
						TEXT("Failed to reimport texture %s from %s."),
						*ObjectPath,
						*Filename));
					return nullptr;
				}
				bReimported = true;
				++Result.ReimportedTextureCount;
			}
			else
			{
				++Result.ReusedTextureCount;
			}

			const bool bSettingsChanged = ConfigureTexture(*ExistingTexture, MapType);
			if (bReimported || bSettingsChanged)
			{
				SaveMixtormatAsset(*ExistingTexture, TEXT("imported texture"), Result.Errors);
			}
			return ExistingTexture;
		}

		UAssetImportTask* Task = NewObject<UAssetImportTask>();
		Task->Filename = Filename;
		Task->DestinationPath = DestinationPath;
		Task->DestinationName = AssetName;
		Task->bAutomated = true;
		Task->bReplaceExisting = false;
		Task->bReplaceExistingSettings = false;
		Task->bSave = true;

		TArray<UAssetImportTask*> Tasks;
		Tasks.Add(Task);
		AssetTools.ImportAssetTasks(Tasks);

		for (const FString& ImportedObjectPath : Task->ImportedObjectPaths)
		{
			if (UTexture2D* Texture = LoadObject<UTexture2D>(nullptr, *ImportedObjectPath))
			{
				ConfigureTexture(*Texture, MapType);
				SaveMixtormatAsset(*Texture, TEXT("imported texture"), Result.Errors);
				return Texture;
			}
		}

		return nullptr;
	}

	bool ReadTextureSourceBGRA8(
		UTexture2D& Texture,
		const TCHAR* TextureLabel,
		TArray<FColor>& OutPixels,
		FString& OutError)
	{
		const int32 Width = Texture.Source.GetSizeX();
		const int32 Height = Texture.Source.GetSizeY();
		if (Width <= 0 || Height <= 0)
		{
			OutError = FString::Printf(TEXT("The %s texture has no source pixels."), TextureLabel);
			return false;
		}
		if (Texture.Source.GetFormat() != TSF_BGRA8)
		{
			OutError = FString::Printf(
				TEXT("The %s source format must be BGRA8; received format %d."),
				TextureLabel,
				static_cast<int32>(Texture.Source.GetFormat()));
			return false;
		}

		const uint8* SourceData = Texture.Source.LockMip(0);
		if (!SourceData)
		{
			OutError = FString::Printf(TEXT("Failed to lock the %s source pixels."), TextureLabel);
			return false;
		}
		OutPixels.SetNumUninitialized(Width * Height);
		FMemory::Memcpy(
			OutPixels.GetData(),
			SourceData,
			OutPixels.Num() * sizeof(FColor));
		Texture.Source.UnlockMip(0);
		return true;
	}

	UTexture2D* CreateOrUpdateGeneratedRAMH(
		const FString& DestinationPath,
		const FString& AssetName,
		const int32 Width,
		const int32 Height,
		const TArray<FColor>& RamPixels,
		const TArray<uint8>& HeightPixels,
		FMixtormatImportResult& Result)
	{
		if (!IsMixtormatAssetPath(DestinationPath))
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Refused to create derived RAMH outside Mixtormat-managed content: %s."),
				*DestinationPath));
			return nullptr;
		}
		if (RamPixels.Num() != Width * Height || HeightPixels.Num() != Width * Height)
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Derived RAMH pixel counts do not match %dx%d for %s."),
				Width,
				Height,
				*AssetName));
			return nullptr;
		}

		const FString PackageName = FString::Printf(TEXT("%s/%s"), *DestinationPath, *AssetName);
		const FString ObjectPath = FString::Printf(TEXT("%s.%s"), *PackageName, *AssetName);
		UTexture2D* Texture = LoadObject<UTexture2D>(nullptr, *ObjectPath);
		const bool bCreated = Texture == nullptr;
		if (bCreated)
		{
			if (UObject* ExistingObject = StaticLoadObject(UObject::StaticClass(), nullptr, *ObjectPath))
			{
				Result.Errors.Add(FString::Printf(
					TEXT("Cannot create derived RAMH because an incompatible asset exists at %s."),
					*ExistingObject->GetPathName()));
				return nullptr;
			}
			UPackage* Package = CreatePackage(*PackageName);
			Texture = NewObject<UTexture2D>(
				Package,
				*AssetName,
				RF_Public | RF_Standalone | RF_Transactional);
		}
		if (!Texture)
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Failed to create or load derived RAMH %s."),
				*ObjectPath));
			return nullptr;
		}
		if (!bCreated && Texture->AssetImportData
			&& !Texture->AssetImportData->GetSourceData().SourceFiles.IsEmpty())
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Refused to overwrite non-generated texture at derived RAMH path %s."),
				*ObjectPath));
			return nullptr;
		}

		TArray<FColor> PackedPixels = RamPixels;
		for (int32 PixelIndex = 0; PixelIndex < PackedPixels.Num(); ++PixelIndex)
		{
			PackedPixels[PixelIndex].A = HeightPixels[PixelIndex];
		}

		Texture->Modify();
		Texture->PreEditChange(nullptr);
		Texture->Source.Init(
			Width,
			Height,
			1,
			1,
			TSF_BGRA8,
			reinterpret_cast<const uint8*>(PackedPixels.GetData()));
		Texture->SRGB = false;
		Texture->CompressionSettings = TC_Masks;
		Texture->CompressionNoAlpha = false;
		Texture->LODGroup = TEXTUREGROUP_World;
		Texture->MipGenSettings = TMGS_FromTextureGroup;
		Texture->NeverStream = true;
		Texture->Filter = TF_Default;
		Texture->AddressX = TA_Wrap;
		Texture->AddressY = TA_Wrap;
		Texture->PostEditChange();
		Texture->MarkPackageDirty();
		if (bCreated)
		{
			FAssetRegistryModule::AssetCreated(Texture);
		}
		if (!SaveMixtormatAsset(*Texture, TEXT("derived RAMH texture"), Result.Errors))
		{
			return nullptr;
		}
		++Result.GeneratedHeightCount;
		return Texture;
	}

	FString MakeDerivedHeightSourceHash(
		const FString& NormalFile,
		const FString& RamFile,
		const bool bFlipNormalY)
	{
		const FString NormalHash = LexToString(FMD5Hash::HashFile(*NormalFile));
		const FString RamHash = LexToString(FMD5Hash::HashFile(*RamFile));
		return FString::Printf(
			TEXT("FFT2:Y%d:%s:%s"),
			bFlipNormalY ? 1 : 0,
			*NormalHash,
			*RamHash);
	}

	FString MakeSurfaceThumbnailSourceHash(
		const FTextureSet& Set,
		const FString& PackedSourceFile,
		const float DefaultIOR,
		UMaterialInstanceConstant& PreviewMaterial)
	{
		const float RoughnessBias = UMaterialEditingLibrary::GetMaterialInstanceScalarParameterValue(
			&PreviewMaterial, TEXT("DA_RoughnessBias"));
		const float RoughnessContrast = UMaterialEditingLibrary::GetMaterialInstanceScalarParameterValue(
			&PreviewMaterial, TEXT("DA_RoughnessContrast"));
		const float RoughnessOffset = UMaterialEditingLibrary::GetMaterialInstanceScalarParameterValue(
			&PreviewMaterial, TEXT("DA_RoughnessOffset"));
		return FString::Printf(
			TEXT("SurfaceThumbnailV19:%d:ReflectionBrightness10:StudioPresetSky:NoFogScaledFloor:ShapedLeftRim:Medium:NoAA:NoHeight:SceneCaptureView:PluginFerndaleSky3:IOR%.6g:R%.6g,%.6g,%.6g:%s:%s:%s"),
			MixtormatPreviewSceneSettings::SurfaceThumbnailResolution,
			DefaultIOR,
			RoughnessBias,
			RoughnessContrast,
			RoughnessOffset,
			*LexToString(FMD5Hash::HashFile(*Set.BaseColorFile)),
			*LexToString(FMD5Hash::HashFile(*Set.NormalFile)),
			*LexToString(FMD5Hash::HashFile(*PackedSourceFile)));
	}

	FString MakeDerivedRAMHAssetName(const FString& BaseName)
	{
		return ObjectTools::SanitizeObjectName(BaseName + TEXT("_RAMH_Derived"));
	}

	UTexture2D* LoadReusableDerivedRAMH(
		const UMixtormatSurface& Surface,
		const FString& DestinationPath,
		const FString& BaseName,
		const FString& SourceHash)
	{
		if (Surface.BlendHeightProvenance
			!= EMixtormatBlendHeightProvenance::DerivedFromNormal
			|| !Surface.DerivedHeightSourceHash.Equals(SourceHash, ESearchCase::CaseSensitive))
		{
			return nullptr;
		}
		const FString AssetName = MakeDerivedRAMHAssetName(BaseName);
		const FString ObjectPath = FString::Printf(
			TEXT("%s/%s.%s"),
			*DestinationPath,
			*AssetName,
			*AssetName);
		UTexture2D* Texture = LoadObject<UTexture2D>(nullptr, *ObjectPath);
		return Texture
			&& (!Texture->AssetImportData
				|| Texture->AssetImportData->GetSourceData().SourceFiles.IsEmpty())
			? Texture
			: nullptr;
	}

	UTexture2D* BuildDerivedRAMH(
		UTexture2D& Normal,
		UTexture2D& Ram,
		const FString& DestinationPath,
		const FString& BaseName,
		FMixtormatImportResult& Result)
	{
		const FIntPoint NormalSize(Normal.Source.GetSizeX(), Normal.Source.GetSizeY());
		const FIntPoint RamSize(Ram.Source.GetSizeX(), Ram.Source.GetSizeY());
		if (NormalSize != RamSize)
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Cannot derive height for %s because source dimensions differ: N %dx%d, RAM %dx%d."),
				*BaseName,
				NormalSize.X,
				NormalSize.Y,
				RamSize.X,
				RamSize.Y));
			return nullptr;
		}

		TArray<FColor> NormalPixels;
		FString NormalSourceError;
		if (!ReadTextureSourceBGRA8(
			Normal,
			TEXT("normal"),
			NormalPixels,
			NormalSourceError))
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Failed to read normal source for %s: %s"),
				*BaseName,
				*NormalSourceError));
			return nullptr;
		}

		TArray<uint8> HeightPixels;
		FString GenerationError;
		if (!FMixtormatNormalHeightGenerator::Generate(
			NormalPixels,
			NormalSize,
			Normal.bFlipGreenChannel,
			HeightPixels,
			GenerationError))
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Failed to derive height for %s: %s"),
				*BaseName,
				*GenerationError));
			return nullptr;
		}

		TArray<FColor> RamPixels;
		FString SourceError;
		if (!ReadTextureSourceBGRA8(
			Ram,
			TEXT("packed RAM"),
			RamPixels,
			SourceError))
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Failed to pack derived height for %s: %s"),
				*BaseName,
				*SourceError));
			return nullptr;
		}

		const FString AssetName = MakeDerivedRAMHAssetName(BaseName);
		return CreateOrUpdateGeneratedRAMH(
			DestinationPath,
			AssetName,
			RamSize.X,
			RamSize.Y,
			RamPixels,
			HeightPixels,
			Result);
	}

	void SetIdentity(
		UMixtormatSurface& Surface,
		const FString& BaseName,
		const FString& Family)
	{
		Surface.Family = FName(*Family);
		Surface.SourceTextureBaseName = BaseName;

		FString Identity = BaseName;
		Identity.RemoveFromStart(TEXT("TX_"));

		TArray<FString> Parts;
		Identity.ParseIntoArray(Parts, TEXT("_"), true);
		if (Parts.Num() < 3)
		{
			return;
		}

		Surface.Subtype = FName(*Parts[1]);
		Surface.Structure = Parts.Num() >= 5 ? FName(*Parts[3]) : FName(TEXT("Plain"));

		const FString& VariantPart = Parts.Last();
		Surface.Variant = FMath::Max(1, FCString::Atoi(*VariantPart));
		if (Parts.Num() >= 4)
		{
			Surface.Finish = FName(*Parts[2]);
			Surface.DisplayName = FText::FromString(FString::Printf(
				TEXT("%s · %s"), *Parts[1], *Parts[2]));
		}
		else
		{
			Surface.Finish = FName(TEXT("Standard"));
			Surface.DisplayName = FText::FromString(FString::Printf(
				TEXT("%s · %s"), *Parts[1], *VariantPart));
		}
	}

	UMixtormatSurface* CreateOrLoadSurface(
		IAssetTools& AssetTools,
		const FString& AssetName,
		const FString& DestinationPath)
	{
		const FString ObjectPath = FString::Printf(
			TEXT("%s/%s.%s"), *DestinationPath, *AssetName, *AssetName);
		if (UMixtormatSurface* ExistingSurface = LoadObject<UMixtormatSurface>(nullptr, *ObjectPath))
		{
			return ExistingSurface;
		}

		UDataAssetFactory* Factory = NewObject<UDataAssetFactory>();
		Factory->DataAssetClass = UMixtormatSurface::StaticClass();
		return Cast<UMixtormatSurface>(AssetTools.CreateAsset(
			AssetName,
			DestinationPath,
			UMixtormatSurface::StaticClass(),
			Factory));
	}


	UMaterial* LoadSubstrateMaster()
	{
		return LoadObject<UMaterial>(
			nullptr,
			*FMixtormatPaths::MasterMaterialObjectPath());
	}

	UMaterialInstanceConstant* CreateOrUpdatePreviewMaterial(
		IAssetTools& AssetTools,
		UMaterial& Parent,
		const FString& SurfaceAssetName,
		const FString& DestinationPath,
		UTexture2D& BaseColor,
		UTexture2D& Normal,
		UTexture2D& Ram,
		const float DefaultIOR)
	{
		FString InstanceName = SurfaceAssetName;
		InstanceName.RemoveFromStart(TEXT("DA_"));
		InstanceName = TEXT("MI_") + InstanceName;
		const FString ObjectPath = FString::Printf(TEXT("%s/%s.%s"), *DestinationPath, *InstanceName, *InstanceName);

		UMaterialInstanceConstant* Instance = LoadObject<UMaterialInstanceConstant>(nullptr, *ObjectPath);
		if (!Instance)
		{
			UMaterialInstanceConstantFactoryNew* Factory = NewObject<UMaterialInstanceConstantFactoryNew>();
			Factory->InitialParent = &Parent;
			Instance = Cast<UMaterialInstanceConstant>(AssetTools.CreateAsset(
				InstanceName,
				DestinationPath,
				UMaterialInstanceConstant::StaticClass(),
				Factory));
		}
		if (!Instance)
		{
			return nullptr;
		}

		Instance->Modify();
		if (Instance->Parent != &Parent)
		{
			UMaterialEditingLibrary::SetMaterialInstanceParent(Instance, &Parent);
		}
		UMaterialEditingLibrary::SetMaterialInstanceTextureParameterValue(Instance, TEXT("DA_BaseColor"), &BaseColor);
		UMaterialEditingLibrary::SetMaterialInstanceTextureParameterValue(Instance, TEXT("DA_Normal"), &Normal);
		UMaterialEditingLibrary::SetMaterialInstanceTextureParameterValue(Instance, TEXT("DA_RAMH"), &Ram);
		const float SafeIOR = FMath::Max(1.0f, DefaultIOR);
		const float DielectricF0 = FMath::Square((SafeIOR - 1.0f) / (SafeIOR + 1.0f));
		UMaterialEditingLibrary::SetMaterialInstanceScalarParameterValue(
			Instance,
			TEXT("DA_DielectricF0"),
			DielectricF0);
		UMaterialEditingLibrary::SetMaterialInstanceScalarParameterValue(
			Instance,
			TEXT("DA_UsePackedF0"),
			0.0f);
		Instance->PostEditChange();
		Instance->MarkPackageDirty();
		return Instance;
	}
}

FText FMixtormatImportResult::ToMessage() const
{
	if (bCancelled)
	{
		return NSLOCTEXT("MixtormatImporter", "Cancelled", "Import cancelled.");
	}

	FString Message = FString::Printf(
		TEXT("Imported or updated %d surfaces, %d masks, %d standalone normals, and %d effects. Generated %d normal-derived height textures. Generated or updated %d thumbnails; reused %d unchanged thumbnails. Reimported %d changed textures; reused %d unchanged textures."),
		ImportedSurfaceCount,
		ImportedMaskCount,
		ImportedNormalCount,
		ImportedEffectCount,
		GeneratedHeightCount,
		GeneratedThumbnailCount,
		ReusedThumbnailCount,
		ReimportedTextureCount,
		ReusedTextureCount);

	if (!Errors.IsEmpty())
	{
		Message += TEXT("\n\nIssues:\n- ");
		Message += FString::Join(Errors, TEXT("\n- "));
	}
	return FText::FromString(Message);
}

FString FMixtormatSurfaceImporter::GetPluginTexturesRoot()
{
	const FString SourceTexturesDir = FMixtormatPaths::SourceTexturesDir();
	return SourceTexturesDir.IsEmpty()
		? FString()
		: FPaths::ConvertRelativePathToFull(SourceTexturesDir);
}

TArray<FString> FMixtormatSurfaceImporter::EnumerateShippedSourceDirectories()
{
	TArray<FString> Directories;
	const FString Root = GetPluginTexturesRoot();
	if (Root.IsEmpty() || !IFileManager::Get().DirectoryExists(*Root))
	{
		return Directories;
	}

	TArray<FString> FamilyDirectories;
	IFileManager::Get().FindFiles(
		FamilyDirectories,
		*(Root / TEXT("*")),
		false,
		true);
	for (const FString& FamilyDirectory : FamilyDirectories)
	{
		if (FamilyDirectory.Equals(TEXT("Masks"), ESearchCase::IgnoreCase)
			|| FamilyDirectory.Equals(TEXT("Normals"), ESearchCase::IgnoreCase)
			|| FamilyDirectory.Equals(TEXT("Effects"), ESearchCase::IgnoreCase))
		{
			continue;
		}

		const FString SourceDirectory = Root / FamilyDirectory / TEXT("Source");
		if (!IFileManager::Get().DirectoryExists(*SourceDirectory))
		{
			continue;
		}

		TArray<FString> PngFiles;
		IFileManager::Get().FindFiles(
			PngFiles,
			*(SourceDirectory / TEXT("*.png")),
			true,
			false);
		if (!PngFiles.IsEmpty())
		{
			Directories.Add(SourceDirectory);
		}
	}
	return Directories;
}

FMixtormatImportResult FMixtormatSurfaceImporter::ImportShippedMasks()
{
	using namespace MixtormatImporter;
	FMixtormatImportResult Result;
	const FString TexturesRoot = GetPluginTexturesRoot();
	if (TexturesRoot.IsEmpty())
	{
		return Result;
	}
	const FString MaskSourceRoot = TexturesRoot / TEXT("Masks/Source");
	if (!IFileManager::Get().DirectoryExists(*MaskSourceRoot))
	{
		Result.Errors.Add(FString::Printf(TEXT("Mask source folder is missing: %s."), *MaskSourceRoot));
		return Result;
	}

	TArray<FString> MaskFiles;
	IFileManager::Get().FindFiles(
		MaskFiles,
		*(MaskSourceRoot / TEXT("*.png")),
		true,
		false);
	if (MaskFiles.IsEmpty())
	{
		Result.Errors.Add(FString::Printf(TEXT("No mask PNG files were found under %s."), *MaskSourceRoot));
		return Result;
	}
	IAssetTools& AssetTools =
		FModuleManager::LoadModuleChecked<FAssetToolsModule>(TEXT("AssetTools")).Get();
	for (const FString& MaskFilename : MaskFiles)
	{
		const FString MaskFile = MaskSourceRoot / MaskFilename;
		if (UTexture2D* MaskTexture = ImportTexture(
			AssetTools,
			MaskFile,
			FMixtormatPaths::MasksRoot(),
			EMapType::Ram,
			Result))
		{
			const FMixtormatThumbnailUpdate ThumbnailUpdate =
				FMixtormatThumbnailRenderer::CreateOrUpdateMaskThumbnail(
					*MaskTexture,
					FMixtormatPaths::MaskThumbnailsRoot());
			if (!ThumbnailUpdate.IsValid())
			{
				Result.Errors.Add(ThumbnailUpdate.Error);
			}
			else if (ThumbnailUpdate.bChanged)
			{
				if (SaveMixtormatAsset(
					*ThumbnailUpdate.Texture,
					TEXT("mask thumbnail"),
					Result.Errors))
				{
					++Result.GeneratedThumbnailCount;
				}
			}
			else
			{
				++Result.ReusedThumbnailCount;
			}
			++Result.ImportedMaskCount;
		}
		else
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Failed to import mask %s."),
				*FPaths::GetCleanFilename(MaskFile)));
		}
	}
	return Result;
}

FMixtormatImportResult FMixtormatSurfaceImporter::ImportShippedNormals()
{
	using namespace MixtormatImporter;
	FMixtormatImportResult Result;
	const FString TexturesRoot = GetPluginTexturesRoot();
	if (TexturesRoot.IsEmpty())
	{
		return Result;
	}

	const FString NormalSourceRoot = TexturesRoot / TEXT("Normals/Source");
	if (!IFileManager::Get().DirectoryExists(*NormalSourceRoot))
	{
		return Result;
	}

	TArray<FString> NormalFiles;
	IFileManager::Get().FindFilesRecursive(
		NormalFiles,
		*NormalSourceRoot,
		TEXT("*.png"),
		true,
		false);
	if (NormalFiles.IsEmpty())
	{
		return Result;
	}

	IAssetTools& AssetTools =
		FModuleManager::LoadModuleChecked<FAssetToolsModule>(TEXT("AssetTools")).Get();
	for (const FString& NormalFile : NormalFiles)
	{
		FString Category = FPaths::GetPath(NormalFile);
		const FString NormalSourceRootWithSlash = NormalSourceRoot + TEXT("/");
		FPaths::MakePathRelativeTo(Category, *NormalSourceRootWithSlash);
		Category.ReplaceInline(TEXT("\\"), TEXT("/"));
		if (Category.IsEmpty() || Category == TEXT("."))
		{
			Category = TEXT("General");
		}

		const FString DestinationPath = FMixtormatPaths::NormalCategoryRoot(Category);
		if (ImportTexture(
			AssetTools,
			NormalFile,
			DestinationPath,
			EMapType::Normal,
			Result))
		{
			++Result.ImportedNormalCount;
		}
		else
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Failed to import standalone normal %s."),
				*FPaths::GetCleanFilename(NormalFile)));
		}
	}
	return Result;
}

FMixtormatImportResult FMixtormatSurfaceImporter::ImportShippedEffects()
{
	using namespace MixtormatImporter;
	FMixtormatImportResult Result;
	const FString TexturesRoot = GetPluginTexturesRoot();
	if (TexturesRoot.IsEmpty())
	{
		return Result;
	}

	const FString EffectSourceRoot = TexturesRoot / TEXT("Effects");
	if (!IFileManager::Get().DirectoryExists(*EffectSourceRoot))
	{
		return Result;
	}

	TArray<FString> EffectFiles;
	IFileManager::Get().FindFilesRecursive(
		EffectFiles,
		*EffectSourceRoot,
		TEXT("*.png"),
		true,
		false);

	// The _PDM / _MSK / _H / _SDF / _BN map sets that used to be scanned and imported here fed
	// the asset-backed peeling path, which is gone -- peeling generates its field now. Nothing
	// else consumed them, so the whole effect-texture import went with it.

	// Stains are procedural filters and no longer need a generated placeholder asset.

	return Result;
}

FString FMixtormatSurfaceImporter::GetDefaultSourceDirectory()
{
	const TArray<FString> Directories = EnumerateShippedSourceDirectories();
	return Directories.IsEmpty() ? FString() : Directories[0];
}

FMixtormatImportResult FMixtormatSurfaceImporter::ImportDefaultLibrary()
{
	FMixtormatImportResult Result;
	for (const FString& SourceDirectory : EnumerateShippedSourceDirectories())
	{
		const FMixtormatImportResult Step = ImportDirectory(SourceDirectory, true);
		Result.ImportedSurfaceCount += Step.ImportedSurfaceCount;
		Result.ReimportedTextureCount += Step.ReimportedTextureCount;
		Result.ReusedTextureCount += Step.ReusedTextureCount;
		Result.GeneratedHeightCount += Step.GeneratedHeightCount;
		Result.GeneratedThumbnailCount += Step.GeneratedThumbnailCount;
		Result.ReusedThumbnailCount += Step.ReusedThumbnailCount;
		Result.Errors.Append(Step.Errors);
	}
	const FMixtormatImportResult MaskStep = ImportShippedMasks();
	Result.ImportedMaskCount += MaskStep.ImportedMaskCount;
	Result.ReimportedTextureCount += MaskStep.ReimportedTextureCount;
	Result.ReusedTextureCount += MaskStep.ReusedTextureCount;
	Result.GeneratedThumbnailCount += MaskStep.GeneratedThumbnailCount;
	Result.ReusedThumbnailCount += MaskStep.ReusedThumbnailCount;
	Result.Errors.Append(MaskStep.Errors);

	const FMixtormatImportResult NormalStep = ImportShippedNormals();
	Result.ImportedNormalCount += NormalStep.ImportedNormalCount;
	Result.ReimportedTextureCount += NormalStep.ReimportedTextureCount;
	Result.ReusedTextureCount += NormalStep.ReusedTextureCount;
	Result.Errors.Append(NormalStep.Errors);

	const FMixtormatImportResult EffectStep = ImportShippedEffects();
	Result.ImportedEffectCount += EffectStep.ImportedEffectCount;
	Result.ReimportedTextureCount += EffectStep.ReimportedTextureCount;
	Result.ReusedTextureCount += EffectStep.ReusedTextureCount;
	Result.Errors.Append(EffectStep.Errors);
	if (Result.Errors.IsEmpty() && !Result.bCancelled)
	{
		Result.bCancelled = false;
	}
	return Result;
}

FMixtormatImportResult FMixtormatSurfaceImporter::ReimportShippedLibrary()
{
	return ImportDefaultLibrary();
}

FMixtormatImportResult FMixtormatSurfaceImporter::ReimportShippedSurface(
	const FSoftObjectPath& SurfacePath)
{
	using namespace MixtormatImporter;
	FMixtormatImportResult Result;
	const UMixtormatSurface* Surface = Cast<UMixtormatSurface>(SurfacePath.TryLoad());
	if (!Surface)
	{
		Result.Errors.Add(TEXT("The selected gallery material could not be loaded."));
		return Result;
	}

	const FString PackageName = Surface->GetPackage()->GetName();
	const FString ManagedRoot = FMixtormatPaths::SurfacesRoot();
	if (PackageName != ManagedRoot && !PackageName.StartsWith(ManagedRoot + TEXT("/")))
	{
		Result.Errors.Add(TEXT("Only built-in gallery materials can be refreshed from developer sources."));
		return Result;
	}

	const FString SourceBaseName = Surface->SourceTextureBaseName;
	if (SourceBaseName.IsEmpty())
	{
		Result.Errors.Add(TEXT("The selected material does not record a source texture base name."));
		return Result;
	}

	for (const FString& SourceDirectory : EnumerateShippedSourceDirectories())
	{
		TArray<FString> Files;
		IFileManager::Get().FindFiles(Files, *(SourceDirectory / TEXT("*.png")), true, false);
		const bool bContainsSurface = Files.ContainsByPredicate(
			[&SourceBaseName](const FString& File)
			{
				FString ParsedBaseName;
				EMapType MapType;
				return ParseMapName(FPaths::GetBaseFilename(File), ParsedBaseName, MapType)
					&& ParsedBaseName.Equals(SourceBaseName, ESearchCase::IgnoreCase);
			});
		if (bContainsSurface)
		{
			return ImportDirectoryInternal(SourceDirectory, true, SourceBaseName, true);
		}
	}

	Result.Errors.Add(FString::Printf(
		TEXT("No shipped source PNG set was found for %s."),
		*SourceBaseName));
	return Result;
}

bool FMixtormatSurfaceImporter::CanDeleteShippedSurface(const FSoftObjectPath& SurfacePath)
{
	if (!MixtormatParameterUi::IsDeveloperMetaEnabled())
	{
		return false;
	}
	if (!SurfacePath.GetLongPackageName().StartsWith(FMixtormatPaths::SurfacesRoot() + TEXT("/")))
	{
		return false;
	}
	const UMixtormatSurface* Surface = Cast<UMixtormatSurface>(SurfacePath.TryLoad());
	if (!Surface || Surface->GetOutermost()->GetName() != SurfacePath.GetLongPackageName())
	{
		return false;
	}
	const FString& BaseName = Surface->SourceTextureBaseName;
	return !BaseName.IsEmpty()
		&& BaseName != TEXT(".") && BaseName != TEXT("..")
		&& ObjectTools::SanitizeObjectName(BaseName) == BaseName;
}

FMixtormatSurfaceDeletionResult FMixtormatSurfaceImporter::DeleteShippedSurface(
	const FSoftObjectPath& SurfacePath)
{
	FMixtormatSurfaceDeletionResult Result;
	if (!CanDeleteShippedSurface(SurfacePath))
	{
		Result.Errors.Add(TEXT("Deletion requires developer mode and a built-in surface with a valid source texture base name."));
		return Result;
	}
	UMixtormatSurface* Surface = Cast<UMixtormatSurface>(SurfacePath.TryLoad());
	if (!Surface)
	{
		Result.Errors.Add(TEXT("Built-in surface could not be loaded for deletion; no files or assets were deleted."));
		return Result;
	}
	const FString BaseName = Surface->SourceTextureBaseName;
	FString SourceRoot = GetPluginTexturesRoot();
	FPaths::NormalizeDirectoryName(SourceRoot);
	if (SourceRoot.IsEmpty() || !FPaths::CollapseRelativeDirectories(SourceRoot))
	{
		Result.Errors.Add(TEXT("Could not resolve the shipped source texture root."));
		return Result;
	}

	TArray<FString> SourceFiles;
	TArray<FString> MatchingSourceDirectories;
	for (const FString& Directory : EnumerateShippedSourceDirectories())
	{
		TArray<FString> Files;
		IFileManager::Get().FindFiles(Files, *(Directory / TEXT("*.png")), true, false);
		for (const FString& File : Files)
		{
			FString ParsedBase;
			MixtormatImporter::EMapType MapType;
			if (!MixtormatImporter::ParseMapName(FPaths::GetBaseFilename(File), ParsedBase, MapType)
				|| !ParsedBase.Equals(BaseName, ESearchCase::IgnoreCase))
			{
				continue;
			}
			FString Filename = FPaths::ConvertRelativePathToFull(Directory / File);
			FPaths::NormalizeFilename(Filename);
			if (!FPaths::CollapseRelativeDirectories(Filename) || !FPaths::IsUnderDirectory(Filename, SourceRoot))
			{
				Result.Errors.Add(FString::Printf(TEXT("Refused source file outside the shipped texture root: %s"), *Filename));
				continue;
			}
			SourceFiles.AddUnique(Filename);
			MatchingSourceDirectories.AddUnique(Directory);
		}
	}
	if (SourceFiles.IsEmpty())
	{
		Result.Errors.Add(FString::Printf(TEXT("No shipped source PNG files were found for %s."), *BaseName));
	}
	if (MatchingSourceDirectories.Num() > 1)
	{
		Result.Errors.Add(FString::Printf(TEXT("Source set %s is ambiguous across shipped directories: %s"),
			*BaseName, *FString::Join(MatchingSourceDirectories, TEXT(", "))));
	}

	FAssetRegistryModule& RegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	if (RegistryModule.Get().IsLoadingAssets())
	{
		Result.Errors.Add(TEXT("Cannot validate the deletion set while the Asset Registry is discovering assets."));
		return Result;
	}
	const FString PluginContentDirectory = FPaths::ConvertRelativePathToFull(FMixtormatPaths::PluginBaseDir() / TEXT("Content"));
	TArray<FAssetData> Assets;
	TArray<UObject*> ObjectsToDelete;
	TArray<FString> PackageFiles;
	const auto AddAsset = [&Assets, &ObjectsToDelete, &PackageFiles, &Result, &PluginContentDirectory](UObject* Asset, const FString& Root, const TArray<FString>& Names)
	{
		if (!Asset)
		{
			Result.Errors.Add(FString::Printf(TEXT("Could not resolve generated asset in %s: %s"),
				*Root, *FString::Join(Names, TEXT(", "))));
			return;
		}
		const FString Package = Asset->GetOutermost()->GetName();
		if (!Package.StartsWith(Root + TEXT("/")) || !Names.Contains(Asset->GetName()))
		{
			Result.Errors.Add(FString::Printf(TEXT("Refused unrelated or unmanaged asset: %s"), *Asset->GetPathName()));
			return;
		}
		FString Filename;
		if (!FPackageName::TryConvertLongPackageNameToFilename(Package, Filename, FPackageName::GetAssetPackageExtension()))
		{
			Result.Errors.Add(FString::Printf(TEXT("Could not resolve package file: %s"), *Package));
			return;
		}
		Filename = FPaths::ConvertRelativePathToFull(Filename);
		FPaths::NormalizeFilename(Filename);
		if (!FPaths::CollapseRelativeDirectories(Filename) || !FPaths::IsUnderDirectory(Filename, PluginContentDirectory))
		{
			Result.Errors.Add(FString::Printf(TEXT("Refused package file outside plugin content: %s"), *Filename));
			return;
		}
		Assets.AddUnique(FAssetData(Asset));
		ObjectsToDelete.AddUnique(Asset);
		PackageFiles.AddUnique(Filename);
	};
	const FString SurfaceName = Surface->GetName();
	FString PreviewName = SurfaceName;
	PreviewName.RemoveFromStart(TEXT("DA_"));
	PreviewName = TEXT("MI_") + PreviewName;
	AddAsset(Surface, FMixtormatPaths::SurfacesRoot(), {SurfaceName});
	AddAsset(Surface->PreviewMaterial, FMixtormatPaths::MaterialsRoot() + TEXT("/Instances"), {PreviewName});
	AddAsset(Surface->Thumbnail, FMixtormatPaths::SurfaceThumbnailsRoot(), {SurfaceName + TEXT("_Thumbnail")});
	if (!Surface->BaseColor)
	{
		Result.Errors.Add(TEXT("Could not resolve the surface's imported base-color texture directory."));
	}
	else
	{
		const FString TextureDirectory = FPackageName::GetLongPackagePath(Surface->BaseColor->GetOutermost()->GetName());
		if (!TextureDirectory.StartsWith(FMixtormatPaths::TexturesRoot() + TEXT("/")))
		{
			Result.Errors.Add(FString::Printf(TEXT("Refused unmanaged texture directory: %s"), *TextureDirectory));
		}
		else
		{
			const TArray<FString> PackedNames = {BaseName + TEXT("_RAM"), BaseName + TEXT("_RAMH"), BaseName + TEXT("_RAMH_Derived")};
			AddAsset(Surface->BaseColor, TextureDirectory, {BaseName + TEXT("_BC")});
			AddAsset(Surface->Normal, TextureDirectory, {BaseName + TEXT("_N")});
			AddAsset(Surface->RoughnessAOMetallic, TextureDirectory, PackedNames);
			for (const FString& Name : PackedNames)
			{
				const FSoftObjectPath Path(FString::Printf(TEXT("%s/%s.%s"), *TextureDirectory, *Name, *Name));
				UObject* Asset = Path.TryLoad();
				if (!Asset && (RegistryModule.Get().GetAssetByObjectPath(Path).IsValid()
					|| FPackageName::DoesPackageExist(Path.GetLongPackageName())))
				{
					Result.Errors.Add(FString::Printf(TEXT("Could not load generated packed texture: %s"), *Path.ToString()));
				}
				if (Asset && !Asset->IsA<UTexture2D>())
				{
					Result.Errors.Add(FString::Printf(TEXT("Refused non-texture asset at packed texture path: %s"), *Path.ToString()));
				}
				else if (Asset)
				{
					AddAsset(Asset, TextureDirectory, {Name});
				}
			}
		}
	}
	for (const FAssetData& Asset : Assets)
	{
		TArray<FAssetData> PackageAssets;
		RegistryModule.Get().GetAssetsByPackageName(Asset.PackageName, PackageAssets);
		for (const FAssetData& PackageAsset : PackageAssets)
		{
			if (!Assets.Contains(PackageAsset))
			{
				Result.Errors.Add(FString::Printf(TEXT("Refused package containing an unrelated asset: %s"),
					*PackageAsset.GetSoftObjectPath().ToString()));
			}
		}
	}
	if (!Result.Errors.IsEmpty())
	{
		return Result;
	}

	// Delete only the validated objects, without Force Delete's reference replacement.
	// Compositions retain their authored paths; keep PNGs unless all packages were removed.
	ObjectTools::DeleteObjectsUnchecked(ObjectsToDelete);
	const TArray<FString> ScanRoots = {FMixtormatPaths::SurfacesRoot(), FMixtormatPaths::TexturesRoot(),
		FMixtormatPaths::SurfaceThumbnailsRoot(), FMixtormatPaths::MaterialsRoot() + TEXT("/Instances")};
	RegistryModule.Get().ScanPathsSynchronous(ScanRoots, true);
	for (const FAssetData& Asset : Assets)
	{
		if (RegistryModule.Get().GetAssetByObjectPath(Asset.GetSoftObjectPath()).IsValid())
		{
			Result.Errors.Add(FString::Printf(TEXT("Generated asset was not deleted (failed or cancelled): %s"), *Asset.GetSoftObjectPath().ToString()));
		}
	}
	for (const FString& Filename : PackageFiles)
	{
		if (IFileManager::Get().FileExists(*Filename))
		{
			Result.Errors.Add(FString::Printf(TEXT("Generated package file was not deleted: %s"), *Filename));
		}
	}
	Result.bSurfaceDeleted = !RegistryModule.Get().GetAssetByObjectPath(SurfacePath).IsValid()
		&& !FPackageName::DoesPackageExist(SurfacePath.GetLongPackageName());
	if (!Result.bSurfaceDeleted)
	{
		Result.Errors.Add(FString::Printf(TEXT("Surface deletion could not be verified: %s"), *SurfacePath.ToString()));
	}
	if (!Result.Errors.IsEmpty())
	{
		Result.Errors.Add(TEXT("Source PNG files were retained because generated asset deletion was incomplete."));
		return Result;
	}
	for (const FString& Filename : SourceFiles)
	{
		if (!IFileManager::Get().Delete(*Filename, true, false, true) || IFileManager::Get().FileExists(*Filename))
		{
			Result.Errors.Add(FString::Printf(TEXT("Could not delete shipped source PNG: %s"), *Filename));
		}
	}
	return Result;
}

FMixtormatImportResult FMixtormatSurfaceImporter::ImportFromDialog()
{
	FMixtormatImportResult Result;
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	if (!DesktopPlatform)
	{
		Result.Errors.Add(TEXT("Desktop platform services are unavailable."));
		return Result;
	}

	FString SelectedDirectory;
	const void* ParentWindow = FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr);
	if (!DesktopPlatform->OpenDirectoryDialog(
		ParentWindow,
		TEXT("Choose Mixtormat texture export folder"),
		FPaths::ProjectContentDir(),
		SelectedDirectory))
	{
		Result.bCancelled = true;
		return Result;
	}

	return ImportDirectory(SelectedDirectory);
}

FMixtormatImportResult FMixtormatSurfaceImporter::ImportMasksFromDialog()
{
	FMixtormatImportResult Result;
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	if (!DesktopPlatform)
	{
		Result.Errors.Add(TEXT("Desktop platform services are unavailable."));
		return Result;
	}

	FString SelectedDirectory;
	const void* ParentWindow = FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr);
	if (!DesktopPlatform->OpenDirectoryDialog(
		ParentWindow,
		TEXT("Choose Mixtormat mask folder"),
		FPaths::ProjectContentDir(),
		SelectedDirectory))
	{
		Result.bCancelled = true;
		return Result;
	}

	return ImportMaskDirectory(SelectedDirectory);
}

FMixtormatImportResult FMixtormatSurfaceImporter::ImportMaskDirectory(const FString& SourceDirectory)
{
	using namespace MixtormatImporter;
	FMixtormatImportResult Result;

	TArray<FString> Files;
	IFileManager::Get().FindFiles(Files, *(SourceDirectory / TEXT("*.png")), true, false);
	if (Files.IsEmpty())
	{
		Result.Errors.Add(TEXT("No PNG mask files were found in the selected folder."));
		return Result;
	}
	Files.Sort();

	IAssetTools& AssetTools =
		FModuleManager::LoadModuleChecked<FAssetToolsModule>(TEXT("AssetTools")).Get();
	for (const FString& Filename : Files)
	{
		const FString SourceFile = SourceDirectory / Filename;
		UTexture2D* MaskTexture = ImportTexture(
			AssetTools,
			SourceFile,
			FMixtormatPaths::ProjectLibraryMasksRoot(),
			EMapType::Ram,
			Result);
		if (!MaskTexture)
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Failed to import mask %s."),
				*FPaths::GetCleanFilename(SourceFile)));
			continue;
		}

		const FMixtormatThumbnailUpdate ThumbnailUpdate =
			FMixtormatThumbnailRenderer::CreateOrUpdateMaskThumbnail(
				*MaskTexture,
				FMixtormatPaths::ProjectLibraryMaskThumbnailsRoot());
		if (!ThumbnailUpdate.IsValid())
		{
			Result.Errors.Add(ThumbnailUpdate.Error);
		}
		else if (ThumbnailUpdate.bChanged)
		{
			if (SaveMixtormatAsset(
				*ThumbnailUpdate.Texture,
				TEXT("mask thumbnail"),
				Result.Errors))
			{
				++Result.GeneratedThumbnailCount;
			}
		}
		else
		{
			++Result.ReusedThumbnailCount;
		}
		++Result.ImportedMaskCount;
	}
	return Result;
}

FMixtormatImportResult FMixtormatSurfaceImporter::ImportDirectory(
	const FString& SourceDirectory,
	const bool bUsePluginDestination)
{
	return ImportDirectoryInternal(SourceDirectory, bUsePluginDestination, FString(), false);
}

FMixtormatImportResult FMixtormatSurfaceImporter::ImportDirectoryInternal(
	const FString& SourceDirectory,
	const bool bUsePluginDestination,
	const FString& SourceBaseName,
	const bool bForceRefresh)
{
	using namespace MixtormatImporter;
	FMixtormatImportResult Result;

	TArray<FString> Files;
	IFileManager::Get().FindFiles(Files, *(SourceDirectory / TEXT("*.png")), true, false);
	if (Files.IsEmpty())
	{
		Result.Errors.Add(TEXT("No PNG texture files were found in the selected folder."));
		return Result;
	}

	TMap<FString, FTextureSet> TextureSets;
	for (const FString& File : Files)
	{
		const FString Stem = FPaths::GetBaseFilename(File);
		FString BaseName;
		EMapType MapType;
		if (!ParseMapName(Stem, BaseName, MapType)
			|| (!SourceBaseName.IsEmpty()
				&& !BaseName.Equals(SourceBaseName, ESearchCase::IgnoreCase)))
		{
			continue;
		}

		FTextureSet& Set = TextureSets.FindOrAdd(BaseName);
		Set.BaseName = BaseName;
		const FString FullPath = SourceDirectory / File;
		switch (MapType)
		{
		case EMapType::BaseColor: Set.BaseColorFile = FullPath; break;
		case EMapType::Normal: Set.NormalFile = FullPath; break;
		case EMapType::Ram:
			Set.RamFile = FullPath;
			break;
		case EMapType::RamHeight:
			Set.RamHeightFile = FullPath;
			break;
		default: break;
		}
	}
	if (TextureSets.IsEmpty())
	{
		Result.Errors.Add(SourceBaseName.IsEmpty()
			? FString(TEXT("No recognized Mixtormat texture sets were found in the selected folder."))
			: FString::Printf(TEXT("No texture set was found for %s."), *SourceBaseName));
		return Result;
	}

	UMaterial* PreviewMaster = LoadSubstrateMaster();
	if (!PreviewMaster)
	{
		Result.Errors.Add(FString::Printf(
			TEXT("Required master material is missing: %s"),
			*FMixtormatPaths::MasterMaterialObjectPath()));
		return Result;
	}

	IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>(TEXT("AssetTools")).Get();
	FMixtormatThumbnailRenderer ThumbnailRenderer;
	for (const TPair<FString, FTextureSet>& Pair : TextureSets)
	{
		const FTextureSet& Set = Pair.Value;
		if (!Set.IsComplete())
		{
			TArray<FString> MissingMaps;
			if (Set.BaseColorFile.IsEmpty()) MissingMaps.Add(TEXT("_BC"));
			if (Set.NormalFile.IsEmpty()) MissingMaps.Add(TEXT("_N"));
			if (Set.RamFile.IsEmpty() && Set.RamHeightFile.IsEmpty())
			{
				MissingMaps.Add(TEXT("_RAM or _RAMH"));
			}
			Result.Errors.Add(FString::Printf(
				TEXT("%s is missing %s."),
				*Set.BaseName,
				*FString::Join(MissingMaps, TEXT(", "))));
			continue;
		}
		const bool bHasAuthoredHeight = !Set.RamHeightFile.IsEmpty();
		if (bHasAuthoredHeight && !Set.RamFile.IsEmpty())
		{
			Result.Errors.Add(FString::Printf(
				TEXT("%s contains both _RAM and _RAMH; authored _RAMH was selected."),
				*Set.BaseName));
		}

		FString Identity = Set.BaseName;
		Identity.RemoveFromStart(TEXT("TX_"));
		TArray<FString> Parts;
		Identity.ParseIntoArray(Parts, TEXT("_"), true);
		const FString Family = Parts.IsEmpty() ? TEXT("Uncategorized") : Parts[0];
		const FString TexturePath = bUsePluginDestination
			? FMixtormatPaths::RawTextureFamilyRoot(Family)
			: FMixtormatPaths::ProjectLibraryRawTextureFamilyRoot(Family);
		const FString SurfacePath = bUsePluginDestination
			? FMixtormatPaths::SurfaceFamilyRoot(Family)
			: FMixtormatPaths::ProjectLibrarySurfaceFamilyRoot(Family);
		const FString PreviewMaterialPath = bUsePluginDestination
			? FMixtormatPaths::MaterialInstanceFamilyRoot(Family)
			: FMixtormatPaths::ProjectLibraryMaterialInstanceFamilyRoot(Family);
		const FString ThumbnailPath = bUsePluginDestination
			? FMixtormatPaths::SurfaceThumbnailFamilyRoot(Family)
			: FMixtormatPaths::ProjectLibrarySurfaceThumbnailFamilyRoot(Family);
		FString SurfaceAssetName = Set.BaseName;
		SurfaceAssetName.RemoveFromStart(TEXT("TX_"));
		SurfaceAssetName = TEXT("DA_") + SurfaceAssetName;
		UMixtormatSurface* Surface = CreateOrLoadSurface(
			AssetTools,
			SurfaceAssetName,
			SurfacePath);
		if (!Surface)
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Failed to create surface asset %s."),
				*SurfaceAssetName));
			continue;
		}

		UTexture2D* BaseColor = ImportTexture(
			AssetTools, Set.BaseColorFile, TexturePath, EMapType::BaseColor, Result, bForceRefresh);
		UTexture2D* Normal = ImportTexture(
			AssetTools, Set.NormalFile, TexturePath, EMapType::Normal, Result, bForceRefresh);
		const FString& PackedSourceFile = bHasAuthoredHeight ? Set.RamHeightFile : Set.RamFile;
		UTexture2D* SourceRam = ImportTexture(
			AssetTools,
			PackedSourceFile,
			TexturePath,
			bHasAuthoredHeight ? EMapType::RamHeight : EMapType::Ram,
			Result,
			bForceRefresh);
		if (!BaseColor || !Normal || !SourceRam)
		{
			Result.Errors.Add(FString::Printf(TEXT("Failed to import the _BC, _N, and packed RAM texture set for %s."), *Set.BaseName));
			continue;
		}
		const FIntPoint BaseColorSourceSize(
			BaseColor->Source.GetSizeX(),
			BaseColor->Source.GetSizeY());
		const FIntPoint NormalSourceSize(
			Normal->Source.GetSizeX(),
			Normal->Source.GetSizeY());
		const FIntPoint RamSourceSize(
			SourceRam->Source.GetSizeX(),
			SourceRam->Source.GetSizeY());
		if (BaseColorSourceSize != NormalSourceSize
			|| BaseColorSourceSize != RamSourceSize)
		{
			Result.Errors.Add(FString::Printf(
				TEXT("Texture source dimensions do not match for %s: BC %dx%d, N %dx%d, RAM %dx%d."),
				*Set.BaseName,
				BaseColorSourceSize.X,
				BaseColorSourceSize.Y,
				NormalSourceSize.X,
				NormalSourceSize.Y,
				RamSourceSize.X,
				RamSourceSize.Y));
			continue;
		}

		UTexture2D* Ram = SourceRam;
		FString DerivedHeightSourceHash;
		EMixtormatBlendHeightProvenance HeightProvenance = bHasAuthoredHeight
			? EMixtormatBlendHeightProvenance::AuthoredRAMH
			: EMixtormatBlendHeightProvenance::None;
		if (!bHasAuthoredHeight)
		{
			DerivedHeightSourceHash = MakeDerivedHeightSourceHash(
				Set.NormalFile,
				Set.RamFile,
				Normal->bFlipGreenChannel);
			UTexture2D* DerivedRAMH = bForceRefresh
				? nullptr
				: LoadReusableDerivedRAMH(
					*Surface,
					TexturePath,
					Set.BaseName,
					DerivedHeightSourceHash);
			if (DerivedRAMH)
			{
				++Result.ReusedTextureCount;
			}
			else
			{
				DerivedRAMH = BuildDerivedRAMH(
					*Normal,
					*SourceRam,
					TexturePath,
					Set.BaseName,
					Result);
			}
			if (DerivedRAMH)
			{
				Ram = DerivedRAMH;
				HeightProvenance = EMixtormatBlendHeightProvenance::DerivedFromNormal;
			}
		}

		UMaterialInstanceConstant* PreviewMaterial = CreateOrUpdatePreviewMaterial(
			AssetTools,
			*PreviewMaster,
			SurfaceAssetName,
			PreviewMaterialPath,
			*BaseColor,
			*Normal,
			*Ram,
			Surface->DefaultIOR);
		if (!PreviewMaterial)
		{
			Result.Errors.Add(FString::Printf(TEXT("Failed to create preview instance for %s."), *Set.BaseName));
			continue;
		}

		const FString SurfaceThumbnailHash = MakeSurfaceThumbnailSourceHash(
			Set,
			PackedSourceFile,
			Surface->DefaultIOR,
			*PreviewMaterial);
		UTexture2D* SurfaceThumbnail = Surface->Thumbnail.Get();
		FString StoredThumbnailHash = Surface->ThumbnailSourceHash;
		const bool bCanReuseThumbnail = !bForceRefresh
			&& SurfaceThumbnail
			&& SurfaceThumbnail->Source.GetSizeX() == MixtormatPreviewSceneSettings::SurfaceThumbnailResolution
			&& SurfaceThumbnail->Source.GetSizeY() == MixtormatPreviewSceneSettings::SurfaceThumbnailResolution
			&& StoredThumbnailHash.Equals(SurfaceThumbnailHash, ESearchCase::CaseSensitive);
		if (bCanReuseThumbnail)
		{
			++Result.ReusedThumbnailCount;
		}
		else
		{
			const FMixtormatThumbnailUpdate ThumbnailUpdate =
				ThumbnailRenderer.CreateOrUpdateSurfaceThumbnail(
					*PreviewMaterial,
					ThumbnailPath,
					SurfaceAssetName);
			if (!ThumbnailUpdate.IsValid())
			{
				Result.Errors.Add(ThumbnailUpdate.Error);
			}
			else if (!ThumbnailUpdate.bChanged || SaveMixtormatAsset(
				*ThumbnailUpdate.Texture,
				TEXT("surface thumbnail"),
				Result.Errors))
			{
				SurfaceThumbnail = ThumbnailUpdate.Texture;
				StoredThumbnailHash = SurfaceThumbnailHash;
				if (ThumbnailUpdate.bChanged)
				{
					++Result.GeneratedThumbnailCount;
				}
				else
				{
					++Result.ReusedThumbnailCount;
				}
			}
		}

		Surface->Modify();
		SetIdentity(*Surface, Set.BaseName, Family);
		Surface->BaseColor = BaseColor;
		Surface->Normal = Normal;
		Surface->RoughnessAOMetallic = Ram;
		Surface->bHasBlendHeight = HeightProvenance
			!= EMixtormatBlendHeightProvenance::None;
		Surface->BlendHeightProvenance = HeightProvenance;
		Surface->DerivedHeightSourceHash = HeightProvenance
			== EMixtormatBlendHeightProvenance::DerivedFromNormal
			? DerivedHeightSourceHash
			: FString();
		Surface->PreviewMaterial = PreviewMaterial;
		Surface->Thumbnail = SurfaceThumbnail;
		Surface->ThumbnailSourceHash = StoredThumbnailHash;
		Surface->MarkPackageDirty();
		const bool bPreviewSaved = SaveMixtormatAsset(
			*PreviewMaterial,
			TEXT("preview material instance"),
			Result.Errors);
		const bool bSurfaceSaved = SaveMixtormatAsset(
			*Surface,
			TEXT("Mixtormat surface"),
			Result.Errors);
		if (bPreviewSaved && bSurfaceSaved)
		{
			++Result.ImportedSurfaceCount;
		}
	}

	return Result;
}
