// Copyright 2026 Hugo Beyer. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "MixtormatMask.generated.h"

class UTexture2D;

UCLASS(BlueprintType)
class MIXTORMATRUNTIME_API UMixtormatMask final : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	virtual FPrimaryAssetId GetPrimaryAssetId() const override;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity")
	FText DisplayName;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, AssetRegistrySearchable, Category = "Identity")
	FName Category;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity")
	TArray<FName> Tags;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Mask")
	TObjectPtr<UTexture2D> MaskTexture;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Preview")
	TObjectPtr<UTexture2D> Thumbnail;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults", meta = (UIMin = "1.0", UIMax = "16.0", Delta = "1.0"))
	float DefaultTiling = 1.0f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	bool bDefaultInvert = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults", meta = (UIMin = "-1.0", UIMax = "1.0"))
	float DefaultOffset = 0.0f;
};
