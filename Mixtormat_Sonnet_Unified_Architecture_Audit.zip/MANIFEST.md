# Mixtormat Unified Architecture Audit Snapshot

Revision: unverified local workspace (no Git metadata/revision inspection performed; last user-reported remote commit: eee6df1)

Missing requested paths: none found in the requested scope.

Relevant associated implementation files included for tracing: Source/MixtormatShaders/Private/Effects/MixtormatEffectPassesPrivate.h, Source/MixtormatRuntime/Private/MixtormatChildScope.cpp, Source/MixtormatRuntime/Private/MixtormatMaterial.cpp.

Excluded dependencies: Excluded adjacent project dependencies include Unreal Engine headers/libraries and plugin module/build configuration; editor sources also reference supporting Editor settings, parameter definitions, style, and UI modules not in this scoped audit set.

Files included:
- AGENTS.md
- AgentDocs/COMPOSITION.md
- AgentDocs/FILE_MAP.md
- AgentDocs/GENERATORS.md
- AgentDocs/Prototypes/Wrinkling/wrinkling01.cl
- AgentDocs/Prototypes/Wrinkling/wrinkling02.cl
- AgentDocs/Prototypes/Wrinkling/wrinkling_prepwrangle.vfl
- AgentDocs/SHADERS.md
- AgentDocs/UI.md
- AgentDocs/audits/colorrampaudit.md
- AgentDocs/code_docs/wrinkle_curvature_pinch_plan.md
- Shaders/Private/MixtormatColorOps.ush
- Shaders/Private/MixtormatColorRampCapacity.ush
- Shaders/Private/MixtormatComposite.usf
- Shaders/Private/MixtormatErosion.usf
- Shaders/Private/MixtormatFlow.usf
- Shaders/Private/MixtormatFlow.ush
- Shaders/Private/MixtormatGeneratorHeightColorRamp.usf
- Shaders/Private/MixtormatGeneratorHeightModules.ush
- Shaders/Private/MixtormatGeneratorStructuralWarp.usf
- Shaders/Private/MixtormatMaskCurvature.usf
- Shaders/Private/MixtormatNoise.usf
- Source/MixtormatEditor/Private/UI/Containers/SMixtormatFoldoutHeader.cpp
- Source/MixtormatEditor/Private/UI/Containers/SMixtormatFoldoutHeader.h
- Source/MixtormatEditor/Private/UI/Controls/SMixtormatColorRamp.cpp
- Source/MixtormatEditor/Private/UI/Controls/SMixtormatColorRamp.h
- Source/MixtormatEditor/Private/UI/Controls/SMixtormatRampEditor.cpp
- Source/MixtormatEditor/Private/UI/Controls/SMixtormatRampEditor.h
- Source/MixtormatEditor/Private/UI/Layers/SMixtormatLayerChildRow.cpp
- Source/MixtormatEditor/Private/UI/Layers/SMixtormatLayerChildRow.h
- Source/MixtormatEditor/Private/UI/Layers/SMixtormatLayerRow.cpp
- Source/MixtormatEditor/Private/UI/Layers/SMixtormatLayerRow.h
- Source/MixtormatEditor/Private/UI/Layers/SMixtormatSourcesShelf.cpp
- Source/MixtormatEditor/Private/UI/Layers/SMixtormatSourcesShelf.h
- Source/MixtormatEditor/Private/UI/Menus/SMixtormatStructuralSourcePicker.cpp
- Source/MixtormatEditor/Private/UI/Menus/SMixtormatStructuralSourcePicker.h
- Source/MixtormatEditor/Private/Widgets/Inspector/MixtormatInspectorEffects.cpp
- Source/MixtormatEditor/Private/Widgets/Inspector/MixtormatInspectorGenerators.cpp
- Source/MixtormatEditor/Private/Widgets/Inspector/MixtormatInspectorIds.cpp
- Source/MixtormatEditor/Private/Widgets/Layers/MixtormatStructuralConnectionModel.cpp
- Source/MixtormatEditor/Private/Widgets/Layers/MixtormatStructuralConnectionModel.h
- Source/MixtormatEditor/Private/Widgets/Layers/MixtormatStructuralConnections.cpp
- Source/MixtormatEditor/Private/Widgets/MixtormatChildCapabilities.cpp
- Source/MixtormatEditor/Private/Widgets/SMixtormat.h
- Source/MixtormatEditor/Private/Widgets/SMixtormat_Layers.cpp
- Source/MixtormatEditor/Private/Widgets/SMixtormat_Shell.cpp
- Source/MixtormatRuntime/Private/MixtormatChildScope.cpp
- Source/MixtormatRuntime/Private/MixtormatColorRampMath.cpp
- Source/MixtormatRuntime/Private/MixtormatEffect.cpp
- Source/MixtormatRuntime/Private/MixtormatLayerGroups.cpp
- Source/MixtormatRuntime/Private/MixtormatMaterial.cpp
- Source/MixtormatRuntime/Private/MixtormatOutputReference.cpp
- Source/MixtormatRuntime/Private/MixtormatParameterBinding.cpp
- Source/MixtormatRuntime/Private/MixtormatSurface.cpp
- Source/MixtormatRuntime/Public/MixtormatChildScope.h
- Source/MixtormatRuntime/Public/MixtormatColorRamp.h
- Source/MixtormatRuntime/Public/MixtormatColorRampMath.h
- Source/MixtormatRuntime/Public/MixtormatEffect.h
- Source/MixtormatRuntime/Public/MixtormatGeneratorTypes.h
- Source/MixtormatRuntime/Public/MixtormatIdTypes.h
- Source/MixtormatRuntime/Public/MixtormatLayerGroups.h
- Source/MixtormatRuntime/Public/MixtormatLayerTypes.h
- Source/MixtormatRuntime/Public/MixtormatMaterial.h
- Source/MixtormatRuntime/Public/MixtormatOutputReference.h
- Source/MixtormatRuntime/Public/MixtormatParameterBinding.h
- Source/MixtormatRuntime/Public/MixtormatParameterDefinition.h
- Source/MixtormatRuntime/Public/MixtormatParameterTypes.h
- Source/MixtormatRuntime/Public/MixtormatReliefScaling.h
- Source/MixtormatRuntime/Public/MixtormatSurface.h
- Source/MixtormatShaders/Private/Compositing/MixtormatComposeHash.cpp
- Source/MixtormatShaders/Private/Compositing/MixtormatComposeHash.h
- Source/MixtormatShaders/Private/Compositing/MixtormatEffectGather.cpp
- Source/MixtormatShaders/Private/Compositing/MixtormatEffectGather.h
- Source/MixtormatShaders/Private/Compositing/MixtormatGatherCommon.h
- Source/MixtormatShaders/Private/Compositing/MixtormatGeneratorGather.cpp
- Source/MixtormatShaders/Private/Compositing/MixtormatGeneratorGather.h
- Source/MixtormatShaders/Private/Compositing/MixtormatIdGather.cpp
- Source/MixtormatShaders/Private/Compositing/MixtormatIdGather.h
- Source/MixtormatShaders/Private/Compositing/MixtormatLayerGather.cpp
- Source/MixtormatShaders/Private/Compositing/MixtormatLayerGather.h
- Source/MixtormatShaders/Private/Compositing/MixtormatMaskGather.cpp
- Source/MixtormatShaders/Private/Compositing/MixtormatMaskGather.h
- Source/MixtormatShaders/Private/Effects/MixtormatEffectPassesPrivate.h
- Source/MixtormatShaders/Private/Effects/MixtormatErosionPasses.cpp
- Source/MixtormatShaders/Private/Effects/MixtormatGradePasses.cpp
- Source/MixtormatShaders/Private/MixtormatGpuComposePipeline.cpp
- Source/MixtormatShaders/Private/MixtormatGpuCompositor.cpp
- Source/MixtormatShaders/Private/MixtormatGpuCompositorInternal.h
- Source/MixtormatShaders/Private/MixtormatGpuGeneratorPasses.cpp
- Source/MixtormatShaders/Private/MixtormatGpuNoisePasses.cpp
