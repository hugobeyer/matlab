// Copyright 2026 Hugo Beyer. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "MixtormatMaterial.h"
#include "MixtormatParameterDefinition.h"
#include "Style/MixtormatDesignTokens.h"
#include "Widgets/SMixtormatPreviewViewport.h"
#include "Widgets/SMixtormatOverlayPanel.h"
#include "Widgets/MixtormatChildCapabilities.h"
#include "Widgets/MixtormatChildAddress.h"
#include "UI/Rows/SMixtormatRow.h"
#include "UI/Controls/SMixtormatSlider.h"
#include "UI/Parameters/MixtormatParameterUiMeta.h"
#include "UI/Parameters/MixtormatParameterAuthoring.h"
#include "Framework/Application/IInputProcessor.h"
#include "Widgets/SCompoundWidget.h"
#include "UObject/StrongObjectPtr.h"
#include "Materials/MaterialInstanceConstant.h"

// Declared, not included: only a reference to the builder crosses this header.
namespace MixtormatMenu { class FBuilder; }

class FAssetThumbnail;
class FAssetThumbnailPool;
class FMixtormatChildDragDropOp;
class UMaterialInterface;
class IToolTip;
class SBox;
class SButton;
class SHorizontalBox;
class SMenuAnchor;
class SScrollBox;
class STextBlock;
class SVerticalBox;
class SWrapBox;
class SWidgetSwitcher;
class SWindow;
class UScriptStruct;
struct FAssetData;
struct FMixtormatBakeSettings;
struct FMixtormatProjectedChildRow;
struct FMixtormatStructuralRelationshipPresentation;
struct FMixtormatLayerHierarchyPaint;
struct FMixtormatSurfaceEntry;

// What an Add-menu entry creates.
//
// Not the same thing as EMixtormatLayerChildType, and deliberately so: Texture Mask and Layer
// Values Mask are both EMixtormatLayerChildType::Mask, and Strata Carver is a Generator with its
// kind set. This names what the artist picked, which is what both Add menus are authored against,
// and MixtormatChildCreate::ApplyDefaults turns one of these into a configured child. Editor-only
// and never serialised, so it is free to be reordered.
enum class EMixtormatChildCreation : uint8
{
	PatternIds,
	IdGroup,
	SurfaceIds,
	ClusterIds,

	HsvFromIds,
	RampFromIds,
	UvFromIds,
	ReliefFromIds,
	BoundaryFromIds,
	LayerValuesMask,
	NoiseMask,
	GeneratedMask,
	ColorIdMask,
	RandomFromIds,
	StrataCarver,
	Cracks,
	RockFormation,
	Pebbles,
	CliffStrata,
	Noise,
	// Generator-layer sublayers.
	HeightBlend,
	HeightCurve,
	HeightColorRamp,
	Peeling,
	HeightPush,
	StructuralWarp,
};

// Editor-only connection role; the existing payload remains the serialized truth.
enum class EMixtormatStructuralConnectionRole : uint8 { Source, Target };

// Where an Add menu puts what it creates: one layer's child stack, or a group's shared one.
//
// The whole reason the layer and group Add menus can share a taxonomy. Everything above the
// creation call -- the submenu tree, the labels, the icons, the ordering -- is identical for both,
// and this is the only thing that differs.
struct FMixtormatAddTarget
{
	int32 LayerIndex = INDEX_NONE;
	FGuid GroupId;
	FGuid ScopeOwnerChildId;

	static FMixtormatAddTarget Layer(const int32 InLayerIndex)
	{
		FMixtormatAddTarget Target;
		Target.LayerIndex = InLayerIndex;
		return Target;
	}

	static FMixtormatAddTarget Group(const FGuid InGroupId)
	{
		FMixtormatAddTarget Target;
		Target.GroupId = InGroupId;
		return Target;
	}

	bool IsGroup() const { return GroupId.IsValid(); }
};

// FMixtormatPreviewOutputDesc/FMixtormatChildPreviewOutputSet used to be preview-only and hardcode
// their own notion of what a child publishes, separately from the clipboard's Copy Instance Mask
// menus. Both now read one shared FMixtormatChildCapabilities descriptor (a publish/copy/preview
// distinction the old preview-only struct could not express -- Pattern IDs' Gap is copyable but
// deliberately not a second preview option, since the default Region IDs preview already renders
// it). FMixtormatPreviewOutputDesc/Set below are kept as the preview system's own view, now derived
// from capabilities rather than hand-authored a second time.
struct FMixtormatPreviewOutputDesc
{
	FName Name;
	FText Label;
	EMixtormatPreviewOutputKind Kind = EMixtormatPreviewOutputKind::Mask;
	FName GapMaskName;
};

// What a child can show through the generic preview eye: the one output the eye itself toggles
// (empty when the child publishes nothing previewable), and any further outputs reachable only
// through the small chevron beside the eye. A child with no secondary outputs gets no chevron.
struct FMixtormatChildPreviewOutputSet
{
	TOptional<FMixtormatPreviewOutputDesc> Primary;
	TArray<FMixtormatPreviewOutputDesc> Secondary;
};

// Derived from GetChildCapabilities: the entry with bPreviewable && !bSecondaryPreview becomes
// Primary, every bPreviewable && bSecondaryPreview entry becomes Secondary. The inspector's
// eye/chevron widget and its status label read this rather than naming a child type themselves,
// so a new producer needs one case in GetChildCapabilities and nothing else.
FMixtormatChildPreviewOutputSet GetChildPreviewOutputSet(const FMixtormatLayerChild& Child);

// Convenience for an inspector group whose panel is built for one known, fixed child kind (the
// panel is only ever visible while a child of that kind is selected): the descriptor set depends
// only on the kind, never on which specific instance is selected, so there is nothing to resolve
// against the live selection here.
FMixtormatChildPreviewOutputSet GetPreviewOutputSetForChildType(EMixtormatLayerChildType Type);
FMixtormatChildPreviewOutputSet GetPreviewOutputSetForEffectType(EMixtormatEffectType EffectType);

class SMixtormat final : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SMixtormat) {}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);
	virtual ~SMixtormat() override;
	virtual bool SupportsKeyboardFocus() const override { return true; }
	virtual FReply OnPreviewKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
	virtual FReply OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override;
	// The floating inspector's drag and resize. Unhandled unless Overlay is active and the press
	// landed on the panel's own chrome, so nothing else in the workspace changes.
	virtual FReply OnMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
		virtual FReply OnDragDetected(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	// Tunnel phase: a press inside a floating panel brings it to the front before the press is
	// routed to the control under it (D25).
	virtual FReply OnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnMouseButtonUp(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual void OnMouseCaptureLost(const FCaptureLostEvent& CaptureLostEvent) override;
	virtual FCursorReply OnCursorQuery(const FGeometry& MyGeometry, const FPointerEvent& CursorEvent) const override;
	bool CanCloseTab();

private:

	struct FEditHistoryState
	{
		TArray<FMixtormatLayer> Layers;
		// Groups are part of the same edit as the layers they hold -- membership lives on the
		// layer, so restoring one without the other leaves a layer in a group that is not there.
		TArray<FMixtormatLayerGroup> Groups;
		// Sources shelf entries ride the same edit: they are document data, and an undo that
		// restored layers but not sources would resurrect a deleted source or lose a new one.
		TArray<FMixtormatSourceEntry> Sources;
		bool bRotateUV90 = false;
		FMixtormatFinalSettings FinalSettings;
	};

	struct FNumericResetBinding
	{
		TWeakPtr<SWidget> Widget;
		FSimpleDelegate Reset;
	};

	struct FEnumResetBinding
	{
		TWeakPtr<SWidget> Widget;
		FSimpleDelegate Reset;
	};
	void BuildWorkspaceUI();
	void HandleReferencedCompositionUpdated(const FAssetData& AssetData);
	FReply OpenThemePanel();
	FReply OpenDocumentation();
	FReply OpenSettings();
	// Theme refresh modes
	enum class EThemeRefreshMode : uint8
	{
		Paint,
		Layout,
		StyleRefresh,
		Reconstruct
	};

	void RequestThemeRefresh(EThemeRefreshMode Mode = EThemeRefreshMode::Reconstruct);
	EActiveTimerReturnType ApplyPendingTheme(double CurrentTime, float DeltaTime);
	FReply ShowLeftPage(int32 PageIndex);
	FReply ImportSurfaces();
	FReply ImportMasks();
	FReply RefreshSurfaceList();
	FReply RebuildBuiltInLibrary();
	void ZoomMaterialGallery(int32 Direction);
	void ZoomMaskGallery(int32 Direction);
	FReply SelectSurface(FText DisplayName, FSoftObjectPath AssetPath);
	FReply SelectMask(FText DisplayName, FSoftObjectPath AssetPath);
	FReply HandleSurfaceDropped(FText DisplayName, FSoftObjectPath AssetPath);
	// The positional form. GroupId valid means the drop named a group, so the new layer joins it.
	FReply HandleSurfaceDroppedAt(
		FText DisplayName,
		FSoftObjectPath AssetPath,
		int32 InsertIndex,
		FGuid GroupId);
	FReply SetCategoryFilter(FName Family);
	FReply SetPreviewMesh(EMixtormatPreviewMesh MeshType);
	void SetGlobalUVRotation90(bool bEnabled);
	FReply SetPreviewQuality(EMixtormatPreviewQuality Quality);
	FReply SetPreviewAntiAliasing(EMixtormatPreviewAntiAliasing AntiAliasing);
	void SetPreviewScreenPercentage(int32 Percentage);
	void SetPreviewFov(float FovDegrees);
	FReply ResetPreviewCameraAndLighting();
	void SetPreviewDisplacementEnabled(bool bEnabled);
	void SetPreviewDisplacementAmount(float Amount);
	void SetPreviewLightIntensity(float Scale);
	void SetPreviewSkylightIntensity(float Scale);
	void PreviewSelectedSurfaceWithDisplacement();
	FReply ToggleFeaturePreview(EMixtormatDebugPreviewMode Mode);
	TSharedRef<SWidget> MakeFeaturePreviewButton(
		EMixtormatDebugPreviewMode Mode,
		const FText& ToolTip,
		// Card default, not the preview eye's: every caller of this is a card header action,
		// and the handful that are not pass an explicit size anyway. PreviewEyeSize is a preview
		// token and reading it here coupled the card's chrome to the viewport's metrics.
		float IconSize = MixtormatTokens::GroupCardLeadingIconSize);
	// The generic child preview: a normal single-click eye for OutputSet.Primary (the same
	// SMixtormatIconButton widget and toggle behaviour every other feature-preview eye uses), plus
	// -- only when OutputSet.Secondary is non-empty -- a small chevron beside it opening a
	// categorized menu of further outputs (Breakup's Edge/Pieces/Gap today). The eye never becomes
	// a menu itself. An unset Primary (nothing to preview) returns SNullWidget.
	TSharedRef<SWidget> MakeChildOutputPreviewButton(
		const FMixtormatChildPreviewOutputSet& OutputSet);
	FReply ToggleChildOutputPreview(const FMixtormatChildPreviewTarget& Target);
	FReply CycleSelectedModulePreview();
	// Resolves the currently selected child to a preview target naming OutputName/Kind (and,
	// for a RegionIds output, GapMaskName) on it. A group-authored selection is flattened to one
	// concrete enabled member layer and that member's effective child id here, so nothing
	// downstream has to know what a group is. Returns an invalid target (OwnerId/ChildId unset)
	// when nothing resolves.
	FMixtormatChildPreviewTarget ResolveChildPreviewTarget(
		FName OutputName, EMixtormatPreviewOutputKind Kind, FName GapMaskName = NAME_None) const;
	// The generic replacement for the old Pattern/Cluster-only CanPreviewSelectedFilter: enabled
	// state plus whatever domain readiness a child's own output kind genuinely requires (Cluster
	// IDs' packed-source requirement).
	bool IsChildOutputPreviewReady(const FMixtormatLayerChild& Child) const;
	bool IsSelectedOutputPreviewReady() const;
	FReply SetStudioLighting(EMixtormatStudioLighting LightingPreset);
	FReply StartNewMaterial();
	// Starts a recipe whose first layer is LayerType. A Fill needs no library surface.
	FReply StartNewMaterialWith(EMixtormatLayerType LayerType);
	// Adds a layer, starting a recipe first if none is open.
	FReply AddLayerOrStartMaterial(EMixtormatLayerType LayerType);
	TSharedRef<SWidget> BuildLayerColumnContextMenu();
	TSharedRef<SWidget> BuildFinalSettingsControls();
	// True when the selected child is an instance whose source is (OwnerId, ChildId).
	bool IsSourceOfSelectedInstance(const FGuid& OwnerId, const FGuid& ChildId) const;
	void InitializeNewLayer(FMixtormatLayer& Layer, EMixtormatLayerType LayerType, int32 LayerNumber) const;
	FReply AddGeneratorLayer(EMixtormatGeneratorType Type);
	TSharedRef<SWidget> BuildAddGeneratorLayerMenu();
	FReply NewWorkingMaterial();
	FReply OpenWorkingMaterial();
	FReply SaveWorkingMaterial();
	FReply SaveWorkingMaterialAs();
	FReply BakeWorkingMaterial();
	FReply ExecuteBake(
		const FMixtormatBakeSettings& Settings,
		bool bConfirmExistingOutputs);
	void ApplyBakedMaterialToSelectedActors(UMaterialInterface& Material);
	FReply SetCompositionResolution(int32 Resolution);
	FReply UndoMaterialEdit();
	FReply RedoMaterialEdit();
	FReply AddWorkingLayer(EMixtormatLayerType LayerType);
	FReply DuplicateSelectedLayer();
	FReply DeleteSelectedLayer();
	FReply HandleLayerDropped(int32 SourceLayerIndex, int32 TargetLayerIndex, bool bRecordHistory = true,
			const FGuid* ExplicitGroupId = nullptr);
	FReply SelectWorkingLayer(int32 LayerIndex);
	FReply SelectWorkingChild(int32 LayerIndex, int32 ChildIndex);
	FReply AssignMaskToLayer(int32 LayerIndex, FSoftObjectPath MaskPath);
	FReply AddBlurToMask(int32 LayerIndex, int32 OwnerChildIndex);
	FReply AddMaskFilterToLayerChild(int32 LayerIndex, int32 OwnerChildIndex, EMixtormatLayerChildType ChildType);
	// The same two, on a group's shared stack. A group mask carries the scoped children a layer's
	// mask does; the runtime rebinds them per member when it flattens the group.
	FReply AddMaskFilterToGroupChild(FGuid GroupId, int32 OwnerChildIndex, EMixtormatLayerChildType ChildType);
	FReply AddFlowWarpToGroupChild(FGuid GroupId, int32 OwnerChildIndex);
	FReply AddCurvatureToMask(int32 LayerIndex, int32 OwnerChildIndex);
	FMixtormatMaskCurvature* GetSelectedLayerCurvature();
	const FMixtormatMaskCurvature* GetSelectedLayerCurvature() const;
	TSharedRef<SWidget> BuildMaskCurvatureControls();
	TSharedRef<SWidget> BuildCurvatureSourceMenu(int32 LayerIndex, int32 ChildIndex);
	TSharedRef<SWidget> BuildCurvatureModeMenu(int32 LayerIndex, int32 ChildIndex);
	FReply AssignScopedMaskToChild(int32 LayerIndex, int32 OwnerChildIndex, FSoftObjectPath MaskPath);
	FReply ReplaceMaskInLayer(int32 LayerIndex, int32 MaskIndex, FSoftObjectPath MaskPath);
	FReply ReplaceSurfaceInLayer(int32 LayerIndex, FSoftObjectPath SurfacePath);
	FReply ClearLayerMask(int32 LayerIndex);
	FReply RemoveMaskFromLayer(int32 LayerIndex, int32 ChildIndex);
	FReply ReorderLayerChild(int32 LayerIndex, int32 SourceChildIndex, int32 TargetChildIndex);
	FReply DuplicateLayerChild(int32 LayerIndex, int32 ChildIndex);
	FReply MoveChildToLayer(int32 SourceLayerIndex, int32 ChildIndex, int32 DestLayerIndex, int32 DestChildIndex = INDEX_NONE);
	// Same move, but the destination is a group's shared stack rather than another layer: the
	// child leaves its layer and becomes something every member composites, instead of landing in
	// one member in particular.
	FReply MoveChildToGroup(int32 SourceLayerIndex, int32 ChildIndex, FGuid GroupId);
	// The reverse of MoveChildToGroup: the shared child leaves the group and becomes this one
	// layer's own, so every other member loses it.
	FReply MoveGroupChildToLayer(FGuid GroupId, int32 ChildIndex, int32 DestLayerIndex, int32 DestChildIndex = INDEX_NONE);

	// Mirrors every instance's payload down from its source, so the inspector, the badges and the
	// row names all read the resolved values without a second read path. Run on every refresh; the
	// compositor resolves again on its own copy regardless.
	void SyncChildInstances();
	bool IsSelectedChildInstance() const;
	FText GetSelectedInstanceSourceText() const;
	TSharedRef<SWidget> BuildInstanceBanner();

	// True when the parameter belongs to a child that is a live instance. Inherited data is the
	// source's to change, so the row refuses the write rather than breaking the instance under a
	// user who only meant to drag a slider.
	bool IsParameterLocked(const FMixtormatParameterAddress& Target) const;

	// A child is addressed by (LayerIndex, ChildIndex) throughout most of SMixtormat; these turn
	// that pair, or a group child's (GroupId, ChildIndex), into the owner-agnostic address the
	// clipboard and instance placement now use.
	FMixtormatChildAddress MakeChildAddress(int32 LayerIndex, int32 ChildIndex) const;
	FMixtormatChildAddress MakeGroupChildAddress(FGuid GroupId, int32 ChildIndex) const;
	FMixtormatChildAddress GetSelectedChildAddress() const;
	// The child array an address names -- WorkingLayers[x].Children or a group's shared Children --
	// so every clipboard/placement operation below reads and writes through one lookup rather than
	// branching on OwnerType itself.
	TArray<FMixtormatLayerChild>* ResolveContainer(const FMixtormatChildAddress& Address);
	const TArray<FMixtormatLayerChild>* ResolveContainer(const FMixtormatChildAddress& Address) const;
	FMixtormatLayerChild* ResolveChildAt(const FMixtormatChildAddress& Address);
	const FMixtormatLayerChild* ResolveChildAt(const FMixtormatChildAddress& Address) const;
	int32 ResolveChildIndexAt(const FMixtormatChildAddress& Address) const;
	bool StructuralLinksPreserved(const TArray<FMixtormatLayer>& ProposedLayers,
		const TArray<FMixtormatLayerGroup>& ProposedGroups, FText& OutReason) const;
	bool CanMovePublishedOutputs(const FMixtormatChildAddress& Source, const FMixtormatChildAddress& Dest,
		int32 InsertIndex, FText* OutReason = nullptr) const;
	bool CanMoveChildIntoIdGroup(const FMixtormatChildAddress& Source, const FMixtormatChildAddress& Dest,
		FText* OutReason = nullptr) const;
	FReply MoveChildIntoIdGroup(const FMixtormatChildAddress& Source, const FMixtormatChildAddress& Dest);
	FMixtormatChildAddress GetDraggedChildAddress(const FMixtormatChildDragDropOp& Operation) const;
	bool CanDropChildIntoIdGroup(const FMixtormatChildDragDropOp& Operation, FMixtormatChildAddress Dest) const;
	bool CanAddIdGroupSource(const FMixtormatChildAddress& Source, const FMixtormatChildAddress& Dest) const;
	FReply AddIdGroupSource(const FMixtormatChildAddress& Source, const FMixtormatChildAddress& Dest);
	bool ResolveIdGroupPasteReference(FMixtormatLayerChild& Reference) const;
	TSharedRef<SWidget> BuildIdGroupSourceMenu(FMixtormatChildAddress Dest);
	TSharedRef<SWidget> BuildOutputReferenceSourceMenu(FMixtormatChildAddress Dest);
	// The shared body of both menus: lists every producer that publishes a bCopyableAsField output
	// of the requested kind. RegionIds keeps its IdGroup add/replace behaviour; other kinds only
	// replace an existing OutputReference.
	TSharedRef<SWidget> BuildPublishedSourceMenu(FMixtormatChildAddress Dest, EMixtormatPublishedFieldKind Kind);
	FReply ReplaceOutputReferenceSource(const FMixtormatChildAddress& Dest, const FMixtormatOutputReference& Reference);
	bool HasSelectedOutputReference() const;
	bool IsOutputReferenceAvailable(const FMixtormatChildAddress& Address) const;
	TSharedRef<SWidget> BuildOutputReferenceControls();
	FReply DropChildIntoIdGroup(const FMixtormatChildDragDropOp& Operation, FMixtormatChildAddress Dest);

	// Copy takes the payload; Copy as Instance takes the address as well; Copy Output takes one of
	// Address's published outputs (see MixtormatChildCapabilities.h) and builds a published-source
	// mask from it. Paste reads FMixtormatChildClipboard::Mode to decide which of the three it does
	// -- there is no separate "Paste Instance" destination command any more.
	void CopyChild(const FMixtormatChildAddress& Address, bool bAsInstance);
	// Scalar outputs become live gate masks; typed fields become OutputReference children.
	bool CanCopyChildOutput(const FMixtormatChildAddress& Address, FName OutputName) const;
	void CopyChildOutput(const FMixtormatChildAddress& Address, FName OutputName);
	// Where the clipboard's child may land at Dest, given the row the paste was asked from.
	// INDEX_NONE when nothing in Dest can take it (wrong kind for Dest, or -- for Mode::Instance --
	// no position in Dest can read the source). Valid for every clipboard mode, not only Instance.
	int32 ResolvePasteInsertIndex(const FMixtormatChildAddress& Dest, int32 AnchorChildIndex,
			FGuid* OutScopeOwnerChildId = nullptr) const;
	bool CanPasteChild(const FMixtormatChildAddress& Dest, int32 AnchorChildIndex) const;
	FText GetChildPasteReason(const FMixtormatChildAddress& Dest, int32 AnchorChildIndex) const;
	FReply PasteChild(const FMixtormatChildAddress& Dest, int32 AnchorChildIndex = INDEX_NONE);

	FReply GoToChildInstanceSource(const FMixtormatChildAddress& Address);
	FReply BreakChildInstanceAt(const FMixtormatChildAddress& Address);
	void CopyChildInstanceReference(const FMixtormatChildAddress& Address);
	FReply ReplaceChildInstanceSource(const FMixtormatChildAddress& Address, FMixtormatChildAddress NewSource);
	// By value, not const&: FOnGetContent::CreateSP binds this as an extra Vars arg, whose deduced
	// target signature decays a reference away -- a by-ref parameter here fails to match the bound
	// pointer-to-member type.
	TSharedRef<SWidget> BuildReplaceInstanceSourceMenu(FMixtormatChildAddress Address);
	TSharedRef<SWidget> BuildMoveChildToLayerMenu(int32 LayerIndex, int32 ChildIndex);
	TSharedRef<SWidget> BuildMoveGroupChildToLayerMenu(FGuid GroupId, int32 ChildIndex);

	// The rows every child row shares, appended to whichever child menu is open (layer or group) so
	// the vocabulary does not drift between a mask, an effect, a filter -- or a container.
	void AddSharedChildMenuItems(MixtormatMenu::FBuilder& Menu, const FMixtormatChildAddress& Address);
	TSharedRef<SWidget> BuildCopyChildOutputMenu(FMixtormatChildAddress Address);

	// THE ADD MENU. One taxonomy, two containers.
	//
	// AddCreationSections appends the shared non-effect Add tree to layer and group menus. Effect
	// remains split because most procedural effects are layer-only; Peeling explicitly uses the same
	// configured child creation path in both menus.
	void AddCreationSections(MixtormatMenu::FBuilder& Menu, FMixtormatAddTarget Target);
	TSharedRef<SWidget> BuildAddIdsMenu(FMixtormatAddTarget Target);
	TSharedRef<SWidget> BuildAddFromIdsMenu(FMixtormatAddTarget Target);
	void AddIdGroupMenuItems(MixtormatMenu::FBuilder& Menu, const FMixtormatChildAddress& Owner);
	TSharedRef<SWidget> BuildAddFiltersMenu(FMixtormatAddTarget Target);
	TSharedRef<SWidget> BuildAddMasksMenu(FMixtormatAddTarget Target);
	TSharedRef<SWidget> BuildAddGeneratorsMenu(FMixtormatAddTarget Target);
	// The one creation path both menus call. Appends the child, applies the defaults that kind
	// wants, and leaves it selected in whichever container it landed in.
	FReply CreateChild(FMixtormatAddTarget Target, EMixtormatChildCreation Kind);
	FReply CreateStructuralModuleForTarget(FGuid TargetLayerId, FGuid TargetChildId,
		EMixtormatLayerChildType ModuleType);
	bool PrepareStructuralModuleForTarget(FGuid TargetLayerId, FGuid TargetChildId,
		EMixtormatLayerChildType ModuleType, TArray<FMixtormatLayer>& ProposedLayers,
		int32& LayerIndex, int32& InsertIndex, FText& OutReason) const;
	FReply CreateConnectedStructuralModuleForTarget(FGuid TargetLayerId, FGuid TargetChildId,
		EMixtormatLayerChildType ModuleType, const FMixtormatOutputReference& Source);
	bool PrepareConnectedStructuralModuleForTarget(FGuid TargetLayerId, FGuid TargetChildId,
		EMixtormatLayerChildType ModuleType, const FMixtormatOutputReference& Source,
		TArray<FMixtormatLayer>& ProposedLayers, int32& LayerIndex, int32& InsertIndex, FText& OutReason) const;
	bool PrepareStructuralModuleProposal(FGuid TargetLayerId, FGuid TargetChildId,
		EMixtormatLayerChildType ModuleType, const FMixtormatOutputReference* Source,
		TArray<FMixtormatLayer>& ProposedLayers, int32& LayerIndex, int32& InsertIndex, FText& OutReason) const;
	FReply CommitStructuralModuleForTarget(FGuid TargetLayerId, FGuid TargetChildId,
		EMixtormatLayerChildType ModuleType, const FMixtormatOutputReference* Source);
	TSharedRef<SWidget> BuildStructuralSourcePickerForTarget(FGuid TargetLayerId, FGuid TargetChildId,
		EMixtormatLayerChildType ModuleType);
	bool CanCreateChild(const FMixtormatAddTarget& Target) const;
	bool CanAddGeneratorModule(const FMixtormatAddTarget& Target) const;
	void AddHeightBlendRows(
		const TSharedRef<SVerticalBox>& Panel,
		TFunction<FMixtormatHeightBlend*()> Resolve,
		const FText& OpHint,
		const FText& AmountHint);
	// Texture Mask, from the gallery selection. The same call the gallery's drag-and-drop makes, so
	// the menu entry and the drop cannot drift into two different kinds of mask.
	FReply AddTextureMask(FMixtormatAddTarget Target, FSoftObjectPath MaskPath);
	FReply ToggleLayerExpanded(int32 LayerIndex);
	FReply AssignNormalTexture(int32 LayerIndex, FSoftObjectPath NormalPath);
	FReply AddEffectToLayer(int32 LayerIndex, FSoftObjectPath EffectPath);
	FReply AddStainToLayer(int32 LayerIndex, EMixtormatStainMode Mode);
	FMixtormatLayerEffect* GetSelectedStain();
	const FMixtormatLayerEffect* GetSelectedStain() const;
	FReply AddRunoffToLayer(int32 LayerIndex);
	FMixtormatLayerEffect* GetSelectedRunoff();
	const FMixtormatLayerEffect* GetSelectedRunoff() const;
	FReply AddErosionToLayer(int32 LayerIndex);
	FMixtormatLayerEffect* GetSelectedProceduralPeel();
	const FMixtormatLayerEffect* GetSelectedProceduralPeel() const;
	FMixtormatLayerEffect* GetSelectedErosion();
	const FMixtormatLayerEffect* GetSelectedErosion() const;
	FReply AddGradeToLayer(int32 LayerIndex);
	FMixtormatLayerEffect* GetSelectedGrade();
	const FMixtormatLayerEffect* GetSelectedGrade() const;

	FMixtormatLayerEffect* GetSelectedBreakup();
	const FMixtormatLayerEffect* GetSelectedBreakup() const;
	FReply AddBreakupToLayer(int32 LayerIndex);

	FMixtormatLayerEffect* GetSelectedWornEdges();
	const FMixtormatLayerEffect* GetSelectedWornEdges() const;
	FReply AddWornEdgesToLayer(int32 LayerIndex);
	TSharedRef<SWidget> BuildWornEdgesControls();

	FMixtormatLayerEffect* GetSelectedFlowWarp();
	const FMixtormatLayerEffect* GetSelectedFlowWarp() const;
	FReply AddFlowWarpToLayer(int32 LayerIndex, int32 OwnerChildIndex = INDEX_NONE);
	FReply AddLayerBlurToLayer(int32 LayerIndex);
	FMixtormatLayerEffect* GetSelectedLayerBlurEffect();
	const FMixtormatLayerEffect* GetSelectedLayerBlurEffect() const;
	TSharedRef<SWidget> BuildLayerBlurControls();
	TSharedRef<SWidget> BuildFlowWarpControls();
	FMixtormatLayerEffect* GetSelectedGeneratorFlow();
	const FMixtormatLayerEffect* GetSelectedGeneratorFlow() const;
	bool CanAddGeneratorFlow(const FMixtormatChildAddress& Owner) const;
	FReply AddGeneratorFlow(const FMixtormatChildAddress& Owner, EMixtormatEffectType Type);
	void AddGeneratorFlowMenuItems(MixtormatMenu::FBuilder& Menu, const FMixtormatChildAddress& Owner);
	TSharedRef<SWidget> BuildGeneratorFlowControls(EMixtormatEffectType Type);

	FReply ToggleLayerEffect(int32 LayerIndex, int32 EffectIndex);
	FReply RemoveLayerEffect(int32 LayerIndex, int32 ChildIndex);
	FReply AddLayerValuesMaskToLayer(int32 LayerIndex);
	FReply AddGeneratedMaskToLayer(int32 LayerIndex);
	FReply AddCraquelureToLayer(int32 LayerIndex);
	FReply RemoveGeneratedFromLayer(int32 LayerIndex, int32 ChildIndex);
	void SetGeneratedEnabled(ECheckBoxState CheckState, int32 LayerIndex, int32 ChildIndex);
	FMixtormatGeneratedMask* GetSelectedGeneratedMask();
	const FMixtormatGeneratedMask* GetSelectedGeneratedMask() const;

	FMixtormatCraquelure* GetSelectedCraquelure();
	const FMixtormatCraquelure* GetSelectedCraquelure() const;
	TSharedRef<SWidget> BuildCraquelureControls();
	TSharedRef<SWidget> BuildCraquelureBlendModeMenu();
	TSharedRef<SWidget> BuildRampIdBlendModeMenu();
	TSharedRef<SWidget> BuildCraquelureModeMenu();

	FReply AddFilterToLayer(int32 LayerIndex);
	FMixtormatClusterFilter* GetSelectedFilter();
	const FMixtormatClusterFilter* GetSelectedFilter() const;
	TSharedRef<SWidget> BuildFilterControls();
	TSharedRef<SWidget> BuildRegionFilterPanel(bool bSurfaceIds);
	TSharedRef<SWidget> BuildClusterSourceMenu();

	FReply AddHsvFilterToLayer(int32 LayerIndex);
	FMixtormatHsvIdFilter* GetSelectedHsvFilter();
	const FMixtormatHsvIdFilter* GetSelectedHsvFilter() const;
	TSharedRef<SWidget> BuildHsvFilterControls();
	FReply AddHsvPaletteEntry();
	FReply RemoveHsvPaletteEntry(int32 ColorIndex);
	FReply OpenHsvPalettePicker(int32 ColorIndex);
	void SetHsvPaletteColor(FLinearColor NewColor, int32 LayerIndex, int32 ChildIndex, int32 ColorIndex);

	FReply AddPatternIdToLayer(int32 LayerIndex);
	FMixtormatPatternFilter* GetSelectedPatternId();
	const FMixtormatPatternFilter* GetSelectedPatternId() const;
	TSharedRef<SWidget> BuildPatternIdControls();
	TSharedRef<SWidget> BuildPatternModeMenu();
	TSharedRef<SWidget> BuildGridModeMenu();

	// GENERATORS. Panels resolve a generator child first, or the selected Generator layer payload.
	// HasSelectedGenerator remains child-only so a layer keeps its HEIGHT and COMPOSITION cards.
	FReply AddStrataCarverToLayer(int32 LayerIndex);
	FMixtormatStrataCarver* GetSelectedStrataCarver();
	const FMixtormatStrataCarver* GetSelectedStrataCarver() const;
	TSharedRef<SWidget> BuildStrataCarverControls();
	FMixtormatCracks* GetSelectedCracks();
	const FMixtormatCracks* GetSelectedCracks() const;
	TSharedRef<SWidget> BuildCracksControls();
	FMixtormatRockFormation* GetSelectedRockFormation();
	const FMixtormatRockFormation* GetSelectedRockFormation() const;
	TSharedRef<SWidget> BuildRockFormationControls();
	FMixtormatPebbles* GetSelectedPebbles();
	const FMixtormatPebbles* GetSelectedPebbles() const;
	TSharedRef<SWidget> BuildPebblesControls();
	FMixtormatCliffStrata* GetSelectedCliffStrata();
	const FMixtormatCliffStrata* GetSelectedCliffStrata() const;
	TSharedRef<SWidget> BuildCliffStrataControls();
	FMixtormatNoise* GetSelectedNoise();
	const FMixtormatNoise* GetSelectedNoise() const;
	TSharedRef<SWidget> BuildNoiseControls();
	TSharedRef<SWidget> BuildNoisePatternPlacementControls(TFunction<FMixtormatNoise*()> Noise);
	bool CanCreateNoiseGate(const FMixtormatChildAddress& Owner) const;
	bool ResolveGatingMaskPayload(FMixtormatLayerChild& Payload) const;
	void CreateNoiseGate(const FMixtormatChildAddress& Owner);
	TSharedRef<SWidget> BuildMaskNoiseValueMenu(FMixtormatChildAddress Destination);
	TSharedRef<SWidget> BuildMaskSourceMenuFor(FMixtormatChildAddress Destination);
	FText GetMaskSourceLabel(const FMixtormatChildAddress& Destination) const;
	bool CanSelectMaskNoiseValue(const FMixtormatChildAddress& Destination,
		const FMixtormatChildAddress& Source, FText& Reason) const;
	void SelectMaskSource(const FMixtormatChildAddress& Destination, EMixtormatMaskSource Source);
	void SelectMaskNoiseValue(const FMixtormatChildAddress& Destination,
		const FMixtormatChildAddress& Source);
	FMixtormatGeneratorHeightBlend* GetSelectedHeightBlend();
	const FMixtormatGeneratorHeightBlend* GetSelectedHeightBlend() const;
	TSharedRef<SWidget> BuildHeightBlendModuleControls();
	TSharedRef<SWidget> BuildHeightBlendSourceMenu();
	FMixtormatGeneratorHeightCurve* GetSelectedHeightCurve();
	const FMixtormatGeneratorHeightCurve* GetSelectedHeightCurve() const;
	TSharedRef<SWidget> BuildHeightCurveControls();
	FMixtormatGeneratorHeightColorRamp* GetSelectedHeightColorRamp();
	const FMixtormatGeneratorHeightColorRamp* GetSelectedHeightColorRamp() const;
	TSharedRef<SWidget> BuildHeightColorRampControls();
	FMixtormatGeneratorHeightPush* GetSelectedHeightPush();
	const FMixtormatGeneratorHeightPush* GetSelectedHeightPush() const;
	TSharedRef<SWidget> BuildHeightPushControls();
	TSharedRef<SWidget> BuildHeightPushConnectionMenu(bool bTarget);
	FMixtormatGeneratorStructuralWarp* GetSelectedStructuralWarp();
	const FMixtormatGeneratorStructuralWarp* GetSelectedStructuralWarp() const;
	TSharedRef<SWidget> BuildStructuralWarpControls();
	TSharedRef<SWidget> BuildStructuralWarpConnectionMenu(bool bTarget);
	TSharedRef<SWidget> BuildStructuralConnectionMenu(FMixtormatChildAddress Address,
		EMixtormatStructuralConnectionRole Role);
	FReply SetStructuralConnection(FMixtormatChildAddress Address,
		EMixtormatStructuralConnectionRole Role, const FMixtormatOutputReference* Source = nullptr,
		const FGuid* TargetId = nullptr);
	FText GetStructuralConnectionLabel(FMixtormatChildAddress Address,
		EMixtormatStructuralConnectionRole Role, bool bCompact = false,
		FText* OutFullLabel = nullptr) const;
	FText GetStructuralChildLabel(const FMixtormatLayer& Layer, int32 ChildIndex) const;
	TSharedRef<SWidget> BuildStructuralLinkChips(FMixtormatChildAddress Address);
	TSharedRef<SWidget> BuildStructuralRelationshipHeader();
	bool GetStructuralRelationshipRow(FMixtormatChildAddress Address, FMixtormatProjectedChildRow& OutRow,
		EMixtormatLayerChildType& OutType, FText& OutReason) const;
	FMixtormatStructuralRelationshipPresentation DescribeStructuralConnection(const FMixtormatProjectedChildRow& Row,
		EMixtormatLayerChildType Type) const;
	FText GetStructuralRelationshipText(FMixtormatChildAddress Address, bool bToolTip) const;
	bool ResolveStructuralSourceAddress(FMixtormatChildAddress ModuleAddress,
		FMixtormatChildAddress& OutSource, FText& OutReason) const;
	FReply GoToStructuralSource(FMixtormatChildAddress ModuleAddress);
	FReply NavigateToChild(FMixtormatChildAddress Address);
	// Mutates expansion only; the caller rebuilds if this returns true.
	bool RevealChildInHierarchy(FMixtormatChildAddress Address);
	FReply ToggleGeneratorExpanded(FMixtormatChildAddress Address);
	bool ResolveHierarchyChildAddress(FMixtormatChildAddress Address, int32& OutOwnerIndex,
		int32& OutChildIndex) const;
	TArray<FMixtormatProjectedChildRow> BuildGroupHierarchyRows(FGuid GroupId) const;
	FMixtormatLayerHierarchyPaint BuildGroupHierarchyPaint(
		const TArray<FMixtormatProjectedChildRow>& VisibleRows, int32 DisplayIndex) const;
	TArray<FMixtormatProjectedChildRow> FilterVisibleHierarchyRows(
		const TArray<FMixtormatProjectedChildRow>& Rows) const;
	TSharedRef<SWidget> BuildGeneratorDisclosure(FMixtormatChildAddress Address, bool bHasChildren,
		FText ToolTip = FText::GetEmpty());
	void RegisterChildRowWidget(FMixtormatChildAddress Address, TSharedRef<SWidget> Widget);
	FText GetStructuralSourceBreadcrumb(const FMixtormatLayer& Layer, int32 ChildIndex) const;
	TSharedRef<SWidget> BuildStructuralConnectionContent(const FMixtormatProjectedChildRow& Row,
		EMixtormatLayerChildType Type, FText& OutToolTip) const;
	EStructuralLinkHighlightRole GetStructuralHighlightRole(FMixtormatChildAddress Address) const;
	bool IsSelectedStructuralSourceLayer(FGuid LayerId, FGuid GroupId) const;
	FText GetStructuralIncomingCountLabel(int32 LayerIndex, int32 ChildIndex) const;
	TSharedRef<SWidget> BuildColorRampSourceMenu();
	FReply AddGeneratorToGroup(FGuid GroupId, EMixtormatGeneratorType GeneratorType);
	bool HasSelectedGenerator() const;
	FMixtormatGenerator* GetSelectedGenerator();
	const FMixtormatGenerator* GetSelectedGenerator() const;
	// NOTE: with a Sources shelf entry selected, this resolves the source's generator payload, so
	// the generator parameter panels serve sources through the same accessors.

	FReply AddRampIdToLayer(int32 LayerIndex);

	FMixtormatIdGroup* GetSelectedIdGroup();
	const FMixtormatIdGroup* GetSelectedIdGroup() const;

	FMixtormatRampIdFilter* GetSelectedRampId();
	const FMixtormatRampIdFilter* GetSelectedRampId() const;
	TSharedRef<SWidget> BuildRampIdControls();
	FMixtormatUvIdFilter* GetSelectedUvId();
	const FMixtormatUvIdFilter* GetSelectedUvId() const;
	TSharedRef<SWidget> BuildUvIdControls();
	FMixtormatReliefIdFilter* GetSelectedReliefId();
	const FMixtormatReliefIdFilter* GetSelectedReliefId() const;
	TSharedRef<SWidget> BuildReliefIdControls();
	FMixtormatBoundaryIdFilter* GetSelectedBoundaryId();
	const FMixtormatBoundaryIdFilter* GetSelectedBoundaryId() const;
	TSharedRef<SWidget> BuildBoundaryIdControls();
	TSharedRef<SWidget> BuildBoundaryIdSourceMenu();
	TSharedRef<SWidget> BuildIdGroupControls();
	TSharedRef<SWidget> BuildIdGroupFeatureMenu();
	TSharedRef<SWidget> BuildChildOutputsControls(const FMixtormatChildCapabilities& Capabilities);


	FReply AddRandomIdToLayer(int32 LayerIndex);
	FMixtormatRandomIdMask* GetSelectedRandomId();
	const FMixtormatRandomIdMask* GetSelectedRandomId() const;
	TSharedRef<SWidget> BuildRandomIdControls();
	TSharedRef<SWidget> BuildRandomIdBlendModeMenu();

	FReply AddColorIdMaskToLayer(int32 LayerIndex);
	FMixtormatColorIdMask* GetSelectedColorId();
	const FMixtormatColorIdMask* GetSelectedColorId() const;
	TSharedRef<SWidget> BuildColorIdControls();
	TSharedRef<SWidget> BuildBaseColorBlendModeMenu();
	TSharedRef<SWidget> BuildColorIdBlendModeMenu();
	TSharedRef<SWidget> BuildColorIdRotationMenu();
	TSharedRef<SWidget> BuildColorIdModeMenu();
	// THE EXACT ID PICKER.
	//
	// A popover of the live Region IDs preview, clicked to sample. The image is the composite's
	// own debug target -- the same pixels the viewport is showing -- so what is clicked and what
	// is read are the same frame; the value written comes from the parallel pick buffer, which
	// holds the integer id rather than the hashed colour standing in for it.
	TSharedRef<SWidget> BuildRegionIdPickerPopup();
	// The mask gallery as a popover grid of thumbnails. One implementation for every slot that
	// picks a mask asset -- the Texture Mask row in the inspector and Peeling's Seed Mask -- so
	// the two cannot drift into different pickers over the same library. Footer is an optional
	// row under the grid for a slot that has a "none" of its own to offer.
	TSharedRef<SWidget> BuildMaskAssetPicker(
		TFunction<void(FSoftObjectPath)> OnPicked,
		TFunction<bool(FSoftObjectPath)> IsSelected,
		TSharedPtr<SWidget> Footer = nullptr);
	// True when a Region IDs preview is up, which is the only time the pick buffer holds anything.
	bool CanPickRegionId() const;
	// UV in [0,1] over the composition. Returns false -- leaving ExactRegionId untouched -- for a
	// pixel belonging to no region, an unavailable buffer, or a failed readback.
	bool ReadRegionIdAtUV(FVector2D UV, int32& OutRegionId) const;
	void PickRegionIdAtUV(FVector2D UV);
	// Held for the lifetime of the panel so the popover's SImage has something stable to point at.
	// The render target itself is owned by the compositor.
	TSharedPtr<FSlateBrush> RegionIdPreviewBrush;
	FReply AddColorIdEntry();
	FReply RemoveColorIdEntry(int32 ColorIndex);
	FReply OpenColorIdPicker(int32 ColorIndex);
	void SetColorIdColor(FLinearColor NewColor, int32 LayerIndex, int32 ChildIndex, int32 ColorIndex);
	TSharedRef<SWidget> BuildMaskSourceMenu();
	TSharedRef<SWidget> BuildMaskLayerValueChannelMenu();
	TSharedRef<SWidget> BuildMaskRotationMenu();
	TSharedRef<SWidget> BuildLayerRotationMenu();

	FMixtormatLayerEffect* GetSelectedLayerEffect();
	const FMixtormatLayerEffect* GetSelectedLayerEffect() const;
	FMixtormatMaskLayer* GetSelectedLayerMask();
	const FMixtormatMaskLayer* GetSelectedLayerMask() const;
	int32 GetSelectedChildIndex() const;
	// The derived mark the inspector strip prints -- the selected child's, or the layer's.
	FText GetSelectedBadgeText() const;
	void SetMaskEnabled(ECheckBoxState CheckState, int32 LayerIndex, int32 ChildIndex);
	void SetMaskBlendMode(int32 LayerIndex, int32 ChildIndex, EMixtormatMaskBlendMode BlendMode);
	FReply OpenFillColorPicker(int32 LayerIndex);
	void SetFillBaseColor(FLinearColor NewColor, int32 LayerIndex);
	void RestoreFillBaseColor(FLinearColor OriginalColor, int32 LayerIndex);

	void SetWorkingLayerEnabled(ECheckBoxState CheckState, int32 LayerIndex);
	FReply ToggleLayerSolo(int32 LayerIndex);
	bool IsLayerChildEnabled(int32 LayerIndex, int32 ChildIndex) const;
	void SyncSelectedLayerControls();
	void ResetEditHistory(bool bCurrentStateIsSaved);
	void RecordEditHistory();
	void ApplyEditHistoryState(const FEditHistoryState& State);
	void SynchronizeHistoryAfterCancelledEdit();
	bool IsCurrentStateSaved() const;
	// Group operations. Creating gathers the selected layers into one contiguous block, because a
	// group owning a scattered set of layers would have no single position in the stack.
	// Shared group children. Authored once on the group and broadcast onto every member by
	// MixtormatLayerGroups::BuildEffectiveLayers, which is the whole point of a group.
	// The one place the inspector learns what container a child lives in.
	//
	// A child is addressed by (LayerIndex, ChildIndex) everywhere, and a group has no layer index,
	// so INDEX_NONE plus a valid SelectedGroupId means the selected group's shared stack. Neither
	// variable lies -- when a group child is selected there genuinely is no layer selected -- and
	// no setter signature has to change, which is what keeps this from being a rewrite of every
	// slider in the panel.
	FMixtormatLayerChild* ResolveChild(int32 LayerIndex, int32 ChildIndex);
	const FMixtormatLayerChild* ResolveChild(int32 LayerIndex, int32 ChildIndex) const;

	FMixtormatLayerChild* AppendGroupChild(FGuid GroupId, EMixtormatLayerChildType ChildType);
	void FinishGroupChildEdit(FGuid GroupId, int32 SelectIndex = INDEX_NONE);
	FReply AddMaskToGroup(FGuid GroupId, FSoftObjectPath MaskPath);
	FReply AddEffectToGroup(FGuid GroupId, FSoftObjectPath EffectPath);
	FReply AddProceduralChildToGroup(FGuid GroupId, EMixtormatLayerChildType ChildType);
	FReply RemoveGroupChild(FGuid GroupId, int32 ChildIndex);
	FReply ReorderGroupChild(FGuid GroupId, int32 SourceChildIndex, int32 TargetChildIndex);
	FReply ToggleGroupChildEnabled(FGuid GroupId, int32 ChildIndex);
	FReply SelectGroupChild(FGuid GroupId, int32 ChildIndex);
	// Paste a copied mask (a copied output included) as the gating mask of the row it is pasted
	// on -- an effect, a flow tool or a generator -- instead of as a layer mask above it.
	bool CanPasteAsGatingMask(const FMixtormatChildAddress& Address) const;
	FReply PasteAsGatingMask(const FMixtormatChildAddress& Address);
	// Clicking empty space in the layer stack: nothing selected, so the inspector shows globals.
	void ClearLayerSelection();
	bool HasAnySelection() const;
	static bool IsGroupChildEnabled(const FMixtormatLayerChild& Child);
	TSharedRef<SWidget> BuildGroupChildRow(FGuid GroupId, int32 ChildIndex);
	TSharedRef<SWidget> BuildGroupAddEffectMenu(FGuid GroupId);
	TSharedRef<SWidget> BuildGroupChildContextMenu(FGuid GroupId, int32 ChildIndex);

	// Rename. Names do not reach the compositor, so committing one records history and marks the
	// document dirty but deliberately does not ask for a new composite.
	FReply RenameLayer(FGuid LayerId, FText NewName);
	FReply RenameLayerGroup(FGuid GroupId, FText NewName);
	// F2 (or its F12 alias), and the context menu, on whichever of the two selections is live.
	bool BeginRenameSelection();

	TSharedRef<SWidget> BuildLayerGroupRow(FGuid GroupId);
	TSharedRef<SWidget> BuildLayerGroupContextMenu(FGuid GroupId);
	// Editor-only tagging: the compositor never reads a group's colour, so this asks for no
	// recomposite -- only a rebuild of the rows that draw it.
	FReply SetLayerGroupAccentColor(FGuid GroupId, FLinearColor AccentColor);
	TSharedRef<SWidget> BuildGroupAccentMenu(FGuid GroupId);
	static int32 InsertIndexToMoveTarget(int32 SourceIndex, int32 InsertIndex);
	FReply HandleLayerInsertedAt(int32 SourceLayerIndex, int32 InsertIndex);
	FReply HandleGroupInsertedAt(FGuid GroupId, int32 InsertIndex);
	FReply HandleLayerDroppedOnGroup(int32 SourceLayerIndex, FGuid TargetGroupId);
	FGuid ResolveGroupMembershipAt(int32 LayerIndex) const;
	FReply CreateGroupFromSelection();
	FReply UngroupLayerGroup(FGuid GroupId);
	bool CanCreateGroup() const;
	TArray<int32> GetSelectedLayerIndices() const;
	FText MakeUniqueGroupName() const;
	bool IsGroupExpanded(const FGuid& GroupId) const;
	FReply ToggleGroupExpanded(FGuid GroupId);
	FReply SelectLayerGroup(FGuid GroupId);
	FReply SetLayerGroupEnabled(FGuid GroupId, bool bEnabled);

	// Expansion and multi-select, addressed by index at the call site and stored by identity.
	bool IsLayerExpanded(int32 LayerIndex) const;
	void SetLayerExpanded(int32 LayerIndex, bool bExpanded);
	bool IsLayerMultiSelected(int32 LayerIndex) const;
	// Applies the modifier keys currently held: plain replaces, ctrl/cmd toggles, shift extends
	// from the anchor.
	void UpdateMultiSelection(int32 LayerIndex);

	static bool AreLayerGroupsEqual(
		const TArray<FMixtormatLayerGroup>& A,
		const TArray<FMixtormatLayerGroup>& B);
	static bool AreLayerStacksEqual(
		const TArray<FMixtormatLayer>& A,
		const TArray<FMixtormatLayer>& B);
	static bool AreSourcesEqual(
		const TArray<FMixtormatSourceEntry>& A,
		const TArray<FMixtormatSourceEntry>& B);
	static bool HaveSameLayerStructure(
		const TArray<FMixtormatLayer>& A,
		const TArray<FMixtormatLayer>& B);
	void RefreshLayeredPreview(bool bMarkDirty = true);
	EActiveTimerReturnType FlushPendingPreviewRefresh(double CurrentTime, float DeltaTime);

	// True while a Slate control has the mouse captured with the left button down, which is
	// what a spin box scrub looks like from outside. Read globally rather than wired through
	// each control's OnBeginSliderMovement: there are dozens of spin boxes, and this survives
	// replacing them.
	bool IsInteractiveEdit() const;
	bool ConfirmDiscardUnsavedChanges();

	// One inspector row: label, fill and value in a single bar of fixed height. Every numeric
	// control in the inspector goes through here, which is what makes the rows uniform.
	// Registers itself for hover + Backspace reset like the spin boxes it replaces.
	//
	// Min/Max/Delta are attributes so migrated rows can resolve them from the parameter UI
	// metadata -- including a session dev override -- on every paint. Plain doubles pass in
	// unchanged and keep working via TAttribute's implicit conversion.
	TSharedRef<SWidget> MakeSlider(
		const TAttribute<FText>& Label,
		const TAttribute<double>& Value,
		const TAttribute<double>& MinValue,
		const TAttribute<double>& MaxValue,
		const TAttribute<double>& DefaultValue,
		const TAttribute<double>& SnapDelta,
		const bool bInteger,
		const FMixtormatOnSliderValueChanged& OnValueChanged,
		const FSimpleDelegate& ResetDelegate,
		const TAttribute<FText>& ToolTip = TAttribute<FText>(),
		const FMixtormatSliderRangeOptions& RangeOptions = FMixtormatSliderRangeOptions());

	// Soft-range policy for a parameter row: the UI range may grow (on release, after pushing
	// an end) up to the authoring back-end clamp, which also stops drags and typed values.
	// Not where the shader saturates the value -- past its range it changes nothing. ValueScale
	// converts stored bounds to the row's UI units.
	template <typename TKeyFor>
	static FMixtormatSliderRangeOptions MakeParameterRangeOptions(TKeyFor KeyFor, const double ValueScale = 1.0)
	{
		const auto Contract = [KeyFor]() -> const FMixtormatParameterContract*
		{
			const FMixtormatParameterDefinitionKey* Key = KeyFor();
			return Key ? MixtormatParameterContracts::TryGet(Key->Owner, Key->Parameter) : nullptr;
		};
		const auto Bound = [KeyFor, ValueScale](const bool bMax) -> double
		{
			const FMixtormatParameterDefinitionKey* Key = KeyFor();
			const TOptional<float> Stored = Key
				? MixtormatParameterAuthoring::ResolveAuthoringClamp(*Key, bMax) : TOptional<float>();
			if (!Stored.IsSet())
			{
				return bMax ? UE_BIG_NUMBER : -UE_BIG_NUMBER;
			}
			return static_cast<double>(Stored.GetValue()) / ValueScale;
		};
		FMixtormatSliderRangeOptions Options;
		// Only parameters with a back-end clamp grow: without one there is no limit to grow
		// toward, so the authored UI range stays the whole visual range (layer rows, most
		// effect rows).
		Options.bExpandable = TAttribute<bool>::CreateLambda([KeyFor, Contract]()
		{
			const FMixtormatParameterDefinitionKey* Key = KeyFor();
			const FMixtormatParameterContract* C = Contract();
			return Key != nullptr && !(C && C->bShaderSaturates)
				&& (MixtormatParameterAuthoring::ResolveAuthoringClamp(*Key, false).IsSet()
					|| MixtormatParameterAuthoring::ResolveAuthoringClamp(*Key, true).IsSet());
		});
		Options.HardMin = TAttribute<double>::CreateLambda([Bound, ValueScale]()
		{
			return ValueScale < 0.0 ? Bound(true) : Bound(false);
		});
		Options.HardMax = TAttribute<double>::CreateLambda([Bound, ValueScale]()
		{
			return ValueScale < 0.0 ? Bound(false) : Bound(true);
		});
		return Options;
	}

	// Appends a titled card to a panel and hands back the box its rows go in, so a run of
	// values is one extra line at the top rather than a nested SNew tree around every row.
	TSharedRef<SVerticalBox> AddCard(
		const TSharedRef<SVerticalBox>& TargetPanel,
		const FText& Title,
		const TSharedPtr<SWidget>& HeaderAction = nullptr,
		const TSharedPtr<SWidget>& LeadingHeaderContent = nullptr);

	void AddSliderRow(
		const TSharedRef<SVerticalBox>& TargetPanel,
		const TSharedRef<SWidget>& Row);

	// The Invert / Balance / Contrast / Offset block, from one place.
	//
	// Four nodes run the same MixtormatShapeMask and used to write these rows out four times, with
	// four different slider ranges for the same parameter. The panel supplies a resolver for
	// whichever FMixtormatMaskShaping it owns and gets the block, the ranges and the tooltips.
	void AddMaskShapingRows(
		const TSharedRef<SVerticalBox>& TargetPanel,
		TFunction<FMixtormatMaskShaping*()> Resolve);

	FMixtormatParameterAddress BuildParameterAddress(
		const void* Owner,
		UScriptStruct* OwnerStruct,
		int32 MemberOffset) const;
	// The address a parameter row points at, resolved on every use rather than captured once.
	//
	// The inspector is built once, in Construct, before anything is selected -- so a resolver
	// called at construct time hands back nullptr and the address built from it is permanently
	// invalid. Every other binding in the panel is already lazy for that reason; this one was the
	// exception, which is why no row ever got a state dot or a parameter menu.
	template <typename TOwner, typename TMember>
	TFunction<FMixtormatParameterAddress()> MakeAddressResolver(
		TFunction<TOwner*()> Resolve,
		TMember TOwner::* Member)
	{
		return [this, Resolve, Member]() -> FMixtormatParameterAddress
		{
			TOwner* Owner = Resolve();
			if (!Owner)
			{
				return FMixtormatParameterAddress();
			}
			const int32 MemberOffset = static_cast<int32>(
				reinterpret_cast<const uint8*>(&(Owner->*Member))
				- reinterpret_cast<const uint8*>(Owner));
			return BuildParameterAddress(Owner, TOwner::StaticStruct(), MemberOffset);
		};
	}

	TSharedRef<SWidget> WrapParameterControl(
		const TSharedRef<SWidget>& Control,
		TFunction<FMixtormatParameterAddress()> ResolveTarget);
	TSharedRef<SWidget> BuildParameterContextMenu(FMixtormatParameterAddress Target);
	// Developer surface, gated by Mixtormat.Developer.ParameterMeta. The submenu exists only
	// while that flag is on and only in the editor module.
	TSharedRef<SWidget> BuildParameterDeveloperMenu(FMixtormatParameterAddress Target);
	TSharedRef<SWidget> BuildParameterInfoPanel(FMixtormatParameterAddress Target);
	TSharedRef<SWidget> BuildParameterUiRangeOverridePanel(FMixtormatParameterAddress Target);
	// Persistent authoring editor for PersistentDevTunable parameters: label/default/UI range/
	// snap with live preview; edits stay unsaved until Save to Plugin Defaults.
	TSharedRef<SWidget> BuildAuthoringSetupPanel(FMixtormatParameterAddress Target);
	void CopyParameterAddress(FMixtormatParameterAddress Target);
	TSharedRef<SWidget> BuildParameterDriverPopover(FMixtormatParameterAddress Target);
	TSharedRef<SWidget> BuildParameterContextMenuFor(TFunction<FMixtormatParameterAddress()> ResolveTarget);
	TSharedRef<SWidget> BuildParameterDriverPopoverFor(TFunction<FMixtormatParameterAddress()> ResolveTarget);
	TSharedRef<SWidget> BuildDriverSourceMenu(FMixtormatParameterAddress Target);
	TSharedRef<SWidget> BuildDriverOutputMenu(FMixtormatParameterAddress Target);
	TSharedRef<SWidget> BuildDriverCombineMenu(FMixtormatParameterAddress Target);
	FMixtormatParameterBinding* FindParameterBinding(
		const FMixtormatParameterAddress& Target,
		bool bCreate);
	const FMixtormatParameterBinding* FindParameterBinding(
		const FMixtormatParameterAddress& Target) const;
	bool IsParameterReferenced(const FMixtormatParameterAddress& Target) const;
	bool IsParameterDriven(const FMixtormatParameterAddress& Target) const;
	bool IsParameterReferenceBroken(const FMixtormatParameterAddress& Target) const;
	bool CanPasteParameterReference(const FMixtormatParameterAddress& Target) const;
	bool WouldCreateParameterReferenceCycle(
		const FMixtormatParameterAddress& Destination,
		const FMixtormatParameterAddress& Source) const;
	void CopyParameterReference(FMixtormatParameterAddress Source);
	void PasteParameterReference(FMixtormatParameterAddress Destination);
	void ClearParameterReference(FMixtormatParameterAddress Target);
	void GoToParameterReferenceSource(FMixtormatParameterAddress Target);
	void SetDriverSource(
		FMixtormatParameterAddress Target,
		FGuid SourceLayerId,
		FGuid SourceChildId,
		EMixtormatDriverSourceKind SourceKind,
		FName SourceOutput);
	void SetDriverCombine(FMixtormatParameterAddress Target, EMixtormatDriverCombineMode Combine);
	void SetDriverEnabled(FMixtormatParameterAddress Target, bool bEnabled);
	void ClearParameterDriver(FMixtormatParameterAddress Target);
	void SetParameterReferenceMode(FMixtormatParameterAddress Target, EMixtormatReferenceMode Mode);
	EMixtormatReferenceMode GetParameterReferenceMode(const FMixtormatParameterAddress& Target) const;

	// True when a Link reference took the edit: the value went to the authoritative source and the
	// link survives. False means the row writes its own member, which is what breaks a Follow.
	bool TryWriteLinkedFloat(const FMixtormatParameterAddress& Target, float Value);
	bool TryWriteLinkedInt(const FMixtormatParameterAddress& Target, int32 Value);
	bool TryWriteLinkedBool(const FMixtormatParameterAddress& Target, bool Value);
	bool TryWriteLinkedEnum(const FMixtormatParameterAddress& Target, int64 Value);
	double GetEffectiveFloatParameter(const FMixtormatParameterAddress& Target, double LocalValue) const;
	int32 GetEffectiveIntParameter(const FMixtormatParameterAddress& Target, int32 LocalValue) const;
	bool GetEffectiveBoolParameter(const FMixtormatParameterAddress& Target, bool LocalValue) const;
	int64 GetEffectiveEnumParameter(const FMixtormatParameterAddress& Target, int64 LocalValue) const;

	// One binding for every parameter row in the inspector, whatever owns it.
	//
	// A panel supplies a resolver for its own selection and a pointer to the member; the row, its
	// reset to default and its preview refresh all come from here. Peel, erosion, generated masks,
	// mask children and layers differ only in the resolver, so without this each grows its own
	// near-identical copy -- which is exactly what had started to happen.
	template <typename TOwner>
	TSharedRef<SWidget> MakeMemberSlider(
		const FText& Label,
		TFunction<TOwner*()> Resolve,
		float TOwner::* Member,
		const double MinValue,
		const double MaxValue,
		const double DefaultValue,
		const double SnapDelta,
		const TAttribute<FText>& ToolTip = TAttribute<FText>(),
		const double ValueScale = 1.0)
	{
		// The slider always works in the units its Min/Max/Default are written in. ValueScale is
		// what the member is stored in, per one of those units -- so a row can read -1..1 while the
		// data underneath stays in whatever the shader expects. Hue Shift is the case that needs it:
		// the pass is in degrees, but a signed -1..1 is what fills from the centre and reads as
		// untouched at zero.
		checkSlow(ValueScale != 0.0);
		const TFunction<FMixtormatParameterAddress()> ResolveTarget = MakeAddressResolver(Resolve, Member);

		// The parameter-definition key behind this row. It is a property of the row's fixed
		// member and owner struct, not of the selection, so it resolves once (nothing is
		// selected at construct time) and is shared by every attribute getter below.
		const TSharedRef<TOptional<FMixtormatParameterDefinitionKey>> CachedKey =
			MakeShared<TOptional<FMixtormatParameterDefinitionKey>>();
		const auto KeyFor = [ResolveTarget, CachedKey]() -> const FMixtormatParameterDefinitionKey*
		{
			if (!CachedKey->IsSet())
			{
				*CachedKey = MixtormatParameterUi::DefinitionKeyOf(ResolveTarget());
			}
			return CachedKey->IsSet() ? &CachedKey->GetValue() : nullptr;
		};

		// Drag range resolves per paint: dev override, then UiMeta, then the call site's
		// literals. None of these are clamps -- a typed value past the range still reaches the
		// member; only a runtime HardMin/HardMax restricts, and that happens in the compositor.
		const auto RangeBound = [KeyFor](const double Fallback, const bool bMax)
		{
			return TAttribute<double>::CreateLambda([KeyFor, Fallback, bMax]() -> double
			{
				const FMixtormatParameterDefinitionKey* Key = KeyFor();
				if (!Key)
				{
					return Fallback;
				}
				return static_cast<double>(
					MixtormatParameterAuthoring::ResolveAuthoringUiBound(*Key, static_cast<float>(Fallback), bMax));
			});
		};
		// Migration guard, runs from the min getter and warns once per parameter (guarded inside
		// by a warned-set) when the literals and the UiMeta table disagree.
		const float LiteralMin = static_cast<float>(MinValue);
		const float LiteralMax = static_cast<float>(MaxValue);
		const float LiteralSnap = static_cast<float>(SnapDelta);
		const auto MigrationGuardBound = [KeyFor, LiteralMin, LiteralMax, LiteralSnap, RangeBound]()
		{
			return TAttribute<double>::CreateLambda([KeyFor, LiteralMin, LiteralMax, LiteralSnap,
				Guard = RangeBound(LiteralMin, false)]() -> double
			{
				if (const FMixtormatParameterDefinitionKey* Key = KeyFor())
				{
					MixtormatParameterUi::ReportLiteralMismatch(*Key, LiteralMin, LiteralMax, LiteralSnap);
				}
				return Guard.Get(0.0);
			});
		};

		// Reset and the modified-value stripe resolve the SAME default: unsaved dev edit ->
		// shipped plugin default -> compiled definition, all in STORED units. Only the legacy
		// literal fallback is in UI units and needs ValueScale; multiplying an already-stored
		// canonical default by ValueScale would double-scale it.
		const auto StoredDefault = [KeyFor, DefaultValue, ValueScale]() -> double
		{
			if (const FMixtormatParameterDefinitionKey* Key = KeyFor())
			{
				return MixtormatParameterAuthoring::ResolveAuthoringDefault(
					*Key, DefaultValue * ValueScale);
			}
			return DefaultValue * ValueScale;
		};
		// The display default for the stripe: stored units converted back to UI units.
		const auto DisplayDefault = [StoredDefault, ValueScale]() -> double
		{
			return StoredDefault() / ValueScale;
		};
		// The persistent label override, when the authoring database carries one.
		const auto ResolvedLabel = [KeyFor, Label]() -> FText
		{
			if (const FMixtormatParameterDefinitionKey* Key = KeyFor())
			{
				return MixtormatParameterAuthoring::ResolveAuthoringLabel(*Key, Label);
			}
			return Label;
		};

		TSharedRef<SWidget> Slider = MakeSlider(
			TAttribute<FText>::CreateLambda(ResolvedLabel),
			TAttribute<double>::CreateLambda([this, Resolve, Member, StoredDefault, ValueScale, ResolveTarget]() -> double
			{
				const TOwner* Owner = Resolve();
				const double Local = Owner ? static_cast<double>(Owner->*Member) : StoredDefault();
				return GetEffectiveFloatParameter(ResolveTarget(), Local) / ValueScale;
			}),
			MigrationGuardBound(),
			RangeBound(MaxValue, true),
			TAttribute<double>::CreateLambda(DisplayDefault),
			TAttribute<double>::CreateLambda([KeyFor, LiteralSnap]() -> double
			{
				const FMixtormatParameterDefinitionKey* Key = KeyFor();
				return Key
					? static_cast<double>(MixtormatParameterAuthoring::ResolveAuthoringSnap(*Key, LiteralSnap))
					: static_cast<double>(LiteralSnap);
			}),
			false,
			FMixtormatOnSliderValueChanged::CreateLambda(
				[this, Resolve, Member, ValueScale, ResolveTarget](const double Value)
			{
				if (TOwner* Owner = Resolve())
				{
					const FMixtormatParameterAddress Address = ResolveTarget();
					if (IsParameterLocked(Address))
					{
						return;
					}
					const float Authored = static_cast<float>(Value * ValueScale);
					if (!TryWriteLinkedFloat(Address, Authored))
					{
						Owner->*Member = Authored;
						if (FMixtormatParameterBinding* Binding = FindParameterBinding(Address, false))
						{
							Binding->Reference.bEnabled = false;
						}
					}
					RefreshLayeredPreview();
				}
			}),
			FSimpleDelegate::CreateLambda([this, Resolve, Member, StoredDefault, ValueScale, ResolveTarget]()
			{
				TOwner* Owner = Resolve();
				const float ResetValue = static_cast<float>(StoredDefault());
				if (Owner && !FMath::IsNearlyEqual(Owner->*Member, ResetValue))
				{
					const FMixtormatParameterAddress Address = ResolveTarget();
					if (IsParameterLocked(Address))
					{
						return;
					}
					if (!TryWriteLinkedFloat(Address, ResetValue))
					{
						Owner->*Member = ResetValue;
						if (FMixtormatParameterBinding* Binding = FindParameterBinding(Address, false))
						{
							Binding->Reference.bEnabled = false;
						}
					}
					RefreshLayeredPreview();
				}
			}),
			ToolTip,
			MakeParameterRangeOptions(KeyFor, ValueScale));
		return WrapParameterControl(Slider, ResolveTarget);
	}

	template <typename TOwner>
	TSharedRef<SWidget> MakeMemberSliderInt(
		const FText& Label,
		TFunction<TOwner*()> Resolve,
		int32 TOwner::* Member,
		const double MinValue,
		const double MaxValue,
		const int32 DefaultValue,
		const TAttribute<FText>& ToolTip = TAttribute<FText>())
	{
		const TFunction<FMixtormatParameterAddress()> ResolveTarget = MakeAddressResolver(Resolve, Member);

		// Same metadata resolution as the float template: drag range per paint from the dev
		// override / UiMeta / literals, reset from the canonical definition's default.
		const TSharedRef<TOptional<FMixtormatParameterDefinitionKey>> CachedKey =
			MakeShared<TOptional<FMixtormatParameterDefinitionKey>>();
		const auto KeyFor = [ResolveTarget, CachedKey]() -> const FMixtormatParameterDefinitionKey*
		{
			if (!CachedKey->IsSet())
			{
				*CachedKey = MixtormatParameterUi::DefinitionKeyOf(ResolveTarget());
			}
			return CachedKey->IsSet() ? &CachedKey->GetValue() : nullptr;
		};
		const auto RangeBound = [KeyFor](const double Fallback, const bool bMax)
		{
			return TAttribute<double>::CreateLambda([KeyFor, Fallback, bMax]() -> double
			{
				const FMixtormatParameterDefinitionKey* Key = KeyFor();
				return Key
					? static_cast<double>(MixtormatParameterAuthoring::ResolveAuthoringUiBound(*Key, static_cast<float>(Fallback), bMax))
					: Fallback;
			});
		};
		const auto StoredDefault = [KeyFor, DefaultValue]() -> int32
		{
			if (const FMixtormatParameterDefinitionKey* Key = KeyFor())
			{
				return FMath::RoundToInt(
					MixtormatParameterAuthoring::ResolveAuthoringDefault(
						*Key, static_cast<float>(DefaultValue)));
			}
			return DefaultValue;
		};
		const auto DisplayDefault = [StoredDefault]() -> double
		{
			return static_cast<double>(StoredDefault());
		};

		TSharedRef<SWidget> Slider = MakeSlider(
			TAttribute<FText>::CreateLambda([KeyFor, Label]() -> FText
			{
				const FMixtormatParameterDefinitionKey* Key = KeyFor();
				return Key
					? MixtormatParameterAuthoring::ResolveAuthoringLabel(*Key, Label)
					: Label;
			}),
			TAttribute<double>::CreateLambda([this, Resolve, Member, StoredDefault, ResolveTarget]() -> double
			{
				const TOwner* Owner = Resolve();
				const int32 Local = Owner ? Owner->*Member : StoredDefault();
				return static_cast<double>(GetEffectiveIntParameter(ResolveTarget(), Local));
			}),
			RangeBound(MinValue, false),
			RangeBound(MaxValue, true),
			TAttribute<double>::CreateLambda(DisplayDefault),
			1.0,
			true,
			FMixtormatOnSliderValueChanged::CreateLambda([this, Resolve, Member, ResolveTarget](const double Value)
			{
				if (TOwner* Owner = Resolve())
				{
					const FMixtormatParameterAddress Address = ResolveTarget();
					if (IsParameterLocked(Address))
					{
						return;
					}
					const int32 Authored = FMath::RoundToInt(Value);
					if (!TryWriteLinkedInt(Address, Authored))
					{
						Owner->*Member = Authored;
						if (FMixtormatParameterBinding* Binding = FindParameterBinding(Address, false))
						{
							Binding->Reference.bEnabled = false;
						}
					}
					RefreshLayeredPreview();
				}
			}),
			FSimpleDelegate::CreateLambda([this, Resolve, Member, StoredDefault, ResolveTarget]()
			{
				TOwner* Owner = Resolve();
				const int32 ResetValue = StoredDefault();
				if (Owner && Owner->*Member != ResetValue)
				{
					const FMixtormatParameterAddress Address = ResolveTarget();
					if (IsParameterLocked(Address))
					{
						return;
					}
					if (!TryWriteLinkedInt(Address, ResetValue))
					{
						Owner->*Member = ResetValue;
						if (FMixtormatParameterBinding* Binding = FindParameterBinding(Address, false))
						{
							Binding->Reference.bEnabled = false;
						}
					}
					RefreshLayeredPreview();
				}
			}),
			ToolTip,
			MakeParameterRangeOptions(KeyFor));
		return WrapParameterControl(Slider, ResolveTarget);
	}

	// The toggle equivalent, so a checkbox row is declared the same way a value row is instead of
	// being hand-assembled per panel.
	template <typename TOwner>
	TSharedRef<SWidget> MakeMemberToggle(
		const FText& Label,
		TFunction<TOwner*()> Resolve,
		bool TOwner::* Member,
		const TAttribute<FText>& ToolTip = TAttribute<FText>())
	{
		// Trailing rather than Make: a toggle's label travels with its toggle. The shared label
		// column exists so a run of values scans down one edge, and a toggle has no value in it
		// to scan -- paired beside a slider, a far-left label left "Invert" sitting against the
		// slider's right edge, closer to the value it did not belong to than to its own control.
		const TFunction<FMixtormatParameterAddress()> ResolveTarget = MakeAddressResolver(Resolve, Member);
		TSharedRef<SWidget> Toggle = MixtormatRow::MakeTrailing(
			Label,
			MixtormatRow::MakeCheckbox(
				TAttribute<ECheckBoxState>::CreateLambda([this, Resolve, Member, ResolveTarget]()
				{
					const TOwner* Owner = Resolve();
					const bool Local = Owner && Owner->*Member;
					return GetEffectiveBoolParameter(ResolveTarget(), Local) ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
				}),
				FOnCheckStateChanged::CreateLambda([this, Resolve, Member, ResolveTarget](const ECheckBoxState State)
				{
					if (TOwner* Owner = Resolve())
					{
						const FMixtormatParameterAddress Address = ResolveTarget();
						if (IsParameterLocked(Address))
						{
							return;
						}
						const bool Authored = State == ECheckBoxState::Checked;
						if (!TryWriteLinkedBool(Address, Authored))
						{
							Owner->*Member = Authored;
							if (FMixtormatParameterBinding* Binding = FindParameterBinding(Address, false))
							{
								Binding->Reference.bEnabled = false;
							}
						}
						RefreshLayeredPreview();
					}
				})),
			ToolTip);
		return WrapParameterControl(Toggle, ResolveTarget);
	}

	// The one enum menu builder behind every MakeMemberEnum row: entries from the member's
	// UEnum, checked state from the effective (link-resolved) value, writes through the caller's
	// linked path. Defined in SMixtormat_Parameters.cpp, where the menu builder lives.
	TSharedRef<SWidget> BuildEnumMenu(
		const UEnum* Enum,
		TFunction<int64()> ActiveValue,
		TFunction<void(int64)> WriteValue,
		const FSimpleDelegate& AfterWrite);

	// The enum equivalent of the rows above, and the replacement for the hand-built chip+menu
	// pairs (plan D7): one control idiom for every reflected-enum member. The chip shows the
	// effective (link-resolved) value under the authoring label override; the menu is built from
	// the member's UEnum; every write routes through the linked path so a Link survives the edit,
	// falling back to the member exactly as the sliders do. AfterWrite lets a panel keep a side
	// effect its old hand menu carried (Stain rebuilt the layer list).
	template <typename TOwner, typename TEnum>
	TSharedRef<SWidget> MakeMemberEnum(
		const FText& Label,
		TFunction<TOwner*()> Resolve,
		TEnum TOwner::* Member,
		const TAttribute<FText>& ToolTip = TAttribute<FText>(),
		FSimpleDelegate AfterWrite = FSimpleDelegate())
	{
		const UEnum* Enum = StaticEnum<TEnum>();
		const TFunction<FMixtormatParameterAddress()> ResolveTarget = MakeAddressResolver(Resolve, Member);

		const auto ActiveValue = [this, Resolve, Member, ResolveTarget]() -> int64
		{
			const TOwner* Owner = Resolve();
			const int64 Local = Owner ? static_cast<int64>(Owner->*Member) : 0;
			return GetEffectiveEnumParameter(ResolveTarget(), Local);
		};

		const auto WriteValue = [this, Resolve, Member, ResolveTarget](const int64 Value)
		{
			if (TOwner* Owner = Resolve())
			{
				const FMixtormatParameterAddress Address = ResolveTarget();
				if (IsParameterLocked(Address))
				{
					return;
				}
				if (!TryWriteLinkedEnum(Address, Value))
				{
					Owner->*Member = static_cast<TEnum>(Value);
					if (FMixtormatParameterBinding* Binding = FindParameterBinding(Address, false))
					{
						Binding->Reference.bEnabled = false;
					}
				}
				RefreshLayeredPreview();
			}
		};

		TSharedRef<SWidget> EnumChip = MixtormatRow::MakeChip(
			TAttribute<FText>::CreateLambda([Enum, ActiveValue]() -> FText
			{
				return Enum->GetDisplayNameTextByValue(ActiveValue());
			}),
			FOnGetContent::CreateLambda([this, Enum, ActiveValue, WriteValue, AfterWrite]()
			{
				return BuildEnumMenu(Enum, ActiveValue, WriteValue, AfterWrite);
			}), nullptr, TAttribute<FText>(), 0.0f);
		TSharedRef<SWidget> Row = MixtormatRow::MakeDropdown(Label, EnumChip, ToolTip);
		FEnumResetBinding& ResetBinding = EnumResetBindings.AddDefaulted_GetRef();
		ResetBinding.Widget = EnumChip;
		ResetBinding.Reset = FSimpleDelegate::CreateLambda(
			[this, Enum, ResolveTarget, WriteValue, AfterWrite]()
			{
				const TOptional<FMixtormatParameterDefinitionKey> Key =
					MixtormatParameterUi::DefinitionKeyOf(ResolveTarget());
				if (!Enum || !Key.IsSet())
				{
					return;
				}
				const FName DefaultName =
					MixtormatParameterAuthoring::ResolveAuthoringEnumDefault(Key.GetValue());
				const int64 DefaultValue = Enum->GetValueByNameString(DefaultName.ToString());
				if (DefaultValue != INDEX_NONE)
				{
					WriteValue(DefaultValue);
					AfterWrite.ExecuteIfBound();
				}
			});
		return WrapParameterControl(Row, ResolveTarget);
	}

	// Procedural peel and erosion rows all read and write one member of the selected effect, so
	// they collapse to a single call each.
	//
	// Each comes in two forms: Make* returns the row so it can be composed -- paired with another
	// row, wrapped, or placed under a caption -- and Add* appends it directly, which is what most
	// call sites want.
	TSharedRef<SWidget> MakePeelSlider(
		const FText& Label,
		float FMixtormatLayerEffect::* Member,
		double MinValue,
		double MaxValue,
		double DefaultValue,
		double SnapDelta,
		const TAttribute<FText>& ToolTip = TAttribute<FText>());

	TSharedRef<SWidget> MakePeelSliderInt(
		const FText& Label,
		int32 FMixtormatLayerEffect::* Member,
		double MinValue,
		double MaxValue,
		int32 DefaultValue,
		const TAttribute<FText>& ToolTip = TAttribute<FText>());

	TSharedRef<SWidget> MakeErosionSlider(
		const FText& Label,
		float FMixtormatLayerEffect::* Member,
		double MinValue,
		double MaxValue,
		double DefaultValue,
		double SnapDelta,
		const TAttribute<FText>& ToolTip = TAttribute<FText>());

	TSharedRef<SWidget> MakeErosionSliderInt(
		const FText& Label,
		int32 FMixtormatLayerEffect::* Member,
		double MinValue,
		double MaxValue,
		int32 DefaultValue,
		const TAttribute<FText>& ToolTip = TAttribute<FText>());

	void AddPeelSlider(
		const TSharedRef<SVerticalBox>& TargetPanel,
		const FText& Label,
		float FMixtormatLayerEffect::* Member,
		double MinValue,
		double MaxValue,
		double DefaultValue,
		double SnapDelta,
		const TAttribute<FText>& ToolTip = TAttribute<FText>());

	void AddPeelSliderInt(
		const TSharedRef<SVerticalBox>& TargetPanel,
		const FText& Label,
		int32 FMixtormatLayerEffect::* Member,
		double MinValue,
		double MaxValue,
		int32 DefaultValue,
		const TAttribute<FText>& ToolTip = TAttribute<FText>());


	bool ResetHoveredNumericControl();
	void HandleSearchChanged(const FText& SearchTextValue);
	void HandleUserLibrarySearchChanged(const FText& SearchTextValue);
	void RebuildCategoryList();
	void RebuildSurfaceList();
	void RebuildUserLibraryList();
	void RebuildLayerList();
	void RebuildMaskList();
	TSharedRef<SWidget> BuildTopBar();
	TSharedRef<SWidget> BuildAuthoringPage();
	// The viewport-pinned rail and its shared Layers/Library/Global page surface. Only Layers travels.
	TSharedRef<SWidget> BuildLeftColumn();
	// What floats when the layer stack pops out: the stack, its grab margin and its grips.
	TSharedRef<SWidget> BuildFloatingLayerStack();
	TSharedRef<SWidget> BuildGlobalPage();
	TSharedRef<SWidget> BuildBottomLibrary();
	TSharedRef<SWidget> BuildStatusBar();
	FReply ToggleBottomLibraryCollapsed();
	FReply ToggleLeftPanelCollapsed();
	FReply ToggleInspectorCollapsed();
	// Sources shelf expansion. UI only: closing the shelf disables nothing and never reaches the
	// document.
	void ToggleSourcesExpanded();
	// Moves the single layer stack between its dock and overlay hosts, and keeps the rail's
	// selection pointing at a page the cell can actually show.
	void ApplyLeftPanelPlacement();
	void SyncLeftCellPage();
	// Floating panels: the shared stack both panels float in, and the fronting that decides which
	// one a press lands on. Geometry, clamping, auto-fit height and the drag/resize interaction
	// are shared free functions (SMixtormatOverlayPanel.h).
	FVector2D GetPreviewViewportBounds() const;
	FVector2D GetPreviewViewportLocalPosition(const FVector2D& ScreenPosition) const;
	TSharedRef<SWidget> BuildFloatingPanelStack();
	// The Fit height action both floating panels share: a small chevron on the panel's bottom
	// edge, shown only while the height is explicit (D23).
	TSharedRef<SWidget> MakeOverlayFitButton(FMixtormatOverlayPanelState& State, const TSharedPtr<SWidget>& Panel);
	void BringFloatingPanelToFront(bool bLeftPanel);
	void ApplyFloatingPanelOrder();
	TSharedRef<SWidget> BuildLibraryPage();
	TSharedRef<SWidget> BuildUserLibraryPage();
	TSharedRef<SWidget> BuildSurfaceList();
	TSharedRef<SWidget> BuildLayerStackPanel();
	// The Sources shelf: the collapsible list of reusable outputs below the layer rows.
	TSharedRef<SWidget> BuildSourcesShelf();
	// Shelf rows, the Add Source menu and the source actions. Authoring only: sources do not
	// evaluate or connect yet, so no action here touches the render.
	void RebuildSourcesList();
	TSharedRef<SWidget> BuildAddSourcesMenu();
	TSharedRef<SWidget> BuildSourceContextMenu(const FGuid SourceId);
	FReply AddSource(const EMixtormatGeneratorType Kind);
	FReply DeleteSource(const FGuid SourceId);
	FReply RenameSource(const FGuid SourceId, const FText NewName);
	void SelectSource(const FGuid SourceId);
	FMixtormatSourceEntry* GetSelectedSource();
	const FMixtormatSourceEntry* GetSelectedSource() const;
	TSharedRef<SWidget> BuildLayerRow(int32 LayerIndex);
	TSharedRef<SWidget> BuildLayerThumbnail(int32 LayerIndex);
	TSharedRef<SWidget> BuildLayerChildIcon(int32 LayerIndex, int32 ChildIndex);
	// The mask a child row is carrying, shown on hover -- the row only has room for a glyph.
	// Null for effects and generated masks, which have no picture to show.
	TSharedPtr<IToolTip> BuildMaskPreviewTooltip(int32 LayerIndex, int32 ChildIndex);
	FText GetLayerDisplayName(int32 LayerIndex) const;
	FText GetLayerSourceText(int32 LayerIndex) const;
	FText GetLayerChildName(const FMixtormatLayerChild& Child) const;
	FText GetLayerChildSourceText(int32 LayerIndex, int32 ChildIndex) const;
	TSharedRef<SWidget> BuildLayerContextMenu(int32 LayerIndex);
	TSharedRef<SWidget> BuildAddEffectMenu(int32 LayerIndex);
	TSharedRef<SWidget> BuildEffectContextMenu(int32 LayerIndex, int32 ChildIndex);
	TSharedRef<SWidget> BuildMaskBar();
	TSharedRef<SWidget> BuildMaskBlendModeMenu(int32 LayerIndex, int32 MaskIndex);
	// The Height Op choices for one layer, from its badge.
	TSharedRef<SWidget> BuildLayerHeightOpMenu(int32 LayerIndex);
	TSharedRef<SWidget> BuildMaskContextMenu(int32 LayerIndex, int32 MaskIndex);
	TSharedRef<SWidget> BuildBlurContextMenu(int32 LayerIndex, int32 ChildIndex);
	FMixtormatMaskBlur* GetSelectedLayerBlur();
	const FMixtormatMaskBlur* GetSelectedLayerBlur() const;
	// The mask picker grid, shared by adding and replacing -- the caller says what a pick means.
	TSharedRef<SWidget> BuildMaskGallery(TFunction<void(const FSoftObjectPath&)> OnChosen);

	TSharedRef<SWidget> BuildNormalSourceMenu(int32 LayerIndex);
	TSharedRef<SWidget> BuildMaskCard(
		const FText& Name,
		const FSoftObjectPath& AssetPath,
		const FAssetData& ThumbnailAsset,
		bool bCompact);
	TSharedRef<SWidget> BuildMaskLibraryContextMenu(FSoftObjectPath AssetPath);
	void RemoveImportedMask(FSoftObjectPath AssetPath);
	TSharedRef<SWidget> BuildSurfaceCard(
		const FText& Name,
		const FSoftObjectPath& AssetPath,
		const FAssetData& ThumbnailAsset);
	TSharedRef<SWidget> BuildSurfaceLibraryContextMenu(FSoftObjectPath AssetPath);
	TSharedRef<SWidget> BuildCompositionLibraryContextMenu(FSoftObjectPath AssetPath);
	void AddSurfaceFromLibrary(FSoftObjectPath AssetPath);
	void AddCompositionLayers(FSoftObjectPath AssetPath);
	void AddBakedLayerFromComposition(FSoftObjectPath AssetPath);
	void AddReferenceLayerFromComposition(FSoftObjectPath AssetPath);
	void BrowseLibraryAsset(FSoftObjectPath AssetPath);
	void RefreshBuiltInSurface(FSoftObjectPath AssetPath);
	void DeleteBuiltInSurface(FSoftObjectPath AssetPath);
	void RemoveImportedSurface(FSoftObjectPath AssetPath);
	TSharedRef<SWidget> BuildPreviewPanel();
	// The preview's control clusters, shared by the viewport overlay and the GLOBAL Preview /
	// Viewport section (SMixtormat_PreviewControls.cpp). Each returns the control content; the
	// caller decides where it goes and how it is wrapped.
	TSharedRef<SWidget> BuildPreviewRenderControls(bool bMarkingMenu = false);
		TSharedRef<SWidget> BuildPreviewDisplacementControls();
	// The overlay's compact copy of the render strip: render scale and the Final popup only. AA,
	// Default/Lumen and displacement live in GLOBAL, where there is room for them.
	TSharedRef<SWidget> BuildPreviewRenderStrip();
	TSharedRef<SWidget> MakePreviewScaleRow();
	TSharedRef<SWidget> MakeCompositionResolutionControl();
	TSharedRef<SWidget> MakePreviewFinalButton();
	// Wraps a control cluster in the shared plate. A member rather than a file-local helper because
	// the viewport composition and the quick-controls popup both build clusters.
	TSharedRef<SWidget> MakePreviewCluster(const TSharedRef<SWidget>& Content);
	// Q controls: a cursor-centred overlay with distance fading and pass-through gaps.
	TSharedRef<SWidget> BuildQuickControlsOverlay();
		TSharedRef<SWidget> BuildQuickControlsActions();
	void ToggleQuickControls();
	void CloseQuickControls();
	// How a group's buttons are laid out: the viewport's rails stack them down an edge, GLOBAL's
	// cards run them inline, and the quick-controls popup grids them as a palette of choices.
	enum class EPreviewControlLayout : uint8 { Rail, Inline, Grid };
	TSharedRef<SWidget> BuildPreviewLightingControls(EPreviewControlLayout Layout = EPreviewControlLayout::Rail);
	TSharedRef<SWidget> BuildPreviewGeometryControls(EPreviewControlLayout Layout = EPreviewControlLayout::Rail);
	TSharedRef<SWidget> BuildPreviewSceneControls();
	TSharedRef<SWidget> BuildPreviewCameraControls();
	TSharedRef<SWidget> BuildPreviewOutputControls();
	TSharedRef<SWidget> BuildInspectorPanel();
	// The selected Sources shelf entry's card: name, kind, enabled. The kind's own parameter
	// panel opens beneath it through the shared generator resolver.
	TSharedRef<SWidget> BuildSourcesPanel();
	// The one list of child types that own the child-inspector scrollbox. Both master visibility
	// predicates in BuildInspectorPanel read this, so a new child type cannot claim its own panel
	// and still leave the layer inspector showing underneath.
	bool HasSelectedChildInspector() const;

	TSharedRef<SWidget> BuildChannelInfluenceControls();
	// A card rather than a group: colour adjustment is part of how a layer composites, so it
	// lives inside Composition next to the blend mode and opacity that decide the same thing.
	TSharedRef<SWidget> BuildColorAdjustmentCard();
	// The Surface Adjustments body, as titled cards. Extracted from the inline tree it used to
	// be: one column of thirteen sliders with no structure, which is what the cards are for.
	TSharedRef<SWidget> BuildSurfaceAdjustmentCards();

	// Appends the Feature, Curvature and Surface Mask cards. Appends rather than returns,
	// because these are siblings of the cards above them now rather than a group of their own.
	void AddGeneratedFeatureCards(const TSharedRef<SVerticalBox>& Panel);
	TSharedRef<SWidget> BuildHeightBlendControls();
	TSharedRef<SWidget> BuildLayerMaskControls();
	TSharedRef<SWidget> BuildMaskBlurControls();
	TSharedRef<SWidget> BuildGeneratedMaskControls();
	TSharedRef<SWidget> BuildStainControls();
	TSharedRef<SWidget> BuildRunoffControls();
	TSharedRef<SWidget> BuildErosionControls();
	TSharedRef<SWidget> BuildProceduralPeelControls();
	TSharedRef<SWidget> BuildGeneratedContextMenu(int32 LayerIndex, int32 ChildIndex);
	TSharedRef<SWidget> BuildGeneratedBlendModeMenu(int32 LayerIndex, int32 ChildIndex);
	TSharedRef<SWidget> BuildGradeControls();
	TSharedRef<SWidget> BuildBreakupControls();


	TWeakPtr<SWindow> LiveThemeWindow;
	bool bThemeRefreshPending = false;
	EThemeRefreshMode PendingRefreshMode = EThemeRefreshMode::Reconstruct;
	float ShellLeftFraction = 0.19f;
	float ShellCenterFraction = 0.60f;
	float ShellRightFraction = 0.21f;
	enum class EInspectorPlacement : uint8 { Docked, Overlay, Hidden };
	enum class ELeftPanelPlacement : uint8 { Docked, Overlay, Hidden };
	EInspectorPlacement InspectorPlacement = EInspectorPlacement::Docked;
	ELeftPanelPlacement LeftPanelPlacement = ELeftPanelPlacement::Docked;
	bool bInspectorCollapsed = false; // Derived: the docked column is absent in Overlay and Hidden.
	TSharedPtr<SWidget> InspectorPanel;
	TSharedPtr<SWidget> LeftPanel;
	TSharedPtr<SBox> InspectorDockHost;
	TSharedPtr<SBox> InspectorOverlayHost;
	TSharedPtr<SBox> LeftPanelDockHost;
	TSharedPtr<SBox> LeftPanelOverlayHost;
	// The floating panels' geometry and gesture state. Both live here rather than on the widgets
	// so a theme reconstruction preserves them; the placement, clamping and drag/resize code is
	// shared (SMixtormatOverlayPanel.h).
	FMixtormatOverlayPanelState InspectorOverlay;
	FMixtormatOverlayPanelState LeftPanelOverlay;
		bool bLayerHomeDragPending = false;
		FVector2D LayerHomeDragOriginScreen = FVector2D::ZeroVector;
	// The two floating panels share one stack of two slots; the front slot paints and hit-tests
	// last. A press inside a panel brings it forward on the next tick (D25).
	TSharedPtr<SBox> FloatingPanelBackSlot;
	TSharedPtr<SBox> FloatingPanelFrontSlot;
	TSharedPtr<SWidget> InspectorOverlayFrame;
	TSharedPtr<SWidget> LeftPanelOverlayFrame;
	bool bLeftPanelInFront = false;
	bool bAppliedLeftPanelInFront = false;
	// The gallery is one bottom overlay drawer; its open state and height survive rebuilds.
	bool bBottomLibraryCollapsed = false;
	float GalleryDrawerHeight = 0.0f;
	float GalleryColumnFraction = 0.67f;
	bool bGalleryDrawerResizing = false;
	bool bGalleryDrawerResizeMoved = false;
	float GalleryDrawerHeightAtResizeStart = 0.0f;
	FVector2D GalleryDrawerResizeOriginScreen = FVector2D::ZeroVector;
	// SSplitter reports every slot's post-arrangement value, so Inspector write-back stays muted
	// until the first layout has settled after a rebuild.
	bool bSuppressSplitWriteBack = true;
	// One page since the mixer and presets mock-ups were removed. Kept as a switcher rather than
	// unwound to a bare widget because the live-theme rebuild tears the tree down and re-parents
	// through it, and the settings window will want the second slot.
	TSharedPtr<IInputProcessor> WorkspaceHotkeyProcessor;
	TSharedPtr<SWidgetSwitcher> MainSwitcher;
	TSharedPtr<SWidgetSwitcher> LeftSwitcher;
	TSharedPtr<SBox> GalleryDrawerHost;
	TSharedPtr<SBox> GalleryDrawerHeader;
	TSharedPtr<SButton> BottomLibraryToggleButton;
	bool bGalleryPinned = false;
	bool bGalleryDrawerAnimating = false;
	bool bGalleryPointerInside = false;
	float GalleryDrawerAnimatedHeight = 0.0f;
	TSharedPtr<SVerticalBox> CategoryListBox;
	TSharedPtr<SWrapBox> SurfaceListBox;
	TSharedPtr<SVerticalBox> UserLibraryListBox;
	TSharedPtr<SVerticalBox> LayerListBox;
	TSharedPtr<SScrollBox> LayerScrollBox;
	TSharedPtr<SVerticalBox> SourcesListBox;
	// The Add Source menu's anchor, so its button can open it and the menu can close itself after
	// a successful add.
	TSharedPtr<SMenuAnchor> AddSourceAnchor;
	TSharedPtr<SWrapBox> MaskListBox;
	TSharedPtr<STextBlock> SelectedSurfaceText;
	TSharedPtr<STextBlock> SelectedIdentityText;
	// The strip mirrors a layer row, so it carries the row's thumbnail too. Swapped on selection
	// rather than bound, because a thumbnail is a widget from the pool and not a brush.
	TSharedPtr<SBox> SelectedThumbnailBox;
	TSharedPtr<STextBlock> WorkingBaseLayerText;
	TSharedPtr<FAssetThumbnailPool> ThumbnailPool;
	FDelegateHandle AssetUpdatedHandle;
	float MaterialGalleryTileSize = 0.0f;
	float MaskGalleryTileSize = MixtormatTokens::MaskBarTileSize;
	TArray<TSharedPtr<FAssetThumbnail>> LayerThumbnails;
	// The inspector strip's own thumbnail. Kept apart from LayerThumbnails because the strip is
	// re-made on every selection while that array is only cleared when the whole stack rebuilds --
	// pooled thumbnails accumulating there would eat the pool's budget.
	TSharedPtr<FAssetThumbnail> SelectedStripThumbnail;
	TArray<TSharedPtr<FAssetThumbnail>> MaskThumbnails;
	TArray<TSharedPtr<SMixtormatPreviewViewport>> PreviewViewports;
	// Keyed on identity, not position. Grouping gathers layers into a contiguous block and every
	// index in the stack shifts; an index-keyed set would hand one layer's expanded state to
	// whichever layer landed on its old row.
	// The live rows, so F2 can reach the one the selection names. Weak: RebuildLayerList throws
	// the widgets away and builds new ones on every change.
	mutable TMap<FGuid, TArray<FText>> StructuralIncomingCountLabels;
	mutable TMap<FString, FText> StructuralConnectionLabelCache;
	TMap<FGuid, TWeakPtr<class SMixtormatLayerRow>> LayerRowWidgets;
	TMap<FGuid, TWeakPtr<class SMixtormatLayerGroupRow>> GroupRowWidgets;
	// The selected Sources shelf entry, by identity like every other selection. Selecting a
	// source clears the layer and group selection, so the inspector has one subject.
	FGuid SelectedSourceId;
	TSet<FGuid> ExpandedLayerIds;
	TSet<FMixtormatChildAddress> CollapsedGeneratorAddresses;
	TWeakPtr<FMixtormatStructuralEndpointPreview> StructuralEndpointPreview;
	TMap<FMixtormatChildAddress, TWeakPtr<SWidget>> ChildRowWidgets;
	TSet<FMixtormatChildAddress> AmbiguousChildRowAddresses;
	// Collapsed groups hide their members. UI only -- it never reaches the asset or the render.
	TSet<FGuid> CollapsedGroupIds;
	// Sources shelf expansion. UI only, like the group collapse set: closing the shelf disables
	// nothing and never reaches the asset.
	bool bSourcesExpanded = false;
	// Selecting a group clears the layer selection and the other way round, so the inspector
	// always has exactly one subject.
	FGuid SelectedGroupId;
	int32 SelectedGroupChildIndex = INDEX_NONE;
	// What the Group button acts on. Additive: SelectedLayerIndex stays the single layer the
	// inspector shows, and every existing path that reads it is unaffected.
	TSet<FGuid> SelectedLayerIds;
	// Where a shift-extend measures from. Set by a plain click only -- reusing SelectedLayerIndex
	// would move the anchor on every ctrl-click and make the next range unpredictable.
	FGuid SelectionAnchorLayerId;
	TArray<FMixtormatLayer> WorkingLayers;
	TArray<FMixtormatLayer> SavedLayers;
	TArray<FMixtormatLayerGroup> WorkingLayerGroups;
	TArray<FMixtormatLayerGroup> SavedLayerGroups;
	// The Sources shelf's document mirror, kept apart from the compositing stack on purpose:
	// nothing that walks WorkingLayers may see a source as a layer.
	TArray<FMixtormatSourceEntry> WorkingSources;
	TArray<FMixtormatSourceEntry> SavedSources;
	TArray<FEditHistoryState> UndoHistory;
	TArray<FEditHistoryState> RedoHistory;
	TArray<FNumericResetBinding> NumericResetBindings;
	TArray<FEnumResetBinding> EnumResetBindings;
	TOptional<FMixtormatParameterAddress> ParameterReferenceClipboard;

	// The child clipboard keeps the payload, so a Copy still pastes after its source is deleted,
	// and separately the address it was taken from, which is all an Instance paste needs. Mode
	// replaces the old bChildClipboardIsInstance bool -- PublishedOutput is a third state that bool
	// could not express without a second flag.
	TOptional<FMixtormatChildClipboard> ChildClipboard;
	// A copied ID Group carries its existing scoped rows, not the producers they reference.
	TArray<FMixtormatLayerChild> ChildClipboardScopedRows;
	FEditHistoryState CurrentHistoryState;
	FSoftObjectPath SelectedSurfacePath;
	FText SelectedLibrarySurfaceName;
	FString UserLibrarySearchText;
	FSoftObjectPath SelectedMaskPath;
	FText SelectedLibraryMaskName;
	TStrongObjectPtr<UMaterialInstanceConstant> SelectedPreviewMaterial;
	TStrongObjectPtr<UMixtormatMaterial> WorkingMaterialAsset;
	float CurrentTiling = 2.0f;
	float CurrentRoughnessBias = 0.5f;
	float CurrentRoughnessContrast = 0.0f;
	float CurrentRoughnessOffset = 0.0f;
	bool bHasWorkingMaterial = false;
	bool bHasSelectedLayer = false;
	bool bIsWorkingMaterialDirty = false;
	bool bHistoryInitialized = false;
	bool bApplyingHistory = false;
	bool bPreviewRefreshPending = false;

	// Drag state. While scrubbing, the preview composites are rate-limited by the viewport and
	// the undo history is not written; both are settled once on the frame the drag ends.
	bool bInteractiveEdit = false;
	bool bInteractiveHistoryPending = false;
	// Set by every refresh request, cleared when the preview is submitted. Lets the drag timer
	// idle instead of re-submitting an unchanged stack every frame while the mouse is held.
	bool bPreviewSubmitPending = false;
	bool bShowCompositionBefore = false;
	bool bPreviewOverlayUiVisible = false;
	// Viewport group visibility, one flag per group, driven by the GLOBAL switches. Session state
	// on the retained workspace; the H/Space master flag above composes with these rather than
	// replacing them, and hidden groups keep their hotkeys.
	bool bPreviewGroupRenderVisible = true;
	bool bPreviewGroupLightingVisible = true;
	bool bPreviewLightGizmoVisible = true;
	bool bPreviewGroupGeometryVisible = true;
	bool bPreviewGroupCameraVisible = true;
	bool bPreviewGroupOutputVisible = true;
	// The quick-controls popup: where it was opened, how big it turned out, and whether it still
	// has to centre itself on the pointer once its size is known.
	bool bQuickControlsOpen = false;
		bool bQuickControlsActionMenuOpen = false;
		bool bQuickControlsFinalMenuOpen = false;
		bool bQuickControlsTimerActive = false;
	FVector2D QuickControlsPosition = FVector2D::ZeroVector;
	FVector2D QuickControlsSize = FVector2D::ZeroVector;
	bool bQuickControlsNeedsCentre = false;
	TSharedPtr<SWidget> QuickControlsPanel;
	// One active timer advances the reveal and proximity fade only while the popup is open.
	float QuickControlsReveal = 1.0f;
	bool bBypassSelectedChild = false;
	bool bPreviewDisplacementEnabled = true;
	bool bGlobalUVRotation90 = false;
	bool bSavedGlobalUVRotation90 = false;
	// Document-level final passes (final height AO), saved with the recipe.
	FMixtormatFinalSettings WorkingFinalSettings;
	FMixtormatFinalSettings SavedFinalSettings;
	bool bIsBaking = false;
	EMixtormatDebugPreviewMode DebugPreviewMode = EMixtormatDebugPreviewMode::None;
	// Only meaningful while DebugPreviewMode == ChildOutput.
	FMixtormatChildPreviewTarget ChildPreviewTarget;
	int32 SelectedLayerIndex = INDEX_NONE;
	int32 SoloLayerIndex = INDEX_NONE;
	int32 SelectedEffectIndex = INDEX_NONE;
	int32 SelectedMaskIndex = INDEX_NONE;
	int32 LeftTabIndex = 0;
	// The page the cell falls back to while the layer stack is away: the rail's highlight always
	// matches what the cell holds, and the layer stack is the one page that can leave it.
	int32 LastNonLayersPage = 2;
	int32 CompositionResolution = 2048;
	// Bake-only, independent of CompositionResolution (the live preview's resolution, which this
	// never changes). Reset from UMixtormatEditorSettings::DefaultBakeResolution the first time
	// the bake dialog opens for a given recipe; edited per-bake after that; never saved back.
	int32 BakeResolution = 2048;
	// Bake-only, same lifecycle as BakeResolution above. Infrastructure only: see
	// UMixtormatEditorSettings::DefaultBakeAASamples.
	int32 BakeAASamples = 1;
	EMixtormatStudioLighting StudioLighting = EMixtormatStudioLighting::Neutral;
	EMixtormatPreviewMesh PreviewMesh = EMixtormatPreviewMesh::Sphere;
	EMixtormatPlaneOrientation PlaneOrientation = EMixtormatPlaneOrientation::Horizontal;
	EMixtormatPreviewQuality PreviewQuality = EMixtormatPreviewQuality::Default;
	EMixtormatPreviewAntiAliasing PreviewAntiAliasing = EMixtormatPreviewAntiAliasing::Temporal;
	int32 PreviewScreenPercentage = MixtormatPreviewScreenPercentage::Default;
	float PreviewFov = MixtormatPreviewCamera::OverlayFovDefault;
	float PreviewDisplacementAmount = 1.0f;
	// Start the overlay preview at half of each preset's authored lighting.
	float PreviewLightIntensity = 0.8f;
	float PreviewSkylightIntensity = 0.1f;
	FSoftObjectPath BakeSettingsRecipePath;
	FString BakeDestinationPath;
	FString BakeOutputBaseName;
	FString WorkingMaterialName = TEXT("No material");
	FString WorkingStatusText = TEXT("Ready");
	FString SearchText;
	FName CategoryFilter;
	double LastHistoryRecordTime = 0.0;
};
